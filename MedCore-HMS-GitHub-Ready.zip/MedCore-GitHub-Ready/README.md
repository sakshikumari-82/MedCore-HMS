# MedCore HMS

**Connected Care. Smarter Hospitals.**

MedCore HMS is a multi-tenant hospital operations platform foundation for hospital teams and patient-facing workflows. It connects patient registration, appointments, clinical records, prescriptions, labs, billing, notifications, audit activity, and hospital branding through a shared REST API and PostgreSQL data model.

## Implemented

- Tenant-aware hospital, user, patient, appointment, EMR, prescription, lab, invoice, notification, and audit entities.
- Signed httpOnly sessions with salted scrypt password hashing, logout, current-profile flow, and role-aware API authorization.
- Real dashboard aggregates, recent audit activity, patient search, CRUD for patients and appointments, append-only medical records, prescriptions, lab orders, invoices, and hospital branding.
- Responsive MedCore workspace UI with loading, empty, error, confirmation-ready form states, patient portal foundation, and responsive navigation.
- OpenAPI contract, generated Zod validation/client hooks, Drizzle schema, database seed, Docker Compose, Nginx, and GitHub Actions.

## Stack

pnpm monorepo, React 19, Vite, TypeScript, Tailwind CSS, shadcn/ui primitives, Framer Motion-ready UI, React Query, Wouter, Express REST API, Drizzle ORM, PostgreSQL 16, Redis 7-ready configuration, Docker, Nginx, and GitHub Actions.

## Structure

```text
artifacts/medcore-hms/    React application
artifacts/api-server/     REST API and auth/session middleware
lib/api-spec/             OpenAPI source
lib/api-client-react/     Generated React Query hooks
lib/api-zod/              Generated Zod request/response schemas
lib/db/                   PostgreSQL schema and Drizzle client
scripts/src/seed.ts       Realistic demo data
docs/                     Architecture, security, and API notes
infra/                    Dockerfiles and Nginx configuration
```

## Local setup

1. Copy `.env.example` to `.env` and set a long `SESSION_SECRET`.
2. Ensure PostgreSQL is available and set `DATABASE_URL`.
3. Install dependencies: `pnpm install`.
4. Apply the development schema: `pnpm --filter @workspace/db run push`.
5. Seed realistic demo data: `pnpm --filter @workspace/scripts run seed`.
6. Start the API: `pnpm --filter @workspace/api-server run dev`.
7. Start the web preview through the managed `artifacts/medcore-hms: web` workflow.

Generate API clients after contract changes:

```bash
pnpm --filter @workspace/api-spec run codegen
```

## Verify

```bash
pnpm run typecheck
pnpm --filter @workspace/api-server run test
pnpm --filter @workspace/api-server run build
PORT=4173 BASE_PATH=/ pnpm --filter @workspace/medcore-hms run build
```

Swagger/OpenAPI is source-controlled in `lib/api-spec/openapi.yaml`. A Swagger UI route is reserved for the next documentation phase.

## Docker

```bash
docker compose up --build
```

The local Nginx entry point is `http://localhost:8080`.

## Deployment preparation

The web artifact is Vercel-compatible as a static Vite output. The API is container-ready for AWS-style deployment behind a reverse proxy or load balancer. Configure PostgreSQL, Redis, object storage, monitoring, and secret values through the target environment; never commit `.env` files or credentials.

## Known limitations

This phase does not yet enable Redis-backed refresh-token rotation, email/SMS verification delivery, password reset delivery, BullMQ scheduling, Socket.IO realtime delivery, object-storage attachments, invoice PDF rendering, full staff CRUD, or production Swagger UI. The working server remains Express + Drizzle rather than a NestJS + Prisma migration; the current PostgreSQL schema, generated API contract, and service boundaries are the stable foundation for that migration.