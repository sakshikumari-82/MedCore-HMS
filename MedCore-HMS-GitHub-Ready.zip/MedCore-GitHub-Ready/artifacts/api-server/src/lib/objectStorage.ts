import { randomUUID } from "node:crypto";
import { File, Storage } from "@google-cloud/storage";

const REPLIT_SIDECAR_ENDPOINT = "http://127.0.0.1:1106";

export const objectStorageClient = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${REPLIT_SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: {
      url: `${REPLIT_SIDECAR_ENDPOINT}/credential`,
      format: { type: "json", subject_token_field_name: "access_token" },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
  }
}

export class ObjectStorageService {
  private getPrivateObjectDir(): string {
    const dir = process.env.PRIVATE_OBJECT_DIR?.trim();
    if (!dir) throw new Error("PRIVATE_OBJECT_DIR is not configured");
    return dir.replace(/^\/+|\/+$/g, "");
  }

  async getObjectEntityUploadURL(): Promise<string> {
    const fullPath = `/${this.getPrivateObjectDir()}/uploads/${randomUUID()}`;
    const { bucketName, objectName } = parseObjectPath(fullPath);
    const response = await fetch(`${REPLIT_SIDECAR_ENDPOINT}/object-storage/signed-object-url`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        bucket_name: bucketName,
        object_name: objectName,
        method: "PUT",
        expires_at: new Date(Date.now() + 15 * 60_000).toISOString(),
      }),
      signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) throw new Error(`Failed to sign upload URL (${response.status})`);
    const result = await response.json() as { signed_url?: string };
    if (!result.signed_url) throw new Error("Storage service did not return an upload URL");
    return result.signed_url;
  }

  normalizeObjectEntityPath(rawPath: string): string {
    const pathname = rawPath.startsWith("https://") ? new URL(rawPath).pathname : rawPath;
    const privateDir = `/${this.getPrivateObjectDir()}/`;
    if (!pathname.startsWith(privateDir)) throw new Error("Upload URL is outside the private object directory");
    const entityPath = pathname.slice(privateDir.length);
    if (!entityPath.startsWith("uploads/") || entityPath.includes("..")) {
      throw new Error("Invalid private object path");
    }
    return `/objects/${entityPath}`;
  }

  async getObjectEntityFile(objectPath: string): Promise<File> {
    if (!objectPath.startsWith("/objects/") || objectPath.includes("..")) {
      throw new ObjectNotFoundError();
    }
    const entityId = objectPath.slice("/objects/".length);
    const { bucketName, objectName } = parseObjectPath(`/${this.getPrivateObjectDir()}/${entityId}`);
    const file = objectStorageClient.bucket(bucketName).file(objectName);
    const [exists] = await file.exists();
    if (!exists) throw new ObjectNotFoundError();
    return file;
  }

  async setPrivateOwner(objectPath: string, userId: string): Promise<void> {
    const file = await this.getObjectEntityFile(objectPath);
    await file.setMetadata({
      metadata: { "custom:aclPolicy": JSON.stringify({ owner: userId, visibility: "private" }) },
    });
  }
}

function parseObjectPath(path: string): { bucketName: string; objectName: string } {
  const parts = path.replace(/^\/+/, "").split("/");
  if (parts.length < 2 || !parts[0] || !parts.slice(1).join("/")) {
    throw new Error("Invalid object storage path");
  }
  return { bucketName: parts[0], objectName: parts.slice(1).join("/") };
}