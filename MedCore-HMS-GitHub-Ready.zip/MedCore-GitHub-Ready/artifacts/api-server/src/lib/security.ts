import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `scrypt:${salt}:${derived}`;
}

export function verifyPassword(password: string, stored: string | null) {
  if (!stored?.startsWith("scrypt:")) return false;
  const [, salt, expected] = stored.split(":");
  if (!salt || !expected) return false;
  const actual = scryptSync(password, salt, 64).toString("hex");
  return timingSafeEqual(Buffer.from(actual, "hex"), Buffer.from(expected, "hex"));
}

export function hasRole(role: string, allowed: readonly string[]) {
  return allowed.includes(role);
}

export function sameTenant(requestHospitalId: string, recordHospitalId: string, isSuperAdmin = false) {
  return isSuperAdmin || requestHospitalId === recordHospitalId;
}

export function hasAppointmentConflict(
  existing: Array<{ patientId: string; doctorId: string; startsAt: Date; endsAt: Date; status: string }>,
  next: { patientId: string; doctorId: string; startsAt: Date; endsAt: Date },
) {
  return existing.some((appointment) => {
    if (["CANCELLED", "NO_SHOW"].includes(appointment.status)) return false;
    const overlaps = appointment.startsAt < next.endsAt && appointment.endsAt > next.startsAt;
    return overlaps && (appointment.patientId === next.patientId || appointment.doctorId === next.doctorId);
  });
}