import { createHash, createHmac, timingSafeEqual } from "node:crypto";

export function sha256(value: string | Buffer) {
  return createHash("sha256").update(value).digest("hex");
}

export function hmacSha256(value: string | Buffer, secret: string) {
  return createHmac("sha256", secret).update(value).digest("hex");
}

export function verifyHmacSha256(value: string | Buffer, signature: string | undefined, secret: string) {
  if (!signature || !secret || !/^[a-f0-9]{64}$/i.test(signature)) return false;
  const expected = Buffer.from(hmacSha256(value, secret), "hex");
  const actual = Buffer.from(signature, "hex");
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export function secureEqual(left: string, right: string) {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}