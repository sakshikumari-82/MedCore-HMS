import { createHmac, randomBytes } from "node:crypto";
import test from "node:test";
import assert from "node:assert/strict";
import { hmacSha256, sha256, verifyHmacSha256 } from "./payment-security";

test("webhook signatures require exact HMAC and reject altered payloads", () => {
  const body = Buffer.from('{"event":"payment.captured"}');
  const secret = "test-secret";
  const signature = createHmac("sha256", secret).update(body).digest("hex");
  assert.equal(verifyHmacSha256(body, signature, secret), true);
  assert.equal(verifyHmacSha256(Buffer.from('{"event":"payment.failed"}'), signature, secret), false);
  assert.equal(verifyHmacSha256(body, undefined, secret), false);
});

test("QR token storage uses a one-way digest and random tokens have sufficient entropy", () => {
  const token = randomBytes(32).toString("base64url");
  assert.equal(token.length >= 40, true);
  assert.notEqual(sha256(token), token);
  assert.equal(sha256(token), sha256(token));
  assert.equal(hmacSha256("event", "key").length, 64);
});