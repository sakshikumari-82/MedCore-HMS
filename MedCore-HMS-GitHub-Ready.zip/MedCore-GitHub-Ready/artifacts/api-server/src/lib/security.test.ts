import assert from "node:assert/strict";
import test from "node:test";
import { hashPassword, hasAppointmentConflict, hasRole, sameTenant, verifyPassword } from "./security";

test("passwords verify without storing the original value", () => {
  const stored = hashPassword("MedcoreDemo123!");
  assert.notEqual(stored, "MedcoreDemo123!");
  assert.equal(verifyPassword("MedcoreDemo123!", stored), true);
  assert.equal(verifyPassword("wrong-password", stored), false);
});

test("RBAC and tenant checks deny unsafe access", () => {
  assert.equal(hasRole("DOCTOR", ["DOCTOR", "NURSE"]), true);
  assert.equal(hasRole("PATIENT", ["DOCTOR", "NURSE"]), false);
  assert.equal(sameTenant("hospital-a", "hospital-a"), true);
  assert.equal(sameTenant("hospital-a", "hospital-b"), false);
  assert.equal(sameTenant("hospital-a", "hospital-b", true), true);
});

test("appointment conflict logic blocks doctor and patient overlap but ignores cancelled visits", () => {
  const start = new Date("2026-09-26T10:00:00Z");
  const end = new Date("2026-09-26T10:30:00Z");
  assert.equal(hasAppointmentConflict([{ patientId: "p1", doctorId: "d1", startsAt: start, endsAt: end, status: "CONFIRMED" }], { patientId: "p2", doctorId: "d1", startsAt: new Date("2026-09-26T10:15:00Z"), endsAt: new Date("2026-09-26T10:45:00Z") }), true);
  assert.equal(hasAppointmentConflict([{ patientId: "p1", doctorId: "d1", startsAt: start, endsAt: end, status: "CANCELLED" }], { patientId: "p1", doctorId: "d2", startsAt: start, endsAt: end }), false);
});