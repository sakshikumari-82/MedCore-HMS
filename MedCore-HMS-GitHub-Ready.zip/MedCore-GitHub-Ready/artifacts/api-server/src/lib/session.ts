import { randomBytes } from "node:crypto";
import { and, eq, gt, isNull } from "drizzle-orm";
import type { Request, Response } from "express";
import { db, userSessions, users } from "@workspace/db";
import { sha256 } from "./payment-security";

const SESSION_COOKIE = "medcore_session";
const SESSION_TTL_SECONDS = 60 * 60 * 8;

function cookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    maxAge: SESSION_TTL_SECONDS * 1000,
    path: "/",
  };
}

async function createSession(userId: string) {
  const token = randomBytes(32).toString("base64url");
  const now = new Date();
  const [row] = await db.insert(userSessions).values({
    userId,
    tokenHash: sha256(token),
    expiresAt: new Date(now.getTime() + SESSION_TTL_SECONDS * 1000),
    lastSeenAt: now,
  }).returning();
  return { token, row };
}

async function currentSession(req: Request) {
  const raw = req.cookies?.[SESSION_COOKIE];
  if (typeof raw !== "string" || !/^[A-Za-z0-9_-]{40,60}$/.test(raw)) return null;
  const [session] = await db.select().from(userSessions).where(and(
    eq(userSessions.tokenHash, sha256(raw)),
    isNull(userSessions.revokedAt),
    gt(userSessions.expiresAt, new Date()),
  )).limit(1);
  return session ?? null;
}

export async function setSession(res: Response, userId: string) {
  const { token } = await createSession(userId);
  res.cookie(SESSION_COOKIE, token, cookieOptions());
}

export async function rotateSession(req: Request, res: Response) {
  const existing = await currentSession(req);
  if (!existing) return false;
  const token = randomBytes(32).toString("base64url");
  const now = new Date();
  const inserted = await db.transaction(async (tx) => {
    const [revoked] = await tx.update(userSessions).set({ revokedAt: now }).where(and(eq(userSessions.id, existing.id), isNull(userSessions.revokedAt))).returning();
    if (!revoked) return false;
    await tx.insert(userSessions).values({
      userId: existing.userId,
      tokenHash: sha256(token),
      expiresAt: new Date(now.getTime() + SESSION_TTL_SECONDS * 1000),
      lastSeenAt: now,
    });
    return true;
  });
  if (inserted) res.cookie(SESSION_COOKIE, token, cookieOptions());
  return inserted;
}

export async function revokeSession(req: Request) {
  const existing = await currentSession(req);
  if (!existing) return;
  await db.update(userSessions).set({ revokedAt: new Date() }).where(eq(userSessions.id, existing.id));
}

export function clearSession(res: Response) {
  res.clearCookie(SESSION_COOKIE, { ...cookieOptions(), maxAge: undefined });
}

export async function getCurrentUser(req: Request) {
  const session = await currentSession(req);
  if (!session) return null;
  if (Date.now() - session.lastSeenAt.getTime() > 5 * 60 * 1000) {
    await db.update(userSessions).set({ lastSeenAt: new Date() }).where(eq(userSessions.id, session.id));
  }
  const [user] = await db.select().from(users).where(and(eq(users.id, session.userId), eq(users.isActive, true))).limit(1);
  return user ?? null;
}