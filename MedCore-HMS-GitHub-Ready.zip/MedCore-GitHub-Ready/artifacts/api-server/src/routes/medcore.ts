import { and, asc, count, desc, eq, gt, gte, ilike, inArray, isNull, lte, or, sql, sum } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import PDFDocument from "pdfkit";
import {
  CreateAttachmentBody,
  CreateAppointmentBody,
  CreateLabOrderBody,
  CreateMedicalRecordBody,
  CreatePatientBody,
  CreatePrescriptionBody,
  GetDashboardActivityQueryParams,
  ListAppointmentsQueryParams,
  ListInvoicesQueryParams,
  ListLabOrdersQueryParams,
  ListMedicalRecordsQueryParams,
  ListNotificationsQueryParams,
  ListAttachmentsQueryParams,
  ListAttachmentsResponse,
  ListAttachmentsResponseItem,
  ListPatientsQueryParams,
  ListPrescriptionsQueryParams,
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
  SearchAllQueryParams,
  UpdateAppointmentBody,
  UpdateCurrentHospitalBody,
  UpdatePatientBody,
  LoginBody,
} from "@workspace/api-zod";
import {
  appointments,
  auditLogs,
  db,
  hospitals,
  invoices,
  invoiceItems,
  labOrders,
  labResults,
  labTestCatalog,
  medicineBatches,
  medicineCatalog,
  inventoryTransactions,
  medicalRecords,
  notifications,
  notificationPreferences,
  patients,
  prescriptions,
  prescriptionItems,
  payments,
  paymentOrders,
  fileAttachments,
  fileUploadIntents,
  userSessions,
  users,
} from "@workspace/db";
import { clearSession, getCurrentUser, revokeSession, rotateSession, setSession } from "../lib/session";
import { hashPassword, verifyPassword } from "../lib/security";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const loginAttempts = new Map<string, { count: number; resetAt: number }>();
const attachmentUploadAttempts = new Map<string, { count: number; resetAt: number }>();
const objectStorage = new ObjectStorageService();
const allowedAttachmentMimeTypes = new Set(["application/pdf", "image/png", "image/jpeg", "text/plain", "text/csv"]);

function fail(res: Response, status: number, error: string, code?: string) {
  return res.status(status).json({ error, ...(code ? { code } : {}) });
}

async function context(req: Request, res: Response) {
  const user = await getCurrentUser(req);
  if (!user) {
    fail(res, 401, "Authentication required", "AUTH_REQUIRED");
    return null;
  }
  if (!user.hospitalId) {
    fail(res, 403, "Hospital context required", "HOSPITAL_REQUIRED");
    return null;
  }
  if (user.role === "PATIENT" && !req.path.startsWith("/portal")) {
    fail(res, 403, "Use the patient portal for patient records", "PORTAL_ONLY");
    return null;
  }
  const [hospital] = await db.select().from(hospitals).where(eq(hospitals.id, user.hospitalId)).limit(1);
  if (!hospital) {
    fail(res, 403, "Hospital access is not available", "HOSPITAL_UNAVAILABLE");
    return null;
  }
  return { user, hospital };
}

function pageParams(query: Record<string, unknown>) {
  const page = Math.max(1, Number(query.page ?? 1));
  const pageSize = Math.min(100, Math.max(1, Number(query.pageSize ?? 20)));
  return { page, pageSize, offset: (page - 1) * pageSize };
}

function streamPdf(res: Response, filename: string, build: (doc: PDFKit.PDFDocument) => void) {
  const doc = new PDFDocument({ size: "A4", margin: 48, info: { Title: filename.replace(/\.pdf$/i, ""), Author: "MedCore HMS" } });
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `inline; filename="${filename.replace(/[^a-zA-Z0-9._-]/g, "_")}"`);
  res.setHeader("Cache-Control", "private, no-store");
  doc.pipe(res);
  build(doc);
  doc.end();
}

function pdfHeading(doc: PDFKit.PDFDocument, title: string, hospitalName: string) {
  doc.fillColor("#07565d").fontSize(21).font("Helvetica-Bold").text("MedCore HMS");
  doc.moveDown(0.2).fillColor("#465b61").fontSize(9).font("Helvetica").text("Connected Care. Smarter Hospitals.");
  doc.moveDown(0.25).fillColor("#18353b").fontSize(15).font("Helvetica-Bold").text(hospitalName);
  doc.moveDown(0.7).fillColor("#132a30").fontSize(19).text(title);
  doc.moveDown(0.8);
}

async function renderInvoicePdf(ctx: { user: typeof users.$inferSelect; hospital: typeof hospitals.$inferSelect }, invoiceId: string, res: Response) {
  const [invoice] = await db.select().from(invoices).where(and(eq(invoices.id, invoiceId), eq(invoices.hospitalId, ctx.hospital.id))).limit(1);
  if (!invoice) return fail(res, 404, "Invoice not found", "NOT_FOUND");
  if (ctx.user.role === "PATIENT") {
    const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
    if (!patient || patient.id !== invoice.patientId) return fail(res, 403, "You cannot access this invoice", "FORBIDDEN");
  }
  const items = await db.select().from(invoiceItems).where(and(eq(invoiceItems.invoiceId, invoice.id), eq(invoiceItems.hospitalId, ctx.hospital.id)));
  streamPdf(res, `${invoice.invoiceNumber}.pdf`, (doc) => {
    pdfHeading(doc, "Hospital invoice", ctx.hospital.name);
    doc.fontSize(10).font("Helvetica").fillColor("#263b40");
    doc.text(`Invoice: ${invoice.invoiceNumber}`);
    doc.text(`Patient: ${invoice.patientName}`);
    doc.text(`Issued: ${invoice.issueDate}    Due: ${invoice.dueDate}`);
    doc.text(`Status: ${invoice.status}`);
    doc.moveDown();
    doc.font("Helvetica-Bold").text("Description", 48, doc.y, { continued: true, width: 260 });
    doc.text("Qty", 310, doc.y, { continued: true, width: 50, align: "right" });
    doc.text("Amount (INR)", 370, doc.y, { width: 170, align: "right" });
    doc.moveDown(0.4).moveTo(48, doc.y).lineTo(547, doc.y).strokeColor("#aab9bd").stroke();
    doc.moveDown(0.5).font("Helvetica");
    for (const item of items) {
      doc.text(item.description, 48, doc.y, { continued: true, width: 260 });
      doc.text(String(Number(item.quantity)), 310, doc.y, { continued: true, width: 50, align: "right" });
      doc.text(Number(item.total).toFixed(2), 370, doc.y, { width: 170, align: "right" });
    }
    doc.moveDown(0.7).font("Helvetica-Bold").text(`Total: INR ${Number(invoice.total).toFixed(2)}`, { align: "right" });
    doc.text(`Paid: INR ${Number(invoice.paid).toFixed(2)}`, { align: "right" });
    doc.text(`Balance: INR ${(Number(invoice.total) - Number(invoice.paid)).toFixed(2)}`, { align: "right" });
    doc.moveDown(2).font("Helvetica").fontSize(8).fillColor("#64777c").text("This document records hospital billing only. It is separate from MedCore HMS subscription revenue.");
  });
  await audit(ctx.hospital.id, ctx.user.id, "INVOICE_PDF_DOWNLOADED", invoice.id);
  return undefined;
}

async function renderPrescriptionPdf(ctx: { user: typeof users.$inferSelect; hospital: typeof hospitals.$inferSelect }, prescriptionId: string, res: Response) {
  const [prescription] = await db.select().from(prescriptions).where(and(eq(prescriptions.id, prescriptionId), eq(prescriptions.hospitalId, ctx.hospital.id))).limit(1);
  if (!prescription) return fail(res, 404, "Prescription not found", "NOT_FOUND");
  if (ctx.user.role === "PATIENT") {
    const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
    if (!patient || patient.id !== prescription.patientId) return fail(res, 403, "You cannot access this prescription", "FORBIDDEN");
  }
  streamPdf(res, `prescription-${prescription.id.slice(0, 8)}.pdf`, (doc) => {
    pdfHeading(doc, "Prescription", ctx.hospital.name);
    doc.font("Helvetica").fontSize(10).fillColor("#263b40")
      .text(`Patient: ${prescription.patientName}`)
      .text(`Prescriber: ${prescription.doctorName}`)
      .text(`Issued: ${prescription.issuedAt.toISOString().slice(0, 10)}`)
      .text(`Status: ${prescription.status}`);
    doc.moveDown();
    doc.font("Helvetica-Bold").text("Medication instructions");
    doc.moveDown(0.3).font("Helvetica");
    const medicines = Array.isArray(prescription.medicines) ? prescription.medicines : [];
    medicines.forEach((medicine, index) => {
      doc.text(`${index + 1}. ${medicine.medicine || "Medication"}`);
      doc.fontSize(9).fillColor("#465b61").text(
        [medicine.dosage, medicine.frequency, medicine.duration, medicine.instructions].filter(Boolean).join(" · "),
        { indent: 14 },
      );
      doc.moveDown(0.4).fontSize(10).fillColor("#263b40");
    });
    if (prescription.instructions) doc.moveDown().text(`Additional instructions: ${prescription.instructions}`);
    doc.moveDown(2).fontSize(8).fillColor("#64777c").text("Use only as directed by the prescribing clinician. This PDF is generated from the signed hospital prescription.");
  });
  await audit(ctx.hospital.id, ctx.user.id, "PRESCRIPTION_PDF_DOWNLOADED", prescription.id);
  return undefined;
}

function patientView(row: typeof patients.$inferSelect) {
  return {
    id: row.id,
    hospitalId: row.hospitalId,
    mrn: row.mrn,
    name: row.name,
    dateOfBirth: row.dateOfBirth,
    gender: row.gender,
    phone: row.phone,
    email: row.email,
    bloodGroup: row.bloodGroup,
    status: row.status as "ACTIVE" | "INACTIVE",
    lastVisit: row.lastVisit,
    condition: row.condition,
    initials: row.name.split(" ").map((part: string) => part[0]).join("").slice(0, 2).toUpperCase(),
  };
}

function appointmentView(row: typeof appointments.$inferSelect) {
  return {
    id: row.id,
    hospitalId: row.hospitalId,
    patientId: row.patientId,
    patientName: row.patientName,
    doctorId: row.doctorId,
    doctorName: row.doctorName,
    department: row.department,
    startsAt: row.startsAt,
    endsAt: row.endsAt,
    type: row.type,
    status: row.status,
    notes: row.notes,
  };
}

async function audit(hospitalId: string | null, actorId: string | null, action: string, target?: string) {
  await db.insert(auditLogs).values({ hospitalId, actorId, action, target });
}

async function patientForUser(userId: string, hospitalId: string) {
  const [patient] = await db.select().from(patients).where(and(eq(patients.userId, userId), eq(patients.hospitalId, hospitalId), sql`${patients.deletedAt} is null`)).limit(1);
  return patient ?? null;
}

async function notifyUser(hospitalId: string, userId: string, title: string, message: string, type: string) {
  await db.insert(notifications).values({ hospitalId, userId, title, message, type });
}

router.post("/auth/login", async (req, res) => {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const current = loginAttempts.get(ip);
  if (current && current.resetAt > Date.now() && current.count >= 10) {
    return fail(res, 429, "Too many sign-in attempts. Try again shortly.", "RATE_LIMITED");
  }
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Enter a valid email and password", "VALIDATION_ERROR");
  const [user] = await db.select().from(users).where(eq(users.email, parsed.data.email.toLowerCase())).limit(1);
  if (!user || !user.isActive || !verifyPassword(parsed.data.password, user.passwordHash)) {
    loginAttempts.set(ip, { count: (current?.resetAt && current.resetAt > Date.now() ? current.count : 0) + 1, resetAt: Date.now() + 15 * 60 * 1000 });
    return fail(res, 401, "Email or password is incorrect", "INVALID_CREDENTIALS");
  }
  loginAttempts.delete(ip);
  if (!user.hospitalId) return fail(res, 403, "This account is not attached to a hospital", "HOSPITAL_REQUIRED");
  const [hospital] = await db.select().from(hospitals).where(eq(hospitals.id, user.hospitalId)).limit(1);
  if (!hospital) return fail(res, 403, "Hospital access is not available", "HOSPITAL_UNAVAILABLE");
  await db.update(users).set({ lastLoginAt: new Date(), updatedAt: new Date() }).where(eq(users.id, user.id));
  await audit(user.hospitalId, user.id, "LOGIN");
  await revokeSession(req);
  await setSession(res, user.id);
  return res.json({
    user: { id: user.id, name: user.name, email: user.email, role: user.role, hospitalId: user.hospitalId, avatarUrl: user.avatarUrl },
    hospital,
  });
});

router.post("/auth/logout", async (req, res) => {
  const user = await getCurrentUser(req);
  if (user) await audit(user.hospitalId, user.id, "LOGOUT");
  await revokeSession(req);
  clearSession(res);
  return res.status(204).send();
});

router.post("/auth/refresh", async (req, res) => {
  const user = await getCurrentUser(req);
  if (!user || !await rotateSession(req, res)) return fail(res, 401, "Authentication required", "AUTH_REQUIRED");
  await audit(user.hospitalId, user.id, "SESSION_ROTATED");
  return res.json({ refreshed: true });
});

router.get("/auth/session", async (req, res) => {
  const user = await getCurrentUser(req);
  if (!user?.hospitalId) return fail(res, 401, "Authentication required", "AUTH_REQUIRED");
  const [hospital] = await db.select().from(hospitals).where(eq(hospitals.id, user.hospitalId)).limit(1);
  if (!hospital) return fail(res, 401, "Authentication required", "AUTH_REQUIRED");
  return res.json({
    user: { id: user.id, name: user.name, email: user.email, role: user.role, hospitalId: user.hospitalId, avatarUrl: user.avatarUrl },
    hospital,
  });
});

function staffView(user: typeof users.$inferSelect) {
  return { id: user.id, name: user.name, email: user.email, role: user.role, department: user.department, isActive: user.isActive, createdAt: user.createdAt, lastLoginAt: user.lastLoginAt };
}
const staffRoles = ["HOSPITAL_ADMIN", "DOCTOR", "NURSE", "RECEPTIONIST", "LAB_TECHNICIAN", "PHARMACIST", "ACCOUNTANT"] as const;

router.get("/staff", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "SUPER_ADMIN"].includes(ctx.user.role)) return fail(res, 403, "Only hospital administrators can manage staff", "FORBIDDEN");
  const rows = await db.select().from(users).where(and(eq(users.hospitalId, ctx.hospital.id), inArray(users.role, staffRoles))).orderBy(asc(users.name));
  return res.json(rows.map(staffView));
});

router.post("/staff", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "SUPER_ADMIN"].includes(ctx.user.role)) return fail(res, 403, "Only hospital administrators can manage staff", "FORBIDDEN");
  const { name, email, role, department, password } = req.body ?? {};
  if (typeof name !== "string" || name.trim().length < 2 || typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !staffRoles.includes(role) || typeof password !== "string" || password.length < 12) {
    return fail(res, 400, "Enter a name, valid email, supported staff role, and password of at least 12 characters", "VALIDATION_ERROR");
  }
  try {
    const [created] = await db.insert(users).values({
      hospitalId: ctx.hospital.id,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      role,
      department: typeof department === "string" && department.trim() ? department.trim().slice(0, 100) : null,
      passwordHash: hashPassword(password),
      isActive: true,
    }).returning();
    await audit(ctx.hospital.id, ctx.user.id, "STAFF_CREATED", created.id);
    return res.status(201).json(staffView(created));
  } catch (error) {
    if (typeof error === "object" && error && "code" in error && error.code === "23505") return fail(res, 409, "An account already uses that email address", "EMAIL_IN_USE");
    throw error;
  }
});

router.patch("/staff/:staffId", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "SUPER_ADMIN"].includes(ctx.user.role)) return fail(res, 403, "Only hospital administrators can manage staff", "FORBIDDEN");
  const { name, email, role, department, isActive, password } = req.body ?? {};
  if (ctx.user.id === req.params.staffId && (role !== undefined || isActive === false)) return fail(res, 409, "You cannot disable or change your own role", "SELF_CHANGE_BLOCKED");
  if (name !== undefined && (typeof name !== "string" || name.trim().length < 2)) return fail(res, 400, "Name must contain at least two characters", "VALIDATION_ERROR");
  if (email !== undefined && (typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) return fail(res, 400, "Email address is invalid", "VALIDATION_ERROR");
  if (role !== undefined && !staffRoles.includes(role)) return fail(res, 400, "Staff role is not supported", "VALIDATION_ERROR");
  if (isActive !== undefined && typeof isActive !== "boolean") return fail(res, 400, "isActive must be true or false", "VALIDATION_ERROR");
  if (password !== undefined && (typeof password !== "string" || password.length < 12)) return fail(res, 400, "Password must be at least 12 characters", "VALIDATION_ERROR");
  const [before] = await db.select().from(users).where(and(eq(users.id, req.params.staffId), eq(users.hospitalId, ctx.hospital.id), inArray(users.role, staffRoles))).limit(1);
  if (!before) return fail(res, 404, "Staff account not found", "NOT_FOUND");
  try {
    const [updated] = await db.update(users).set({
      ...(name !== undefined ? { name: name.trim() } : {}),
      ...(email !== undefined ? { email: email.toLowerCase().trim() } : {}),
      ...(role !== undefined ? { role } : {}),
      ...(department !== undefined ? { department: typeof department === "string" && department.trim() ? department.trim().slice(0, 100) : null } : {}),
      ...(isActive !== undefined ? { isActive } : {}),
      ...(password !== undefined ? { passwordHash: hashPassword(password) } : {}),
      updatedAt: new Date(),
    }).where(and(eq(users.id, before.id), eq(users.hospitalId, ctx.hospital.id))).returning();
    if (role !== undefined || isActive === false || password !== undefined) {
      await db.update(userSessions).set({ revokedAt: new Date() }).where(and(eq(userSessions.userId, before.id), isNull(userSessions.revokedAt)));
    }
    await audit(ctx.hospital.id, ctx.user.id, "STAFF_UPDATED", updated.id);
    return res.json(staffView(updated));
  } catch (error) {
    if (typeof error === "object" && error && "code" in error && error.code === "23505") return fail(res, 409, "An account already uses that email address", "EMAIL_IN_USE");
    throw error;
  }
});

router.delete("/staff/:staffId", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "SUPER_ADMIN"].includes(ctx.user.role)) return fail(res, 403, "Only hospital administrators can manage staff", "FORBIDDEN");
  if (ctx.user.id === req.params.staffId) return fail(res, 409, "You cannot deactivate your own account", "SELF_CHANGE_BLOCKED");
  const [updated] = await db.update(users).set({ isActive: false, updatedAt: new Date() }).where(and(eq(users.id, req.params.staffId), eq(users.hospitalId, ctx.hospital.id), inArray(users.role, staffRoles))).returning();
  if (!updated) return fail(res, 404, "Staff account not found", "NOT_FOUND");
  await db.update(userSessions).set({ revokedAt: new Date() }).where(and(eq(userSessions.userId, updated.id), isNull(userSessions.revokedAt)));
  await audit(ctx.hospital.id, ctx.user.id, "STAFF_DEACTIVATED", updated.id);
  return res.status(204).send();
});

router.get("/hospitals/current", async (req, res) => {
  const ctx = await context(req, res);
  return ctx ? res.json(ctx.hospital) : undefined;
});

router.patch("/hospitals/current", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "SUPER_ADMIN"].includes(ctx.user.role)) return fail(res, 403, "Only hospital administrators can change branding", "FORBIDDEN");
  const parsed = UpdateCurrentHospitalBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Hospital update is invalid", "VALIDATION_ERROR");
  const [updated] = await db.update(hospitals).set({ ...parsed.data, updatedAt: new Date() }).where(eq(hospitals.id, ctx.hospital.id)).returning();
  await audit(ctx.hospital.id, ctx.user.id, "HOSPITAL_SETTINGS_UPDATED");
  return res.json(updated);
});

router.get("/dashboard/summary", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const hospitalId = ctx.hospital.id;
  const [{ value: patientCount }] = await db.select({ value: count() }).from(patients).where(and(eq(patients.hospitalId, hospitalId), sql`${patients.deletedAt} is null`));
  const [{ value: appointmentCount }] = await db.select({ value: count() }).from(appointments).where(and(eq(appointments.hospitalId, hospitalId), sql`${appointments.deletedAt} is null`));
  const [{ value: doctorCount }] = await db.select({ value: count() }).from(users).where(and(eq(users.hospitalId, hospitalId), eq(users.role, "DOCTOR")));
  const [{ value: pendingLabs }] = await db.select({ value: count() }).from(labOrders).where(and(eq(labOrders.hospitalId, hospitalId), eq(labOrders.status, "ORDERED")));
  const [{ value: outstanding }] = await db.select({ value: sum(sql`${invoices.total} - ${invoices.paid}`) }).from(invoices).where(and(eq(invoices.hospitalId, hospitalId), sql`${invoices.status} <> 'PAID'`));
  const today = new Date();
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const todayEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
  const todayRows = await db.select().from(appointments).where(and(eq(appointments.hospitalId, hospitalId), gte(appointments.startsAt, todayStart), lte(appointments.startsAt, todayEnd), sql`${appointments.deletedAt} is null`)).orderBy(asc(appointments.startsAt)).limit(8);
  const departmentRows = await db.select({ department: appointments.department, value: count() }).from(appointments).where(eq(appointments.hospitalId, hospitalId)).groupBy(appointments.department).orderBy(desc(count())).limit(5);
  const trend = Array.from({ length: 6 }, (_, index) => {
    const dateValue = new Date(todayStart);
    dateValue.setDate(dateValue.getDate() - (5 - index));
    return { label: dateValue.toLocaleDateString("en-US", { weekday: "short" }), value: Math.max(0, Number(appointmentCount) - (5 - index) * 2) };
  });
  return res.json({
    totals: { patients: Number(patientCount), appointments: Number(appointmentCount), doctors: Number(doctorCount), pendingLabs: Number(pendingLabs), outstanding: Number(outstanding ?? 0) },
    appointmentTrend: trend,
    departmentLoad: departmentRows.map((row) => ({ department: row.department, value: Number(row.value) })),
    todayAppointments: todayRows.map(appointmentView),
  });
});

router.get("/dashboard/activity", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = GetDashboardActivityQueryParams.safeParse(req.query);
  const limit = parsed.success ? parsed.data.limit : 10;
  const rows = await db.select({ id: auditLogs.id, action: auditLogs.action, target: auditLogs.target, createdAt: auditLogs.createdAt, actor: users.name }).from(auditLogs).leftJoin(users, eq(users.id, auditLogs.actorId)).where(eq(auditLogs.hospitalId, ctx.hospital.id)).orderBy(desc(auditLogs.createdAt)).limit(limit);
  return res.json(rows.map((row, index) => ({ ...row, actor: row.actor ?? "System", tone: ["blue", "green", "amber", "purple", "red"][index % 5] })));
});

router.get("/patients", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = ListPatientsQueryParams.safeParse(req.query);
  const { page, pageSize, offset } = pageParams(req.query);
  const search = parsed.success ? parsed.data.search : undefined;
  const filter = and(eq(patients.hospitalId, ctx.hospital.id), sql`${patients.deletedAt} is null`, search ? or(ilike(patients.name, `%${search}%`), ilike(patients.mrn, `%${search}%`), ilike(patients.phone, `%${search}%`)) : undefined);
  const [rows, [{ value: total }]] = await Promise.all([
    db.select().from(patients).where(filter).orderBy(desc(patients.updatedAt)).limit(pageSize).offset(offset),
    db.select({ value: count() }).from(patients).where(filter),
  ]);
  return res.json({ items: rows.map(patientView), page, pageSize, total: Number(total) });
});

router.post("/patients", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "RECEPTIONIST", "DOCTOR", "NURSE"].includes(ctx.user.role)) return fail(res, 403, "You do not have permission to register patients", "FORBIDDEN");
  const parsed = CreatePatientBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Patient details are invalid", "VALIDATION_ERROR");
  const mrn = `MC-${Date.now().toString().slice(-7)}`;
  const [row] = await db.insert(patients).values({ ...parsed.data, dateOfBirth: parsed.data.dateOfBirth.toISOString().slice(0, 10), hospitalId: ctx.hospital.id, mrn, status: "ACTIVE" }).returning();
  await audit(ctx.hospital.id, ctx.user.id, "PATIENT_CREATED", row.id);
  return res.status(201).json(patientView(row));
});

router.get("/patients/:patientId", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const [row] = await db.select().from(patients).where(and(eq(patients.id, req.params.patientId), eq(patients.hospitalId, ctx.hospital.id), sql`${patients.deletedAt} is null`)).limit(1);
  if (!row) return fail(res, 404, "Patient not found", "NOT_FOUND");
  await audit(ctx.hospital.id, ctx.user.id, "PATIENT_ACCESSED", row.id);
  return res.json(patientView(row));
});

router.patch("/patients/:patientId", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "RECEPTIONIST", "DOCTOR", "NURSE"].includes(ctx.user.role)) return fail(res, 403, "You do not have permission to update patients", "FORBIDDEN");
  const parsed = UpdatePatientBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Patient update is invalid", "VALIDATION_ERROR");
  const [row] = await db.update(patients).set({ ...parsed.data, updatedAt: new Date() }).where(and(eq(patients.id, req.params.patientId), eq(patients.hospitalId, ctx.hospital.id), sql`${patients.deletedAt} is null`)).returning();
  if (!row) return fail(res, 404, "Patient not found", "NOT_FOUND");
  await audit(ctx.hospital.id, ctx.user.id, "PATIENT_UPDATED", row.id);
  return res.json(patientView(row));
});

router.get("/appointments", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = ListAppointmentsQueryParams.safeParse(req.query);
  const { page, pageSize, offset } = pageParams(req.query);
  const search = parsed.success ? parsed.data.search : undefined;
  const filter = and(eq(appointments.hospitalId, ctx.hospital.id), sql`${appointments.deletedAt} is null`, search ? or(ilike(appointments.patientName, `%${search}%`), ilike(appointments.doctorName, `%${search}%`)) : undefined, parsed.success && parsed.data.status ? eq(appointments.status, parsed.data.status) : undefined, parsed.success && parsed.data.date ? gte(appointments.startsAt, new Date(`${parsed.data.date}T00:00:00.000Z`)) : undefined);
  const [rows, [{ value: total }]] = await Promise.all([
    db.select().from(appointments).where(filter).orderBy(asc(appointments.startsAt)).limit(pageSize).offset(offset),
    db.select({ value: count() }).from(appointments).where(filter),
  ]);
  return res.json({ items: rows.map(appointmentView), page, pageSize, total: Number(total) });
});

router.post("/appointments", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = CreateAppointmentBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Appointment details are invalid", "VALIDATION_ERROR");
  const input = parsed.data;
  if (input.startsAt >= input.endsAt) return fail(res, 400, "Appointment end time must be after start time", "VALIDATION_ERROR");
  const [patient] = await db.select().from(patients).where(and(eq(patients.id, input.patientId), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
  const [doctor] = await db.select().from(users).where(and(eq(users.id, input.doctorId), eq(users.hospitalId, ctx.hospital.id), eq(users.role, "DOCTOR"))).limit(1);
  if (!patient || !doctor) return fail(res, 404, "Patient or doctor not found", "NOT_FOUND");
  const conflict = await db.select({ id: appointments.id }).from(appointments).where(and(eq(appointments.hospitalId, ctx.hospital.id), sql`${appointments.deletedAt} is null`, sql`${appointments.status} not in ('CANCELLED','NO_SHOW')`, or(and(eq(appointments.doctorId, doctor.id), sql`${appointments.startsAt} < ${input.endsAt} and ${appointments.endsAt} > ${input.startsAt}`), and(eq(appointments.patientId, patient.id), sql`${appointments.startsAt} < ${input.endsAt} and ${appointments.endsAt} > ${input.startsAt}`)))).limit(1);
  if (conflict.length) return fail(res, 409, "This time overlaps an existing appointment", "APPOINTMENT_CONFLICT");
  const [row] = await db.insert(appointments).values({ ...input, hospitalId: ctx.hospital.id, patientName: patient.name, doctorName: doctor.name, status: "CONFIRMED" }).returning();
  await audit(ctx.hospital.id, ctx.user.id, "APPOINTMENT_CREATED", row.id);
  return res.status(201).json(appointmentView(row));
});

router.patch("/appointments/:appointmentId", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = UpdateAppointmentBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Appointment update is invalid", "VALIDATION_ERROR");
  const [current] = await db.select().from(appointments).where(and(eq(appointments.id, req.params.appointmentId), eq(appointments.hospitalId, ctx.hospital.id), sql`${appointments.deletedAt} is null`)).limit(1);
  if (!current) return fail(res, 404, "Appointment not found", "NOT_FOUND");
  const startsAt = parsed.data.startsAt ?? current.startsAt;
  const endsAt = parsed.data.endsAt ?? current.endsAt;
  if (startsAt >= endsAt) return fail(res, 400, "Appointment end time must be after start time", "VALIDATION_ERROR");
  if (parsed.data.startsAt !== undefined || parsed.data.endsAt !== undefined) {
    const conflict = await db.select({ id: appointments.id }).from(appointments).where(and(
      eq(appointments.hospitalId, ctx.hospital.id),
      sql`${appointments.deletedAt} is null`,
      sql`${appointments.status} not in ('CANCELLED','NO_SHOW')`,
      sql`${appointments.id} <> ${current.id}`,
      or(eq(appointments.doctorId, current.doctorId), eq(appointments.patientId, current.patientId)),
      sql`${appointments.startsAt} < ${endsAt} and ${appointments.endsAt} > ${startsAt}`,
    )).limit(1);
    if (conflict.length) return fail(res, 409, "This time overlaps an existing appointment", "APPOINTMENT_CONFLICT");
  }
  const [row] = await db.update(appointments).set({ ...parsed.data, updatedAt: new Date() }).where(and(eq(appointments.id, req.params.appointmentId), eq(appointments.hospitalId, ctx.hospital.id), sql`${appointments.deletedAt} is null`)).returning();
  if (!row) return fail(res, 404, "Appointment not found", "NOT_FOUND");
  await audit(ctx.hospital.id, ctx.user.id, "APPOINTMENT_UPDATED", row.id);
  return res.json(appointmentView(row));
});

router.get("/medical-records", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = ListMedicalRecordsQueryParams.safeParse(req.query);
  const { page, pageSize, offset } = pageParams(req.query);
  const filter = and(eq(medicalRecords.hospitalId, ctx.hospital.id), parsed.success && parsed.data.patientId ? eq(medicalRecords.patientId, parsed.data.patientId) : undefined, parsed.success && parsed.data.search ? or(ilike(medicalRecords.patientName, `%${parsed.data.search}%`), ilike(medicalRecords.diagnosis, `%${parsed.data.search}%`), ilike(medicalRecords.chiefComplaint, `%${parsed.data.search}%`)) : undefined);
  const [rows, [{ value: total }]] = await Promise.all([db.select().from(medicalRecords).where(filter).orderBy(desc(medicalRecords.createdAt)).limit(pageSize).offset(offset), db.select({ value: count() }).from(medicalRecords).where(filter)]);
  return res.json({ items: rows, page, pageSize, total: Number(total) });
});

router.post("/medical-records", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "DOCTOR", "NURSE"].includes(ctx.user.role)) return fail(res, 403, "Only clinical staff can create medical records", "FORBIDDEN");
  const parsed = CreateMedicalRecordBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Medical record details are invalid", "VALIDATION_ERROR");
  const [patient] = await db.select().from(patients).where(and(eq(patients.id, parsed.data.patientId), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
  if (!patient) return fail(res, 404, "Patient not found", "NOT_FOUND");
  const [row] = await db.insert(medicalRecords).values({ ...parsed.data, hospitalId: ctx.hospital.id, clinicianId: ctx.user.id, patientName: patient.name, clinicianName: ctx.user.name, status: "SIGNED" }).returning();
  await audit(ctx.hospital.id, ctx.user.id, "MEDICAL_RECORD_CREATED", row.id);
  return res.status(201).json(row);
});

router.get("/prescriptions", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = ListPrescriptionsQueryParams.safeParse(req.query);
  const { page, pageSize, offset } = pageParams(req.query);
  const filter = and(eq(prescriptions.hospitalId, ctx.hospital.id), parsed.success && parsed.data.patientId ? eq(prescriptions.patientId, parsed.data.patientId) : undefined);
  const [rows, [{ value: total }]] = await Promise.all([db.select().from(prescriptions).where(filter).orderBy(desc(prescriptions.issuedAt)).limit(pageSize).offset(offset), db.select({ value: count() }).from(prescriptions).where(filter)]);
  return res.json({ items: rows, page, pageSize, total: Number(total) });
});

router.post("/prescriptions", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "DOCTOR"].includes(ctx.user.role)) return fail(res, 403, "Only doctors can create prescriptions", "FORBIDDEN");
  const parsed = CreatePrescriptionBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Prescription details are invalid", "VALIDATION_ERROR");
  const [patient] = await db.select().from(patients).where(and(eq(patients.id, parsed.data.patientId), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
  if (!patient) return fail(res, 404, "Patient not found", "NOT_FOUND");
  const [row] = await db.insert(prescriptions).values({ ...parsed.data, hospitalId: ctx.hospital.id, doctorId: ctx.user.id, patientName: patient.name, doctorName: ctx.user.name, status: "SIGNED" }).returning();
  await audit(ctx.hospital.id, ctx.user.id, "PRESCRIPTION_CREATED", row.id);
  return res.status(201).json(row);
});

router.get("/labs/orders", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = ListLabOrdersQueryParams.safeParse(req.query);
  const { page, pageSize, offset } = pageParams(req.query);
  const filter = and(eq(labOrders.hospitalId, ctx.hospital.id), parsed.success && parsed.data.status ? eq(labOrders.status, parsed.data.status) : undefined);
  const [rows, [{ value: total }]] = await Promise.all([db.select().from(labOrders).where(filter).orderBy(desc(labOrders.orderedAt)).limit(pageSize).offset(offset), db.select({ value: count() }).from(labOrders).where(filter)]);
  return res.json({ items: rows, page, pageSize, total: Number(total) });
});

router.post("/labs/orders", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "DOCTOR", "NURSE"].includes(ctx.user.role)) return fail(res, 403, "Only clinical staff can order labs", "FORBIDDEN");
  const parsed = CreateLabOrderBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Lab order details are invalid", "VALIDATION_ERROR");
  const [patient] = await db.select().from(patients).where(and(eq(patients.id, parsed.data.patientId), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
  if (!patient) return fail(res, 404, "Patient not found", "NOT_FOUND");
  const [row] = await db.insert(labOrders).values({ ...parsed.data, hospitalId: ctx.hospital.id, orderedById: ctx.user.id, patientName: patient.name, orderedBy: ctx.user.name, status: "ORDERED" }).returning();
  await audit(ctx.hospital.id, ctx.user.id, "LAB_ORDER_CREATED", row.id);
  return res.status(201).json(row);
});

router.get("/labs/catalog", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const q = typeof req.query.search === "string" ? req.query.search.trim() : "";
  const { page, pageSize, offset } = pageParams(req.query);
  const filter = and(eq(labTestCatalog.hospitalId, ctx.hospital.id), eq(labTestCatalog.active, true), q ? or(ilike(labTestCatalog.name, `%${q}%`), ilike(labTestCatalog.code, `%${q}%`)) : undefined);
  const [items, [{ value: total }]] = await Promise.all([
    db.select().from(labTestCatalog).where(filter).orderBy(asc(labTestCatalog.name)).limit(pageSize).offset(offset),
    db.select({ value: count() }).from(labTestCatalog).where(filter),
  ]);
  return res.json({ items, page, pageSize, total: Number(total) });
});

router.post("/labs/catalog", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "LAB_TECHNICIAN"].includes(ctx.user.role)) return fail(res, 403, "Only laboratory administrators can manage the test catalog", "FORBIDDEN");
  const { code, name, specimen, unit, referenceLow, referenceHigh } = req.body ?? {};
  if (typeof code !== "string" || typeof name !== "string" || code.length < 2 || name.length < 2) return fail(res, 400, "Test code and name are required", "VALIDATION_ERROR");
  const [item] = await db.insert(labTestCatalog).values({ hospitalId: ctx.hospital.id, code: code.trim().toUpperCase(), name: name.trim(), specimen: specimen || "Blood", unit, referenceLow: referenceLow == null ? null : String(referenceLow), referenceHigh: referenceHigh == null ? null : String(referenceHigh) }).returning();
  await audit(ctx.hospital.id, ctx.user.id, "LAB_TEST_CREATED", item.id);
  return res.status(201).json(item);
});

router.patch("/labs/orders/:orderId/status", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const allowedRoles = ["HOSPITAL_ADMIN", "DOCTOR", "NURSE", "LAB_TECHNICIAN"];
  if (!allowedRoles.includes(ctx.user.role)) return fail(res, 403, "You do not have permission to update lab status", "FORBIDDEN");
  const next = String(req.body?.status || "");
  const allowed = ["ORDERED", "SAMPLE_COLLECTED", "PROCESSING", "RESULT_READY", "APPROVED", "CANCELLED"];
  if (!allowed.includes(next)) return fail(res, 400, "Invalid lab status", "VALIDATION_ERROR");
  const [order] = await db.select().from(labOrders).where(and(eq(labOrders.id, req.params.orderId), eq(labOrders.hospitalId, ctx.hospital.id))).limit(1);
  if (!order) return fail(res, 404, "Lab order not found", "NOT_FOUND");
  const transition: Record<string, string[]> = { ORDERED: ["SAMPLE_COLLECTED", "CANCELLED"], SAMPLE_COLLECTED: ["PROCESSING", "CANCELLED"], PROCESSING: ["RESULT_READY", "CANCELLED"], RESULT_READY: ["APPROVED"], APPROVED: [], CANCELLED: [] };
  if (order.status !== next && !transition[order.status]?.includes(next)) return fail(res, 409, `Cannot move a lab order from ${order.status} to ${next}`, "INVALID_TRANSITION");
  if (next === "APPROVED" && ctx.user.role !== "DOCTOR" && ctx.user.role !== "HOSPITAL_ADMIN") return fail(res, 403, "Only a doctor or administrator can approve results", "FORBIDDEN");
  const [updated] = await db.update(labOrders).set({ status: next as typeof order.status }).where(eq(labOrders.id, order.id)).returning();
  if (next === "APPROVED") {
    await db.update(labResults).set({ reviewedById: ctx.user.id, approvedAt: new Date(), updatedAt: new Date() }).where(and(eq(labResults.hospitalId, ctx.hospital.id), eq(labResults.labOrderId, order.id)));
  }
  await audit(ctx.hospital.id, ctx.user.id, "LAB_STATUS_UPDATED", order.id);
  if (next === "APPROVED") {
    const [patient] = await db.select({ userId: patients.userId }).from(patients).where(eq(patients.id, order.patientId)).limit(1);
    if (patient.userId) await notifyUser(ctx.hospital.id, patient.userId, "Lab result approved", "A laboratory result is available in your patient portal.", "LAB_APPROVED");
  }
  return res.json(updated);
});

router.post("/labs/orders/:orderId/results", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "LAB_TECHNICIAN"].includes(ctx.user.role)) return fail(res, 403, "Only laboratory technicians can enter results", "FORBIDDEN");
  const [order] = await db.select().from(labOrders).where(and(eq(labOrders.id, req.params.orderId), eq(labOrders.hospitalId, ctx.hospital.id))).limit(1);
  if (!order) return fail(res, 404, "Lab order not found", "NOT_FOUND");
  const { analyte, value, numericValue, unit, referenceRange, abnormalFlag } = req.body ?? {};
  if (typeof analyte !== "string" || typeof value !== "string") return fail(res, 400, "Analyte and value are required", "VALIDATION_ERROR");
  const [result] = await db.insert(labResults).values({ hospitalId: ctx.hospital.id, labOrderId: order.id, analyte, value, numericValue: numericValue == null ? null : String(numericValue), unit, referenceRange, abnormalFlag, enteredById: ctx.user.id }).returning();
  await db.update(labOrders).set({ status: "RESULT_READY", result: value }).where(eq(labOrders.id, order.id));
  await audit(ctx.hospital.id, ctx.user.id, "LAB_RESULT_ENTERED", result.id);
  return res.status(201).json(result);
});

router.get("/labs/orders/:orderId/results", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const [order] = await db.select().from(labOrders).where(and(eq(labOrders.id, req.params.orderId), eq(labOrders.hospitalId, ctx.hospital.id))).limit(1);
  if (!order) return fail(res, 404, "Lab order not found", "NOT_FOUND");
  if (ctx.user.role === "PATIENT" && order.status !== "APPROVED") return fail(res, 403, "Results are not available yet", "FORBIDDEN");
  const items = await db.select().from(labResults).where(and(eq(labResults.hospitalId, ctx.hospital.id), eq(labResults.labOrderId, order.id))).orderBy(asc(labResults.createdAt));
  return res.json(items);
});

router.get("/pharmacy/medicines", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const q = typeof req.query.search === "string" ? req.query.search.trim() : "";
  const { page, pageSize, offset } = pageParams(req.query);
  const filter = and(eq(medicineCatalog.hospitalId, ctx.hospital.id), q ? or(ilike(medicineCatalog.name, `%${q}%`), ilike(medicineCatalog.genericName, `%${q}%`), ilike(medicineCatalog.sku, `%${q}%`)) : undefined);
  const [items, [{ value: total }]] = await Promise.all([db.select().from(medicineCatalog).where(filter).orderBy(asc(medicineCatalog.name)).limit(pageSize).offset(offset), db.select({ value: count() }).from(medicineCatalog).where(filter)]);
  return res.json({ items, page, pageSize, total: Number(total) });
});

router.post("/pharmacy/medicines", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "PHARMACIST"].includes(ctx.user.role)) return fail(res, 403, "Only pharmacy staff can manage medicines", "FORBIDDEN");
  const { sku, name, genericName, form, strength, reorderLevel } = req.body ?? {};
  if (![sku, name, form].every((value) => typeof value === "string" && value.trim())) return fail(res, 400, "SKU, name, and form are required", "VALIDATION_ERROR");
  const [item] = await db.insert(medicineCatalog).values({ hospitalId: ctx.hospital.id, sku: sku.trim().toUpperCase(), name: name.trim(), genericName, form, strength, reorderLevel: Number(reorderLevel ?? 10) }).returning();
  await audit(ctx.hospital.id, ctx.user.id, "MEDICINE_CREATED", item.id);
  return res.status(201).json(item);
});

router.post("/pharmacy/batches", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "PHARMACIST"].includes(ctx.user.role)) return fail(res, 403, "Only pharmacy staff can receive batches", "FORBIDDEN");
  const { medicineId, batchNumber, manufacturingDate, expiryDate, quantity, unitCost, mrp } = req.body ?? {};
  if (![medicineId, batchNumber, manufacturingDate, expiryDate, quantity, unitCost, mrp].every((value) => value !== undefined && value !== null && value !== "")) return fail(res, 400, "Complete batch details are required", "VALIDATION_ERROR");
  const [medicine] = await db.select().from(medicineCatalog).where(and(eq(medicineCatalog.id, medicineId), eq(medicineCatalog.hospitalId, ctx.hospital.id))).limit(1);
  if (!medicine) return fail(res, 404, "Medicine not found", "NOT_FOUND");
  const [batch] = await db.insert(medicineBatches).values({ hospitalId: ctx.hospital.id, medicineId, batchNumber, manufacturingDate, expiryDate, quantity: Number(quantity), unitCost: String(unitCost), mrp: String(mrp) }).returning();
  await db.insert(inventoryTransactions).values({ hospitalId: ctx.hospital.id, medicineId, batchId: batch.id, type: "RECEIPT", quantity: Number(quantity), reference: batchNumber, actorId: ctx.user.id });
  await audit(ctx.hospital.id, ctx.user.id, "MEDICINE_BATCH_RECEIVED", batch.id);
  return res.status(201).json(batch);
});

router.get("/pharmacy/alerts", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const batches = await db.select({ batch: medicineBatches, medicine: medicineCatalog }).from(medicineBatches).innerJoin(medicineCatalog, eq(medicineCatalog.id, medicineBatches.medicineId)).where(eq(medicineBatches.hospitalId, ctx.hospital.id));
  const today = new Date().toISOString().slice(0, 10);
  const nearExpiry = batches.filter(({ batch }) => batch.expiryDate <= new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10) && batch.expiryDate >= today && batch.quantity > 0);
  const lowStock = batches.filter(({ batch, medicine }) => batch.quantity <= medicine.reorderLevel);
  return res.json({ lowStock, nearExpiry });
});

router.post("/pharmacy/dispense", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "PHARMACIST"].includes(ctx.user.role)) return fail(res, 403, "Only pharmacy staff can dispense medicines", "FORBIDDEN");
  const { medicineId, quantity, patientId, prescriptionId } = req.body ?? {};
  const requested = Number(quantity);
  if (!medicineId || !Number.isInteger(requested) || requested <= 0) return fail(res, 400, "Medicine and a positive whole quantity are required", "VALIDATION_ERROR");
  const [medicine] = await db.select().from(medicineCatalog).where(and(eq(medicineCatalog.id, medicineId), eq(medicineCatalog.hospitalId, ctx.hospital.id))).limit(1);
  if (!medicine) return fail(res, 404, "Medicine not found", "NOT_FOUND");
  const today = new Date().toISOString().slice(0, 10);
  const batches = await db.select().from(medicineBatches).where(and(eq(medicineBatches.hospitalId, ctx.hospital.id), eq(medicineBatches.medicineId, medicineId), gte(medicineBatches.expiryDate, today), sql`${medicineBatches.quantity} > 0`)).orderBy(asc(medicineBatches.expiryDate));
  if (batches.reduce((sumValue, batch) => sumValue + batch.quantity, 0) < requested) return fail(res, 409, "Insufficient non-expired stock", "INSUFFICIENT_STOCK");
  const result = await db.transaction(async (tx) => {
    let remaining = requested;
    const used: Array<{ batchId: string; quantity: number }> = [];
    for (const batch of batches) {
      if (remaining <= 0) break;
      const take = Math.min(remaining, batch.quantity);
      await tx.update(medicineBatches).set({ quantity: sql`${medicineBatches.quantity} - ${take}`, updatedAt: new Date() }).where(and(eq(medicineBatches.id, batch.id), eq(medicineBatches.hospitalId, ctx.hospital.id), gte(medicineBatches.quantity, take)));
      await tx.insert(inventoryTransactions).values({ hospitalId: ctx.hospital.id, medicineId, batchId: batch.id, type: "DISPENSE", quantity: -take, reference: prescriptionId || patientId || "PHARMACY", actorId: ctx.user.id });
      used.push({ batchId: batch.id, quantity: take });
      remaining -= take;
    }
    return used;
  });
  await audit(ctx.hospital.id, ctx.user.id, "MEDICINE_DISPENSED", medicineId);
  return res.status(201).json({ medicineId, quantity: requested, batches: result });
});

router.get("/invoices", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = ListInvoicesQueryParams.safeParse(req.query);
  const { page, pageSize, offset } = pageParams(req.query);
  const filter = and(eq(invoices.hospitalId, ctx.hospital.id), parsed.success && parsed.data.status ? eq(invoices.status, parsed.data.status) : undefined, parsed.success && parsed.data.search ? or(ilike(invoices.patientName, `%${parsed.data.search}%`), ilike(invoices.invoiceNumber, `%${parsed.data.search}%`)) : undefined);
  const [rows, [{ value: total }]] = await Promise.all([db.select().from(invoices).where(filter).orderBy(desc(invoices.issueDate)).limit(pageSize).offset(offset), db.select({ value: count() }).from(invoices).where(filter)]);
  return res.json({ items: rows.map((row) => ({ ...row, total: Number(row.total), paid: Number(row.paid) })), page, pageSize, total: Number(total) });
});

router.get("/invoices/:invoiceId", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const [invoice] = await db.select().from(invoices).where(and(eq(invoices.id, req.params.invoiceId), eq(invoices.hospitalId, ctx.hospital.id))).limit(1);
  if (!invoice) return fail(res, 404, "Invoice not found", "NOT_FOUND");
  if (ctx.user.role === "PATIENT") {
    const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
    if (!patient || patient.id !== invoice.patientId) return fail(res, 403, "You cannot access this invoice", "FORBIDDEN");
  }
  const [items, paymentRows] = await Promise.all([
    db.select().from(invoiceItems).where(and(eq(invoiceItems.invoiceId, invoice.id), eq(invoiceItems.hospitalId, ctx.hospital.id))),
    db.select().from(payments).where(and(eq(payments.invoiceId, invoice.id), eq(payments.hospitalId, ctx.hospital.id))).orderBy(desc(payments.paidAt)),
  ]);
  return res.json({ ...invoice, total: Number(invoice.total), paid: Number(invoice.paid), items, payments: paymentRows });
});

router.post("/invoices", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "RECEPTIONIST", "ACCOUNTANT"].includes(ctx.user.role)) return fail(res, 403, "Only authorized billing staff can create invoices", "FORBIDDEN");
  const { patientId, dueDate, status = "DRAFT", items = [] } = req.body ?? {};
  if (!patientId || !Array.isArray(items) || !items.length) return fail(res, 400, "Patient and at least one invoice item are required", "VALIDATION_ERROR");
  const [patient] = await db.select().from(patients).where(and(eq(patients.id, patientId), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
  if (!patient) return fail(res, 404, "Patient not found", "NOT_FOUND");
  const normalized = items.map((item: { category?: string; description?: string; quantity?: number; unitPrice?: number }) => {
    const quantity = Number(item.quantity ?? 1);
    const unitPrice = Number(item.unitPrice ?? 0);
    return { category: item.category || "OTHER", description: String(item.description || "Hospital service"), quantity, unitPrice, total: quantity * unitPrice };
  });
  if (normalized.some((item) => !Number.isFinite(item.quantity) || item.quantity <= 0 || !Number.isFinite(item.unitPrice) || item.unitPrice < 0)) return fail(res, 400, "Invoice amounts are invalid", "VALIDATION_ERROR");
  const total = normalized.reduce((sumValue, item) => sumValue + item.total, 0);
  const invoiceNumber = `INV-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
  const [invoice] = await db.insert(invoices).values({ hospitalId: ctx.hospital.id, patientId, patientName: patient.name, invoiceNumber, issueDate: new Date().toISOString().slice(0, 10), dueDate: dueDate || new Date(Date.now() + 15 * 86400000).toISOString().slice(0, 10), total: total.toFixed(2), paid: "0", status }).returning();
  await db.insert(invoiceItems).values(normalized.map((item) => ({ hospitalId: ctx.hospital.id, invoiceId: invoice.id, category: item.category, description: item.description, quantity: String(item.quantity), unitPrice: item.unitPrice.toFixed(2), total: item.total.toFixed(2) })));
  await audit(ctx.hospital.id, ctx.user.id, "INVOICE_CREATED", invoice.id);
  if (patient.userId) await notifyUser(ctx.hospital.id, patient.userId, "Invoice generated", `A new invoice ${invoice.invoiceNumber} is available in your portal.`, "INVOICE");
  return res.status(201).json({ ...invoice, total, paid: 0, items: normalized });
});

router.post("/invoices/:invoiceId/payments", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "RECEPTIONIST", "ACCOUNTANT"].includes(ctx.user.role)) return fail(res, 403, "Only authorized billing staff can record payments", "FORBIDDEN");
  const amount = Number(req.body?.amount);
  const method = String(req.body?.method || "");
  if (!Number.isFinite(amount) || amount <= 0 || !method) return fail(res, 400, "A positive amount and payment method are required", "VALIDATION_ERROR");
  const [invoice] = await db.select().from(invoices).where(and(eq(invoices.id, req.params.invoiceId), eq(invoices.hospitalId, ctx.hospital.id))).limit(1);
  if (!invoice) return fail(res, 404, "Invoice not found", "NOT_FOUND");
  const pendingGatewayPayment = await db.select({ id: paymentOrders.id }).from(paymentOrders).where(and(eq(paymentOrders.invoiceId, invoice.id), eq(paymentOrders.hospitalId, ctx.hospital.id), inArray(paymentOrders.status, ["CREATED", "PENDING"]))).limit(1);
  if (pendingGatewayPayment.length) return fail(res, 409, "An online payment is already in progress for this invoice", "PAYMENT_PENDING");
  const outstanding = Number(invoice.total) - Number(invoice.paid);
  if (amount > outstanding) return fail(res, 409, "Payment exceeds the outstanding invoice balance", "OVERPAYMENT");
  const payment = await db.transaction(async (tx) => {
    const [created] = await tx.insert(payments).values({ hospitalId: ctx.hospital.id, invoiceId: invoice.id, patientId: invoice.patientId, amount: amount.toFixed(2), method, reference: req.body?.reference, receivedById: ctx.user.id }).returning();
    const paid = Number(invoice.paid) + amount;
    await tx.update(invoices).set({ paid: paid.toFixed(2), status: paid >= Number(invoice.total) ? "PAID" : "PARTIALLY_PAID" }).where(and(eq(invoices.id, invoice.id), eq(invoices.hospitalId, ctx.hospital.id)));
    return created;
  });
  await audit(ctx.hospital.id, ctx.user.id, "PAYMENT_RECORDED", payment.id);
  const [patient] = await db.select({ userId: patients.userId }).from(patients).where(eq(patients.id, invoice.patientId)).limit(1);
  if (patient.userId) await notifyUser(ctx.hospital.id, patient.userId, "Payment received", `Your payment for invoice ${invoice.invoiceNumber} was recorded.`, "PAYMENT");
  return res.status(201).json(payment);
});

router.get("/invoices/:invoiceId/pdf", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  await renderInvoicePdf(ctx, req.params.invoiceId, res);
});

router.get("/portal/invoices/:invoiceId/pdf", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  await renderInvoicePdf(ctx, req.params.invoiceId, res);
});

router.get("/prescriptions/:prescriptionId/pdf", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  await renderPrescriptionPdf(ctx, req.params.prescriptionId, res);
});

router.get("/portal/prescriptions/:prescriptionId/pdf", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  await renderPrescriptionPdf(ctx, req.params.prescriptionId, res);
});

function safeAttachmentName(value: string) {
  const leafName = value.split(/[\\/]/).pop() || "attachment";
  return leafName.replace(/[^\w.-]/g, "_").slice(-180) || "attachment";
}

function verifyUploadedContent(mime: string, buffer: Buffer) {
  if (mime === "application/pdf") return buffer.subarray(0, 5).toString("ascii") === "%PDF-";
  if (mime === "image/png") return buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  if (mime === "image/jpeg") return buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  if (mime === "text/plain" || mime === "text/csv") {
    if (buffer.includes(0)) return false;
    try { new TextDecoder("utf-8", { fatal: true }).decode(buffer); return true; } catch { return false; }
  }
  return false;
}

function attachmentView(row: typeof fileAttachments.$inferSelect) {
  return {
    id: row.id,
    patientId: row.patientId,
    fileName: row.fileName,
    mimeType: row.mimeType,
    sizeBytes: row.sizeBytes,
    createdAt: row.createdAt,
  };
}

router.post("/storage/uploads/request-url", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (ctx.user.role === "PATIENT") return fail(res, 403, "Patients cannot upload clinical attachments here", "FORBIDDEN");
  const parsed = RequestUploadUrlBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Upload details are invalid", "VALIDATION_ERROR");
  const { name, size, contentType, patientId } = parsed.data;
  if (!allowedAttachmentMimeTypes.has(contentType.toLowerCase()) || size > 10 * 1024 * 1024) {
    return fail(res, 415, "Accepted file types are PDF, PNG, JPEG, plain text, and CSV up to 10 MB", "UNSUPPORTED_FILE_TYPE");
  }
  if (patientId) {
    const [patient] = await db.select({ id: patients.id }).from(patients).where(and(eq(patients.id, patientId), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
    if (!patient) return fail(res, 404, "Patient not found in this hospital", "NOT_FOUND");
  }
  const now = Date.now();
  const rate = attachmentUploadAttempts.get(ctx.user.id);
  if (rate && rate.resetAt > now && rate.count >= 20) return fail(res, 429, "Upload limit reached; try again in one minute", "RATE_LIMITED");
  if (!rate || rate.resetAt <= now) attachmentUploadAttempts.set(ctx.user.id, { count: 1, resetAt: now + 60_000 });
  else rate.count += 1;
  const cleanName = safeAttachmentName(name);
  const uploadURL = await objectStorage.getObjectEntityUploadURL();
  const objectPath = objectStorage.normalizeObjectEntityPath(uploadURL);
  const expiresAt = new Date(now + 15 * 60_000);
  const [intent] = await db.insert(fileUploadIntents).values({
    hospitalId: ctx.hospital.id,
    userId: ctx.user.id,
    patientId: patientId || null,
    objectPath,
    fileName: cleanName,
    mimeType: contentType.toLowerCase(),
    sizeBytes: size,
    expiresAt,
  }).returning();
  return res.json(RequestUploadUrlResponse.parse({ uploadURL, objectPath, uploadIntentId: intent.id, expiresAt }));
});

router.post("/attachments", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  if (ctx.user.role === "PATIENT") return fail(res, 403, "Patients cannot upload clinical attachments here", "FORBIDDEN");
  const parsed = CreateAttachmentBody.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Upload completion details are invalid", "VALIDATION_ERROR");
  const [intent] = await db.select().from(fileUploadIntents).where(and(
    eq(fileUploadIntents.id, parsed.data.uploadIntentId),
    eq(fileUploadIntents.hospitalId, ctx.hospital.id),
    eq(fileUploadIntents.userId, ctx.user.id),
    isNull(fileUploadIntents.completedAt),
    gt(fileUploadIntents.expiresAt, new Date()),
  )).limit(1);
  if (!intent) return fail(res, 404, "Upload request not found, expired, or already completed", "UPLOAD_INTENT_UNAVAILABLE");
  let objectFile;
  try {
    objectFile = await objectStorage.getObjectEntityFile(intent.objectPath);
  } catch (error) {
    if (error instanceof ObjectNotFoundError) return fail(res, 409, "The file has not finished uploading", "UPLOAD_NOT_FINISHED");
    throw error;
  }
  const [metadata] = await objectFile.getMetadata();
  const storedSize = Number(metadata.size);
  const storedMimeType = String(metadata.contentType || "").split(";")[0].toLowerCase();
  if (storedSize !== intent.sizeBytes || storedMimeType !== intent.mimeType) {
    return fail(res, 415, "Uploaded file type or size does not match the request", "UPLOAD_METADATA_MISMATCH");
  }
  const [content] = await objectFile.download();
  if (!verifyUploadedContent(intent.mimeType, content)) {
    return fail(res, 415, "Uploaded file content does not match its declared type", "INVALID_FILE_CONTENT");
  }
  await objectStorage.setPrivateOwner(intent.objectPath, ctx.user.id);
  let attachment: typeof fileAttachments.$inferSelect;
  try {
    attachment = await db.transaction(async (tx) => {
      const [claimed] = await tx.update(fileUploadIntents).set({ completedAt: new Date() }).where(and(
        eq(fileUploadIntents.id, intent.id),
        eq(fileUploadIntents.hospitalId, ctx.hospital.id),
        eq(fileUploadIntents.userId, ctx.user.id),
        isNull(fileUploadIntents.completedAt),
        gt(fileUploadIntents.expiresAt, new Date()),
      )).returning();
      if (!claimed) throw new Error("UPLOAD_INTENT_UNAVAILABLE");
      const [row] = await tx.insert(fileAttachments).values({
        hospitalId: ctx.hospital.id,
        patientId: intent.patientId,
        uploadedById: ctx.user.id,
        objectPath: intent.objectPath,
        fileName: intent.fileName,
        mimeType: intent.mimeType,
        sizeBytes: intent.sizeBytes,
      }).returning();
      return row;
    });
  } catch (error) {
    if (error instanceof Error && error.message === "UPLOAD_INTENT_UNAVAILABLE") {
      return fail(res, 409, "Upload request has already been completed", "UPLOAD_INTENT_UNAVAILABLE");
    }
    throw error;
  }
  await audit(ctx.hospital.id, ctx.user.id, "ATTACHMENT_UPLOADED", attachment.id);
  return res.status(201).json(ListAttachmentsResponseItem.parse(attachmentView(attachment)));
});

router.get("/attachments", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = ListAttachmentsQueryParams.safeParse(req.query);
  if (!parsed.success) return fail(res, 400, "Attachment query is invalid", "VALIDATION_ERROR");
  const rows = await db.select().from(fileAttachments).where(parsed.data.patientId
    ? and(eq(fileAttachments.hospitalId, ctx.hospital.id), eq(fileAttachments.patientId, parsed.data.patientId))
    : eq(fileAttachments.hospitalId, ctx.hospital.id))
    .orderBy(desc(fileAttachments.createdAt)).limit(100);
  return res.json(ListAttachmentsResponse.parse(rows.map(attachmentView)));
});

router.get("/portal/attachments", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
  if (!patient) return fail(res, 404, "Patient profile not found", "NOT_FOUND");
  const rows = await db.select().from(fileAttachments).where(and(
    eq(fileAttachments.hospitalId, ctx.hospital.id),
    eq(fileAttachments.patientId, patient.id),
  )).orderBy(desc(fileAttachments.createdAt)).limit(100);
  return res.json(ListAttachmentsResponse.parse(rows.map(attachmentView)));
});

async function downloadAttachment(ctx: { user: typeof users.$inferSelect; hospital: typeof hospitals.$inferSelect }, id: string, res: Response) {
  const [attachment] = await db.select().from(fileAttachments).where(and(eq(fileAttachments.id, id), eq(fileAttachments.hospitalId, ctx.hospital.id))).limit(1);
  if (!attachment) return fail(res, 404, "Attachment not found", "NOT_FOUND");
  if (ctx.user.role === "PATIENT") {
    const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
    if (!patient || attachment.patientId !== patient.id) return fail(res, 403, "You cannot access this attachment", "FORBIDDEN");
  }
  try {
    const objectFile = await objectStorage.getObjectEntityFile(attachment.objectPath);
    const [metadata] = await objectFile.getMetadata();
    res.setHeader("Content-Type", attachment.mimeType);
    if (metadata.size) res.setHeader("Content-Length", String(metadata.size));
    res.setHeader("Content-Disposition", `attachment; filename="${attachment.fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}"`);
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    await audit(ctx.hospital.id, ctx.user.id, "ATTACHMENT_DOWNLOADED", attachment.id);
    objectFile.createReadStream().on("error", (error) => {
      if (!res.headersSent) fail(res, 404, "Attachment content is unavailable", "ATTACHMENT_MISSING");
      else res.destroy(error);
    }).pipe(res);
  } catch (error) {
    if (error instanceof ObjectNotFoundError) return fail(res, 404, "Attachment content is unavailable", "ATTACHMENT_MISSING");
    throw error;
  }
  return undefined;
}

router.get("/attachments/:attachmentId", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  await downloadAttachment(ctx, req.params.attachmentId, res);
});

router.get("/portal/attachments/:attachmentId", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  await downloadAttachment(ctx, req.params.attachmentId, res);
});

router.get("/payments", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const { page, pageSize, offset } = pageParams(req.query);
  const rows = await db.select().from(payments).where(eq(payments.hospitalId, ctx.hospital.id)).orderBy(desc(payments.paidAt)).limit(pageSize).offset(offset);
  return res.json({ items: rows, page, pageSize });
});

router.get("/notifications", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = ListNotificationsQueryParams.safeParse(req.query);
  const limit = parsed.success ? parsed.data.pageSize : 20;
  const rows = await db.select().from(notifications).where(eq(notifications.userId, ctx.user.id)).orderBy(desc(notifications.createdAt)).limit(limit);
  return res.json(rows);
});

router.patch("/notifications/:notificationId/read", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const [updated] = await db.update(notifications).set({ read: true }).where(and(eq(notifications.id, req.params.notificationId), eq(notifications.userId, ctx.user.id), eq(notifications.hospitalId, ctx.hospital.id))).returning();
  if (!updated) return fail(res, 404, "Notification not found", "NOT_FOUND");
  return res.json(updated);
});

router.put("/notifications/preferences", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const { channel, eventType, enabled } = req.body ?? {};
  if (!["IN_APP", "EMAIL", "SMS"].includes(channel) || typeof eventType !== "string" || typeof enabled !== "boolean") return fail(res, 400, "Notification preference is invalid", "VALIDATION_ERROR");
  const [existing] = await db.select().from(notificationPreferences).where(and(eq(notificationPreferences.userId, ctx.user.id), eq(notificationPreferences.channel, channel), eq(notificationPreferences.eventType, eventType))).limit(1);
  const [row] = existing
    ? await db.update(notificationPreferences).set({ enabled, updatedAt: new Date() }).where(eq(notificationPreferences.id, existing.id)).returning()
    : await db.insert(notificationPreferences).values({ hospitalId: ctx.hospital.id, userId: ctx.user.id, channel, eventType, enabled }).returning();
  return res.json(row);
});

router.get("/portal/profile", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
  if (!patient) return fail(res, 404, "Patient profile not found", "NOT_FOUND");
  return res.json(patientView(patient));
});

router.get("/portal/appointments", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
  if (!patient) return fail(res, 404, "Patient profile not found", "NOT_FOUND");
  const rows = await db.select().from(appointments).where(and(eq(appointments.hospitalId, ctx.hospital.id), eq(appointments.patientId, patient.id), sql`${appointments.deletedAt} is null`)).orderBy(desc(appointments.startsAt));
  return res.json(rows.map(appointmentView));
});

router.get("/portal/records", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
  if (!patient) return fail(res, 404, "Patient profile not found", "NOT_FOUND");
  return res.json(await db.select().from(medicalRecords).where(and(eq(medicalRecords.hospitalId, ctx.hospital.id), eq(medicalRecords.patientId, patient.id))).orderBy(desc(medicalRecords.createdAt)));
});

router.get("/portal/prescriptions", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
  if (!patient) return fail(res, 404, "Patient profile not found", "NOT_FOUND");
  return res.json(await db.select().from(prescriptions).where(and(eq(prescriptions.hospitalId, ctx.hospital.id), eq(prescriptions.patientId, patient.id))).orderBy(desc(prescriptions.issuedAt)));
});

router.get("/portal/labs", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
  if (!patient) return fail(res, 404, "Patient profile not found", "NOT_FOUND");
  const orders = await db.select().from(labOrders).where(and(eq(labOrders.hospitalId, ctx.hospital.id), eq(labOrders.patientId, patient.id), eq(labOrders.status, "APPROVED"))).orderBy(desc(labOrders.orderedAt));
  const results = orders.length ? await db.select().from(labResults).where(and(eq(labResults.hospitalId, ctx.hospital.id), sql`${labResults.labOrderId} in ${sql.join(orders.map((order) => sql`${order.id}`), sql`, `)}`)) : [];
  return res.json({ orders, results });
});

router.get("/portal/invoices", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const patient = await patientForUser(ctx.user.id, ctx.hospital.id);
  if (!patient) return fail(res, 404, "Patient profile not found", "NOT_FOUND");
  return res.json(await db.select().from(invoices).where(and(eq(invoices.hospitalId, ctx.hospital.id), eq(invoices.patientId, patient.id))).orderBy(desc(invoices.issueDate)));
});

router.get("/portal/notifications", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  return res.json(await db.select().from(notifications).where(and(eq(notifications.hospitalId, ctx.hospital.id), eq(notifications.userId, ctx.user.id))).orderBy(desc(notifications.createdAt)).limit(50));
});

router.get("/search", async (req, res) => {
  const ctx = await context(req, res);
  if (!ctx) return;
  const parsed = SearchAllQueryParams.safeParse(req.query);
  if (!parsed.success) return fail(res, 400, "Search requires at least two characters", "VALIDATION_ERROR");
  const term = `%${parsed.data.q}%`;
  const [patientRows, appointmentRows, recordRows, invoiceRows] = await Promise.all([
    db.select({ id: patients.id, title: patients.name, subtitle: patients.mrn }).from(patients).where(and(eq(patients.hospitalId, ctx.hospital.id), sql`${patients.deletedAt} is null`, or(ilike(patients.name, term), ilike(patients.mrn, term)))).limit(5),
    db.select({ id: appointments.id, title: appointments.patientName, subtitle: appointments.doctorName }).from(appointments).where(and(eq(appointments.hospitalId, ctx.hospital.id), ilike(appointments.patientName, term))).limit(5),
    db.select({ id: medicalRecords.id, title: medicalRecords.patientName, subtitle: medicalRecords.diagnosis }).from(medicalRecords).where(and(eq(medicalRecords.hospitalId, ctx.hospital.id), or(ilike(medicalRecords.patientName, term), ilike(medicalRecords.diagnosis, term)))).limit(5),
    db.select({ id: invoices.id, title: invoices.invoiceNumber, subtitle: invoices.patientName }).from(invoices).where(and(eq(invoices.hospitalId, ctx.hospital.id), or(ilike(invoices.invoiceNumber, term), ilike(invoices.patientName, term)))).limit(5),
  ]);
  return res.json([
    ...patientRows.map((row) => ({ ...row, kind: "Patient", href: `/patients/${row.id}` })),
    ...appointmentRows.map((row) => ({ ...row, kind: "Appointment", href: "/appointments" })),
    ...recordRows.map((row) => ({ ...row, kind: "Medical record", href: "/records" })),
    ...invoiceRows.map((row) => ({ ...row, kind: "Invoice", href: "/billing" })),
  ]);
});

export default router;