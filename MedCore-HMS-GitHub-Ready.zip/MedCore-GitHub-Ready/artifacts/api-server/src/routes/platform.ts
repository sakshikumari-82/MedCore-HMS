import { and, asc, count, desc, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import QRCode from "qrcode";
import PDFDocument from "pdfkit";
import { Router, type Request, type Response } from "express";
import {
  auditLogs,
  appointments,
  db,
  hospitals,
  hospitalSubscriptions,
  invoices,
  notificationPreferences,
  paymentOrders,
  paymentWebhookEvents,
  payments,
  patients,
  qrAuditEvents,
  secureQrTokens,
  subscriptionInvoices,
  subscriptionPayments,
  subscriptionPlans,
  users,
} from "@workspace/db";
import { getCurrentUser } from "../lib/session";
import { hmacSha256, sha256, verifyHmacSha256 } from "../lib/payment-security";
import { logger } from "../lib/logger";

const router = Router();
const supportedRoles = {
  hospitalAdmin: ["HOSPITAL_ADMIN", "SUPER_ADMIN"],
  biller: ["HOSPITAL_ADMIN", "RECEPTIONIST", "ACCOUNTANT"],
  qrIssuer: ["HOSPITAL_ADMIN", "DOCTOR", "NURSE", "RECEPTIONIST"],
  qrScanner: ["HOSPITAL_ADMIN", "DOCTOR", "NURSE", "RECEPTIONIST"],
} as const;

function fail(res: Response, status: number, error: string, code?: string) {
  return res.status(status).json({ error, ...(code ? { code } : {}) });
}

async function loadContext(req: Request, res: Response) {
  const user = await getCurrentUser(req);
  if (!user) {
    fail(res, 401, "Authentication required", "AUTH_REQUIRED");
    return null;
  }
  if (!user.hospitalId) {
    fail(res, 403, "Hospital context required", "HOSPITAL_REQUIRED");
    return null;
  }
  const [hospital] = await db.select().from(hospitals).where(eq(hospitals.id, user.hospitalId)).limit(1);
  if (!hospital) {
    fail(res, 403, "Hospital access is not available", "HOSPITAL_UNAVAILABLE");
    return null;
  }
  return { user, hospital };
}

async function audit(hospitalId: string | null, actorId: string | null, action: string, target?: string, metadata?: Record<string, unknown>) {
  await db.insert(auditLogs).values({ hospitalId, actorId, action, target, metadata });
}

function configuredProvider(): "razorpay" | "sandbox" | "disabled" {
  if (process.env.PAYMENT_PROVIDER === "razorpay") return "razorpay";
  if (process.env.PAYMENT_PROVIDER === "sandbox") return process.env.NODE_ENV === "production" ? "disabled" : "sandbox";
  return process.env.NODE_ENV === "production" ? "disabled" : "sandbox";
}

function razorpayReady() {
  return Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET && process.env.RAZORPAY_WEBHOOK_SECRET);
}

async function razorpayRequest(path: string, body: Record<string, unknown>, idempotencyKey: string) {
  const key = process.env.RAZORPAY_KEY_ID;
  const secret = process.env.RAZORPAY_KEY_SECRET;
  if (!key || !secret) throw new Error("Razorpay checkout is not configured");
  const response = await fetch(`https://api.razorpay.com/v1${path}`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${key}:${secret}`).toString("base64")}`,
      "Content-Type": "application/json",
      "Idempotency-Key": idempotencyKey,
    },
    body: JSON.stringify(body),
  });
  const result = await response.json() as Record<string, unknown>;
  if (!response.ok) {
    logger.warn({ status: response.status, path }, "Razorpay API request rejected");
    throw new Error("Payment provider could not create the order");
  }
  return result;
}

async function razorpayGet(path: string) {
  const key = process.env.RAZORPAY_KEY_ID;
  const secret = process.env.RAZORPAY_KEY_SECRET;
  if (!key || !secret) throw new Error("Razorpay checkout is not configured");
  const response = await fetch(`https://api.razorpay.com/v1${path}`, {
    headers: { Authorization: `Basic ${Buffer.from(`${key}:${secret}`).toString("base64")}` },
  });
  const result = await response.json() as Record<string, any>;
  if (!response.ok) {
    logger.warn({ status: response.status, path }, "Razorpay reconciliation request rejected");
    throw new Error("Payment provider reconciliation failed");
  }
  return result;
}

function paise(amount: string | number) {
  return Math.round(Number(amount) * 100);
}

function safeOrderView(order: typeof paymentOrders.$inferSelect) {
  return {
    id: order.id,
    scope: order.scope,
    invoiceId: order.invoiceId,
    subscriptionId: order.subscriptionId,
    planId: order.planId,
    billingCycle: order.billingCycle,
    provider: order.provider,
    providerOrderId: order.providerOrderId,
    status: order.status,
    method: order.method,
    amount: Number(order.amount),
    currency: order.currency,
    qrPayload: order.qrPayload,
    qrImageUrl: order.qrImageUrl,
    expiresAt: order.expiresAt,
    succeededAt: order.succeededAt,
    createdAt: order.createdAt,
  };
}

async function authorizePaymentOrder(req: Request, res: Response, orderId: string) {
  const ctx = await loadContext(req, res);
  if (!ctx) return null;
  const [order] = await db.select().from(paymentOrders).where(and(eq(paymentOrders.id, orderId), eq(paymentOrders.hospitalId, ctx.hospital.id))).limit(1);
  if (!order) {
    fail(res, 404, "Payment order not found", "NOT_FOUND");
    return null;
  }
  if (order.scope === "SUBSCRIPTION") {
    if (!supportedRoles.hospitalAdmin.includes(ctx.user.role as "HOSPITAL_ADMIN" | "SUPER_ADMIN")) {
      fail(res, 403, "Only hospital administrators can access subscription payments", "FORBIDDEN");
      return null;
    }
  } else if (ctx.user.role === "PATIENT") {
    const [patient] = await db.select({ id: patients.id }).from(patients).where(and(eq(patients.userId, ctx.user.id), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
    if (!patient || patient.id !== (await db.select({ patientId: invoices.patientId }).from(invoices).where(and(eq(invoices.id, order.invoiceId!), eq(invoices.hospitalId, ctx.hospital.id))).limit(1))[0]?.patientId) {
      fail(res, 403, "You cannot access this payment order", "FORBIDDEN");
      return null;
    }
  } else if (!supportedRoles.biller.includes(ctx.user.role as "HOSPITAL_ADMIN" | "RECEPTIONIST" | "ACCOUNTANT")) {
    fail(res, 403, "You do not have permission to access invoice payments", "FORBIDDEN");
    return null;
  }
  return { ...ctx, order };
}

async function createOrder(req: Request, res: Response, scope: "HOSPITAL_INVOICE" | "SUBSCRIPTION") {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  const idempotencyKey = String(req.get("Idempotency-Key") || req.body?.idempotencyKey || "").trim();
  if (idempotencyKey.length < 8 || idempotencyKey.length > 120) {
    fail(res, 400, "Supply an Idempotency-Key between 8 and 120 characters", "VALIDATION_ERROR");
    return;
  }
  const provider = configuredProvider();
  if (provider === "disabled" || (provider === "razorpay" && !razorpayReady())) {
    fail(res, 503, "Payment checkout requires provider credentials; no payment was created", "PAYMENT_CONFIGURATION_REQUIRED");
    return;
  }

  let invoiceId: string | null = null;
  let planId: string | null = null;
  let subscriptionId: string | null = null;
  let cycle: "MONTHLY" | "ANNUAL" | null = null;
  let amount = 0;
  let currency = "INR";
  if (scope === "HOSPITAL_INVOICE") {
    if (ctx.user.role === "PATIENT") {
      const [patient] = await db.select({ id: patients.id }).from(patients).where(and(eq(patients.userId, ctx.user.id), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
      if (!patient) {
        fail(res, 404, "Patient profile not found", "NOT_FOUND");
        return;
      }
      const [invoice] = await db.select().from(invoices).where(and(eq(invoices.id, String(req.body?.invoiceId || "")), eq(invoices.hospitalId, ctx.hospital.id), eq(invoices.patientId, patient.id))).limit(1);
      if (!invoice) {
        fail(res, 404, "Invoice not found", "NOT_FOUND");
        return;
      }
      invoiceId = invoice.id;
      amount = Number(invoice.total) - Number(invoice.paid);
    } else {
      if (!supportedRoles.biller.includes(ctx.user.role as "HOSPITAL_ADMIN" | "RECEPTIONIST" | "ACCOUNTANT")) {
        fail(res, 403, "You do not have permission to create invoice payments", "FORBIDDEN");
        return;
      }
      const [invoice] = await db.select().from(invoices).where(and(eq(invoices.id, String(req.body?.invoiceId || "")), eq(invoices.hospitalId, ctx.hospital.id))).limit(1);
      if (!invoice) {
        fail(res, 404, "Invoice not found", "NOT_FOUND");
        return;
      }
      invoiceId = invoice.id;
      amount = Number(invoice.total) - Number(invoice.paid);
    }
    if (amount <= 0) {
      fail(res, 409, "Invoice has no outstanding balance", "INVOICE_PAID");
      return;
    }
    const pending = await db.select({ id: paymentOrders.id }).from(paymentOrders).where(and(eq(paymentOrders.hospitalId, ctx.hospital.id), eq(paymentOrders.invoiceId, invoiceId), inArray(paymentOrders.status, ["CREATED", "PENDING"]))).limit(1);
    if (pending.length) {
      fail(res, 409, "An invoice payment is already in progress", "PAYMENT_PENDING");
      return;
    }
  } else {
    if (!supportedRoles.hospitalAdmin.includes(ctx.user.role as "HOSPITAL_ADMIN" | "SUPER_ADMIN")) {
      fail(res, 403, "Only hospital administrators can purchase a subscription", "FORBIDDEN");
      return;
    }
    const cycleInput = String(req.body?.billingCycle || "").toUpperCase();
    if (cycleInput !== "MONTHLY" && cycleInput !== "ANNUAL") {
      fail(res, 400, "Choose MONTHLY or ANNUAL billing", "VALIDATION_ERROR");
      return;
    }
    cycle = cycleInput;
    const [plan] = await db.select().from(subscriptionPlans).where(and(eq(subscriptionPlans.id, String(req.body?.planId || "")), eq(subscriptionPlans.active, true))).limit(1);
    if (!plan) {
      fail(res, 404, "Subscription plan not found", "NOT_FOUND");
      return;
    }
    planId = plan.id;
    amount = Number(cycle === "MONTHLY" ? plan.monthlyPrice : plan.annualPrice);
    const [current] = await db.select().from(hospitalSubscriptions).where(and(eq(hospitalSubscriptions.hospitalId, ctx.hospital.id), inArray(hospitalSubscriptions.status, ["TRIAL", "ACTIVE", "PAST_DUE"]))).orderBy(desc(hospitalSubscriptions.createdAt)).limit(1);
    subscriptionId = current?.id ?? null;
  }
  const existing = await db.select().from(paymentOrders).where(and(eq(paymentOrders.hospitalId, ctx.hospital.id), eq(paymentOrders.idempotencyKey, idempotencyKey))).limit(1);
  if (existing.length) {
    const prior = existing[0]!;
    if (prior.scope !== scope || prior.invoiceId !== invoiceId || prior.planId !== planId || prior.billingCycle !== cycle || Number(prior.amount) !== amount) {
      fail(res, 409, "Idempotency key was already used for a different payment", "IDEMPOTENCY_CONFLICT");
      return;
    }
    res.json(safeOrderView(prior));
    return;
  }

  const expiry = new Date(Date.now() + 15 * 60 * 1000);
  let [order] = await db.insert(paymentOrders).values({
    hospitalId: ctx.hospital.id,
    scope,
    invoiceId,
    subscriptionId,
    planId,
    billingCycle: cycle,
    provider,
    idempotencyKey,
    amount: amount.toFixed(2),
    currency,
    status: "CREATED",
    createdById: ctx.user.id,
    expiresAt: expiry,
  }).onConflictDoNothing().returning();
  if (!order) {
    const [prior] = await db.select().from(paymentOrders).where(and(eq(paymentOrders.hospitalId, ctx.hospital.id), eq(paymentOrders.idempotencyKey, idempotencyKey))).limit(1);
    if (prior && prior.scope === scope && prior.invoiceId === invoiceId && prior.planId === planId && prior.billingCycle === cycle && Number(prior.amount) === amount) {
      res.json(safeOrderView(prior));
      return;
    }
    fail(res, 409, "Idempotency key was already used for a different payment", "IDEMPOTENCY_CONFLICT");
    return;
  }
  try {
    if (provider === "sandbox") {
      const payload = `medcore-sandbox://pay/${order.id}`;
      const qrImageUrl = await QRCode.toDataURL(payload, { errorCorrectionLevel: "M", margin: 2, width: 280 });
      [order] = await db.update(paymentOrders).set({ providerOrderId: `sandbox_${order.id}`, qrPayload: payload, qrImageUrl, status: "PENDING", updatedAt: new Date() }).where(eq(paymentOrders.id, order.id)).returning();
    } else {
      const gatewayOrder = await razorpayRequest("/orders", {
        amount: paise(amount),
        currency,
        receipt: order.id,
        notes: { medcore_order_id: order.id, hospital_id: ctx.hospital.id, scope },
      }, idempotencyKey);
      const gatewayQr = await razorpayRequest("/payments/qr_codes", {
        type: "upi",
        name: "MedCore HMS",
        usage: "single_use",
        fixed_amount: true,
        payment_amount: paise(amount),
        description: scope === "SUBSCRIPTION" ? "MedCore hospital subscription" : "Hospital invoice payment",
        close_by: Math.floor(expiry.getTime() / 1000),
        notes: { medcore_order_id: order.id, hospital_id: ctx.hospital.id, scope },
      }, `${idempotencyKey}:qr`);
      [order] = await db.update(paymentOrders).set({
        providerOrderId: String(gatewayOrder.id),
        providerQrId: String(gatewayQr.id),
        qrImageUrl: typeof gatewayQr.image_url === "string" ? gatewayQr.image_url : null,
        qrPayload: typeof gatewayQr.image_url === "string" ? gatewayQr.image_url : null,
        status: "PENDING",
        updatedAt: new Date(),
      }).where(eq(paymentOrders.id, order.id)).returning();
    }
  } catch (error) {
    await db.update(paymentOrders).set({ status: "FAILED", updatedAt: new Date() }).where(eq(paymentOrders.id, order.id));
    await audit(ctx.hospital.id, ctx.user.id, "PAYMENT_ORDER_CREATE_FAILED", order.id, { provider });
    logger.warn({ provider, orderId: order.id }, "Payment provider order creation failed");
    fail(res, 502, error instanceof Error ? error.message : "Payment provider request failed", "PAYMENT_PROVIDER_ERROR");
    return;
  }
  await audit(ctx.hospital.id, ctx.user.id, "PAYMENT_ORDER_CREATED", order.id, { scope, amount, currency, provider });
  res.status(201).json(safeOrderView(order));
}

async function findSubscription(hospitalId: string) {
  const [row] = await db.select().from(hospitalSubscriptions).where(eq(hospitalSubscriptions.hospitalId, hospitalId)).orderBy(desc(hospitalSubscriptions.createdAt)).limit(1);
  return row ?? null;
}

async function settleSuccessfulOrder(orderId: string, providerPaymentId: string, method: string | null) {
  const [order] = await db.select().from(paymentOrders).where(eq(paymentOrders.id, orderId)).limit(1);
  if (!order || order.status === "SUCCESS" || order.status === "REFUNDED") return order ?? null;

  if (order.scope === "HOSPITAL_INVOICE" && order.invoiceId) {
    await db.transaction(async (tx) => {
      const [invoice] = await tx.select().from(invoices).where(and(eq(invoices.id, order.invoiceId!), eq(invoices.hospitalId, order.hospitalId))).for("update").limit(1);
      if (!invoice) throw new Error("Invoice was not found during payment reconciliation");
      const due = Number(invoice.total) - Number(invoice.paid);
      if (Number(order.amount) > due + 0.005) throw new Error("Verified payment exceeds the invoice balance; manual reconciliation is required");
      const [updatedOrder] = await tx.update(paymentOrders).set({ status: "SUCCESS", providerPaymentId, method, succeededAt: new Date(), updatedAt: new Date() }).where(and(eq(paymentOrders.id, order.id), inArray(paymentOrders.status, ["CREATED", "PENDING"]))).returning();
      if (!updatedOrder) return;
      const newPaid = Number(invoice.paid) + Number(order.amount);
      await tx.insert(payments).values({ hospitalId: order.hospitalId, invoiceId: invoice.id, patientId: invoice.patientId, amount: order.amount, method: method || "UPI", reference: providerPaymentId, receivedById: order.createdById });
      await tx.update(invoices).set({ paid: newPaid.toFixed(2), status: newPaid >= Number(invoice.total) ? "PAID" : "PARTIALLY_PAID" }).where(eq(invoices.id, invoice.id));
    });
  } else if (order.scope === "SUBSCRIPTION" && order.planId && order.billingCycle) {
    await db.transaction(async (tx) => {
      const [existing] = await tx.select().from(hospitalSubscriptions).where(eq(hospitalSubscriptions.hospitalId, order.hospitalId)).orderBy(desc(hospitalSubscriptions.createdAt)).for("update").limit(1);
      const now = new Date();
      const baseDate = existing && existing.renewalAt > now && ["ACTIVE", "TRIAL", "PAST_DUE", "CANCELLED"].includes(existing.status) ? existing.renewalAt : now;
      const renewalAt = new Date(baseDate);
      if (order.billingCycle === "ANNUAL") renewalAt.setFullYear(renewalAt.getFullYear() + 1);
      else renewalAt.setMonth(renewalAt.getMonth() + 1);
      let subscriptionId = existing?.id;
      if (existing) {
        await tx.update(hospitalSubscriptions).set({
          planId: order.planId!,
          status: "ACTIVE",
          billingCycle: order.billingCycle!,
          currentPeriodStart: now,
          renewalAt,
          cancelRequestedAt: null,
          endedAt: null,
          updatedAt: now,
        }).where(eq(hospitalSubscriptions.id, existing.id));
      } else {
        const [subscription] = await tx.insert(hospitalSubscriptions).values({
          hospitalId: order.hospitalId,
          planId: order.planId!,
          status: "ACTIVE",
          billingCycle: order.billingCycle!,
          startsAt: now,
          currentPeriodStart: now,
          renewalAt,
        }).returning();
        subscriptionId = subscription.id;
      }
      await tx.update(paymentOrders).set({ subscriptionId: subscriptionId! }).where(eq(paymentOrders.id, order.id));
      const [subscriptionPayment] = await tx.insert(subscriptionPayments).values({
        hospitalId: order.hospitalId,
        subscriptionId: subscriptionId!,
        paymentOrderId: order.id,
        planId: order.planId!,
        amount: order.amount,
        currency: order.currency,
        status: "SUCCESS",
        providerPaymentId,
        billingCycle: order.billingCycle!,
        paidAt: now,
      }).onConflictDoNothing().returning();
      if (subscriptionPayment) {
        const invoiceNumber = `MCS-${now.getUTCFullYear()}-${subscriptionPayment.id.slice(0, 8).toUpperCase()}`;
        await tx.insert(subscriptionInvoices).values({
          hospitalId: order.hospitalId,
          subscriptionId: subscriptionId!,
          paymentId: subscriptionPayment.id,
          invoiceNumber,
          description: `MedCore subscription ${order.billingCycle!.toLowerCase()}`,
          amount: order.amount,
          currency: order.currency,
          status: "PAID",
          issuedAt: now,
          paidAt: now,
        }).onConflictDoNothing();
      }
      await tx.update(paymentOrders).set({ status: "SUCCESS", providerPaymentId, method, succeededAt: now, updatedAt: now }).where(and(eq(paymentOrders.id, order.id), inArray(paymentOrders.status, ["CREATED", "PENDING", "CANCELLED", "EXPIRED", "FAILED"])));
    });
  }
  return (await db.select().from(paymentOrders).where(eq(paymentOrders.id, order.id)).limit(1))[0] ?? null;
}

async function applyPaymentEvent(provider: string, eventId: string, eventType: string, payload: Record<string, any>, digest: string) {
  const entity = payload?.payload?.payment?.entity ?? payload?.payload?.refund?.entity ?? payload?.payload?.qr_code?.entity ?? payload?.entity ?? {};
  const notes = entity.notes ?? {};
  const providerPaymentId = String(eventType.startsWith("refund.") ? entity.payment_id || "" : entity.id || entity.payment_id || "");
  const orderId = String(notes.medcore_order_id || "");
  let [order] = orderId
    ? await db.select().from(paymentOrders).where(eq(paymentOrders.id, orderId)).limit(1)
    : [];
  if (!order && entity.order_id) [order] = await db.select().from(paymentOrders).where(and(eq(paymentOrders.provider, provider), eq(paymentOrders.providerOrderId, String(entity.order_id)))).limit(1);
  if (!order && entity.qr_code_id) [order] = await db.select().from(paymentOrders).where(and(eq(paymentOrders.provider, provider), eq(paymentOrders.providerQrId, String(entity.qr_code_id)))).limit(1);
  if (!order && providerPaymentId) [order] = await db.select().from(paymentOrders).where(and(eq(paymentOrders.provider, provider), eq(paymentOrders.providerPaymentId, providerPaymentId))).limit(1);

  const [event] = await db.insert(paymentWebhookEvents).values({
    provider,
    eventId,
    eventType,
    payloadSha256: digest,
    signatureVerified: true,
    paymentOrderId: order?.id ?? null,
  }).onConflictDoNothing().returning();
  if (!event) return { duplicate: true, matched: Boolean(order) };
  if (!order) return { duplicate: false, matched: false };

  if (eventType === "payment.captured" || eventType === "payment.succeeded") {
    if (Number(entity.amount) !== paise(order.amount) || String(entity.currency || order.currency).toUpperCase() !== order.currency || !providerPaymentId) {
      await audit(order.hospitalId, null, "PAYMENT_WEBHOOK_AMOUNT_MISMATCH", order.id, { provider, eventType });
      return { duplicate: false, matched: true, mismatch: true };
    }
    const settled = await settleSuccessfulOrder(order.id, providerPaymentId, typeof entity.method === "string" ? entity.method.toUpperCase() : "UPI");
    if (settled?.status === "SUCCESS") {
      await audit(order.hospitalId, null, "PAYMENT_VERIFIED_SUCCESS", order.id, { provider, paymentId: providerPaymentId });
    }
  } else if (eventType === "payment.failed" || eventType === "payment.cancelled") {
    if (order.status !== "SUCCESS" && order.status !== "REFUNDED") {
      const status = eventType === "payment.cancelled" ? "CANCELLED" : "FAILED";
      await db.update(paymentOrders).set({ status, providerPaymentId: providerPaymentId || order.providerPaymentId, updatedAt: new Date() }).where(and(eq(paymentOrders.id, order.id), inArray(paymentOrders.status, ["CREATED", "PENDING"])));
      await audit(order.hospitalId, null, `PAYMENT_${status}`, order.id, { provider });
    }
  } else if (eventType === "refund.processed" || eventType === "payment.refunded") {
    const paymentId = String(entity.payment_id || entity.id || "");
    const [matchedOrder] = await db.select().from(paymentOrders).where(and(eq(paymentOrders.provider, provider), eq(paymentOrders.providerPaymentId, paymentId))).limit(1);
    if (matchedOrder?.status === "SUCCESS" && Number(entity.amount || 0) >= paise(matchedOrder.amount)) {
      await db.transaction(async (tx) => {
        await tx.update(paymentOrders).set({ status: "REFUNDED", updatedAt: new Date() }).where(eq(paymentOrders.id, matchedOrder.id));
        if (matchedOrder.scope === "HOSPITAL_INVOICE" && matchedOrder.invoiceId) {
          const [invoice] = await tx.select().from(invoices).where(eq(invoices.id, matchedOrder.invoiceId)).for("update").limit(1);
          if (invoice) {
            const newPaid = Math.max(0, Number(invoice.paid) - Number(matchedOrder.amount));
            await tx.update(invoices).set({ paid: newPaid.toFixed(2), status: newPaid === 0 ? "ISSUED" : newPaid >= Number(invoice.total) ? "PAID" : "PARTIALLY_PAID" }).where(eq(invoices.id, invoice.id));
          }
          await tx.update(payments).set({ status: "REFUNDED" }).where(and(eq(payments.reference, paymentId), eq(payments.hospitalId, matchedOrder.hospitalId)));
        } else {
          const [refundedPayment] = await tx.update(subscriptionPayments).set({ status: "REFUNDED" }).where(eq(subscriptionPayments.paymentOrderId, matchedOrder.id)).returning();
          if (matchedOrder.subscriptionId) await tx.update(hospitalSubscriptions).set({ status: "PAST_DUE", updatedAt: new Date() }).where(eq(hospitalSubscriptions.id, matchedOrder.subscriptionId));
          if (refundedPayment) await tx.update(subscriptionInvoices).set({ status: "REFUNDED" }).where(eq(subscriptionInvoices.paymentId, refundedPayment.id));
        }
      });
      await audit(matchedOrder.hospitalId, null, "PAYMENT_REFUNDED", matchedOrder.id, { provider });
    } else if (matchedOrder?.status === "SUCCESS") {
      await audit(matchedOrder.hospitalId, null, "PAYMENT_PARTIAL_REFUND_REQUIRES_MANUAL_RECONCILIATION", matchedOrder.id, { provider });
    }
  }
  return { duplicate: false, matched: true };
}

export async function handleRazorpayWebhook(req: Request, res: Response) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signatureHeader = req.get("X-Razorpay-Signature") || "";
  const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.from("");
  if (!secret || !verifyHmacSha256(rawBody, signatureHeader, secret)) {
    await audit(null, null, "PAYMENT_WEBHOOK_SIGNATURE_REJECTED", "razorpay");
    res.status(secret ? 401 : 503).json({ error: secret ? "Webhook signature is invalid" : "Webhook secret is not configured" });
    return;
  }
  try {
    const payload = JSON.parse(rawBody.toString("utf8")) as Record<string, any>;
    const eventType = String(payload.event || "");
    const eventId = String(req.get("X-Razorpay-Event-Id") || sha256(rawBody));
    const outcome = await applyPaymentEvent("razorpay", eventId, eventType, payload, sha256(rawBody));
    res.status(200).json({ received: true, duplicate: Boolean(outcome.duplicate) });
  } catch (error) {
    logger.error({ err: error }, "Verified payment webhook processing failed");
    res.status(500).json({ error: "Webhook processing failed; provider should retry" });
  }
}

router.get("/subscription/plans", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  const items = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.active, true)).orderBy(asc(subscriptionPlans.monthlyPrice));
  res.json(items.map((plan) => ({ ...plan, monthlyPrice: Number(plan.monthlyPrice), annualPrice: Number(plan.annualPrice) })));
});

router.post("/subscription/trial", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  if (!supportedRoles.hospitalAdmin.includes(ctx.user.role as "HOSPITAL_ADMIN" | "SUPER_ADMIN")) {
    fail(res, 403, "Only hospital administrators can start a trial", "FORBIDDEN");
    return;
  }
  const [plan] = await db.select().from(subscriptionPlans).where(and(eq(subscriptionPlans.id, String(req.body?.planId || "")), eq(subscriptionPlans.active, true))).limit(1);
  if (!plan) {
    fail(res, 404, "Subscription plan not found", "NOT_FOUND");
    return;
  }
  const [previous] = await db.select().from(hospitalSubscriptions).where(eq(hospitalSubscriptions.hospitalId, ctx.hospital.id)).limit(1);
  if (previous) {
    fail(res, 409, "A hospital trial or subscription has already been created", "TRIAL_ALREADY_USED");
    return;
  }
  const now = new Date();
  const renewalAt = new Date(now.getTime() + plan.trialDays * 86400_000);
  const [subscription] = await db.insert(hospitalSubscriptions).values({
    hospitalId: ctx.hospital.id,
    planId: plan.id,
    status: "TRIAL",
    billingCycle: "MONTHLY",
    startsAt: now,
    currentPeriodStart: now,
    renewalAt,
  }).returning();
  await audit(ctx.hospital.id, ctx.user.id, "SUBSCRIPTION_TRIAL_STARTED", subscription.id, { planId: plan.id, trialDays: plan.trialDays });
  res.status(201).json(subscription);
});

router.get("/subscription/current", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  if (!supportedRoles.hospitalAdmin.includes(ctx.user.role as "HOSPITAL_ADMIN" | "SUPER_ADMIN")) {
    fail(res, 403, "Only hospital administrators can view subscription details", "FORBIDDEN");
    return;
  }
  const [subscription] = await db.select().from(hospitalSubscriptions).where(eq(hospitalSubscriptions.hospitalId, ctx.hospital.id)).orderBy(desc(hospitalSubscriptions.createdAt)).limit(1);
  const paymentsList = await db.select().from(subscriptionPayments).where(eq(subscriptionPayments.hospitalId, ctx.hospital.id)).orderBy(desc(subscriptionPayments.createdAt)).limit(50);
  const invoicesList = await db.select().from(subscriptionInvoices).where(eq(subscriptionInvoices.hospitalId, ctx.hospital.id)).orderBy(desc(subscriptionInvoices.issuedAt)).limit(50);
  const plan = subscription ? (await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.id, subscription.planId)).limit(1))[0] : null;
  res.json({
    subscription: subscription ? { ...subscription, status: subscription.renewalAt < new Date() && ["ACTIVE", "TRIAL"].includes(subscription.status) ? "EXPIRED" : subscription.status } : null,
    plan: plan ? { ...plan, monthlyPrice: Number(plan.monthlyPrice), annualPrice: Number(plan.annualPrice) } : null,
    payments: paymentsList.map((item) => ({ ...item, amount: Number(item.amount) })),
    invoices: invoicesList.map((item) => ({ ...item, amount: Number(item.amount) })),
  });
});

router.post("/subscription/orders", async (req, res) => createOrder(req, res, "SUBSCRIPTION"));
router.post("/subscription/upgrade", async (req, res) => createOrder(req, res, "SUBSCRIPTION"));
router.post("/subscription/renew", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  const [sub] = await db.select().from(hospitalSubscriptions).where(eq(hospitalSubscriptions.hospitalId, ctx.hospital.id)).orderBy(desc(hospitalSubscriptions.createdAt)).limit(1);
  if (!sub) {
    fail(res, 409, "Choose a plan before requesting renewal", "SUBSCRIPTION_NOT_FOUND");
    return;
  }
  req.body = { ...req.body, planId: req.body?.planId || sub.planId, billingCycle: req.body?.billingCycle || sub.billingCycle };
  await createOrder(req, res, "SUBSCRIPTION");
});
router.post("/subscription/cancel", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  if (!supportedRoles.hospitalAdmin.includes(ctx.user.role as "HOSPITAL_ADMIN" | "SUPER_ADMIN")) {
    fail(res, 403, "Only hospital administrators can request cancellation", "FORBIDDEN");
    return;
  }
  const [sub] = await db.select().from(hospitalSubscriptions).where(and(eq(hospitalSubscriptions.hospitalId, ctx.hospital.id), inArray(hospitalSubscriptions.status, ["TRIAL", "ACTIVE", "PAST_DUE"]))).orderBy(desc(hospitalSubscriptions.createdAt)).limit(1);
  if (!sub) {
    fail(res, 404, "No cancellable subscription was found", "NOT_FOUND");
    return;
  }
  const [updated] = await db.update(hospitalSubscriptions).set({ status: "CANCELLED", cancelRequestedAt: new Date(), endedAt: sub.renewalAt, updatedAt: new Date() }).where(eq(hospitalSubscriptions.id, sub.id)).returning();
  await audit(ctx.hospital.id, ctx.user.id, "SUBSCRIPTION_CANCELLATION_REQUESTED", sub.id);
  res.json(updated);
});

router.get("/subscription/revenue", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  if (ctx.user.role !== "SUPER_ADMIN") {
    fail(res, 403, "Only super administrators can view platform revenue", "FORBIDDEN");
    return;
  }
  const now = new Date();
  const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const yearStart = new Date(Date.UTC(now.getUTCFullYear(), 0, 1));
  const [successPayments, subscriptions, pendingOrders, failedOrders, plans] = await Promise.all([
    db.select().from(subscriptionPayments).where(eq(subscriptionPayments.status, "SUCCESS")),
    db.select().from(hospitalSubscriptions),
    db.select({ value: count() }).from(paymentOrders).where(and(eq(paymentOrders.scope, "SUBSCRIPTION"), inArray(paymentOrders.status, ["CREATED", "PENDING"]))),
    db.select({ value: count() }).from(paymentOrders).where(and(eq(paymentOrders.scope, "SUBSCRIPTION"), inArray(paymentOrders.status, ["FAILED", "CANCELLED", "EXPIRED"]))),
    db.select().from(subscriptionPlans),
  ]);
  const revenueRows = successPayments.filter((payment) => payment.paidAt);
  const totalRevenue = revenueRows.reduce((total, payment) => total + Number(payment.amount), 0);
  const monthlyRevenue = revenueRows.filter((payment) => payment.paidAt! >= monthStart).reduce((total, payment) => total + Number(payment.amount), 0);
  const annualRevenue = revenueRows.filter((payment) => payment.paidAt! >= yearStart).reduce((total, payment) => total + Number(payment.amount), 0);
  const planMap = new Map(plans.map((plan) => [plan.id, plan.name]));
  const revenueByPlan = new Map<string, number>();
  for (const payment of revenueRows) revenueByPlan.set(planMap.get(payment.planId) || "Unknown plan", (revenueByPlan.get(planMap.get(payment.planId) || "Unknown plan") || 0) + Number(payment.amount));
  const monthlyBuckets: Array<{ month: string; revenue: number }> = [];
  for (let offset = 11; offset >= 0; offset--) {
    const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - offset, 1));
    const end = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, 1));
    const revenue = revenueRows.filter((payment) => payment.paidAt! >= start && payment.paidAt! < end).reduce((sum, payment) => sum + Number(payment.amount), 0);
    monthlyBuckets.push({ month: start.toISOString().slice(0, 7), revenue });
  }
  const currentSubscriptions = subscriptions.filter((sub) => sub.renewalAt >= now && ["TRIAL", "ACTIVE", "PAST_DUE"].includes(sub.status));
  const expiredSubscriptions = subscriptions.filter((sub) => sub.status === "EXPIRED" || (sub.renewalAt < now && ["ACTIVE", "TRIAL"].includes(sub.status)));
  const growth = monthlyBuckets.map(({ month }) => ({
    month,
    newSubscriptions: subscriptions.filter((sub) => sub.startsAt.toISOString().slice(0, 7) === month).length,
  }));
  res.json({
    currency: "INR",
    totalRevenue,
    monthlyRevenue,
    annualRevenue,
    activeSubscriptions: currentSubscriptions.filter((sub) => sub.status === "ACTIVE").length,
    trialSubscriptions: currentSubscriptions.filter((sub) => sub.status === "TRIAL").length,
    expiredSubscriptions: expiredSubscriptions.length,
    pendingPayments: Number(pendingOrders[0]?.value || 0),
    failedPayments: Number(failedOrders[0]?.value || 0),
    revenueByPlan: [...revenueByPlan.entries()].map(([plan, revenue]) => ({ plan, revenue })),
    revenueByMonth: monthlyBuckets,
    subscriptionGrowth: growth,
  });
});

router.post("/payments/orders", async (req, res) => createOrder(req, res, "HOSPITAL_INVOICE"));
router.get("/payments/orders/:orderId", async (req, res) => {
  const authorized = await authorizePaymentOrder(req, res, req.params.orderId);
  if (!authorized) return;
  let { order } = authorized;
  if (["CREATED", "PENDING"].includes(order.status) && order.expiresAt <= new Date()) {
    [order] = await db.update(paymentOrders).set({ status: "EXPIRED", updatedAt: new Date() }).where(and(eq(paymentOrders.id, order.id), inArray(paymentOrders.status, ["CREATED", "PENDING"]))).returning();
    await audit(authorized.hospital.id, authorized.user.id, "PAYMENT_ORDER_EXPIRED", order.id);
  }
  res.json(safeOrderView(order));
});

router.post("/payments/reconcile", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  if (!["HOSPITAL_ADMIN", "ACCOUNTANT", "SUPER_ADMIN"].includes(ctx.user.role)) {
    fail(res, 403, "Only billing administrators can reconcile payments", "FORBIDDEN");
    return;
  }
  if (configuredProvider() !== "razorpay" || !razorpayReady()) {
    fail(res, 503, "Provider API reconciliation requires configured Razorpay credentials", "PAYMENT_CONFIGURATION_REQUIRED");
    return;
  }
  const rows = await db.select().from(paymentOrders).where(and(eq(paymentOrders.hospitalId, ctx.hospital.id), eq(paymentOrders.provider, "razorpay"), inArray(paymentOrders.status, ["CREATED", "PENDING"]))).orderBy(asc(paymentOrders.createdAt)).limit(50);
  let reconciled = 0;
  for (const order of rows) {
    try {
      if (order.expiresAt <= new Date()) {
        await db.update(paymentOrders).set({ status: "EXPIRED", updatedAt: new Date() }).where(and(eq(paymentOrders.id, order.id), inArray(paymentOrders.status, ["CREATED", "PENDING"])));
      }
      if (!order.providerOrderId) continue;
      const result = await razorpayGet(`/orders/${encodeURIComponent(order.providerOrderId)}/payments`);
      const entities = Array.isArray(result.items) ? result.items : [];
      for (const payment of entities) {
        if (payment.status !== "captured" || Number(payment.amount) !== paise(order.amount) || String(payment.currency).toUpperCase() !== order.currency) continue;
        const digest = sha256(JSON.stringify({ orderId: order.id, paymentId: payment.id, status: payment.status, amount: payment.amount }));
        const eventId = `reconcile_${String(payment.id)}`;
        const [event] = await db.insert(paymentWebhookEvents).values({
          provider: "razorpay",
          eventId,
          eventType: "reconciliation.payment.captured",
          payloadSha256: digest,
          signatureVerified: false,
          paymentOrderId: order.id,
        }).onConflictDoNothing().returning();
        if (!event) continue;
        const settled = await settleSuccessfulOrder(order.id, String(payment.id), typeof payment.method === "string" ? payment.method.toUpperCase() : "UPI");
        if (settled?.status === "SUCCESS") {
          reconciled++;
          await audit(ctx.hospital.id, ctx.user.id, "PAYMENT_RECONCILED_BY_PROVIDER_API", order.id, { provider: "razorpay" });
        }
      }
    } catch {
      await audit(ctx.hospital.id, ctx.user.id, "PAYMENT_RECONCILIATION_FAILED", order.id, { provider: "razorpay" });
    }
  }
  res.json({ inspected: rows.length, reconciled });
});
router.post("/payments/orders/:orderId/cancel", async (req, res) => {
  const authorized = await authorizePaymentOrder(req, res, req.params.orderId);
  if (!authorized) return;
  if (!["CREATED", "PENDING"].includes(authorized.order.status)) {
    fail(res, 409, "Payment order is already finalized", "PAYMENT_FINALIZED");
    return;
  }
  const [order] = await db.update(paymentOrders).set({ status: "CANCELLED", updatedAt: new Date() }).where(and(eq(paymentOrders.id, authorized.order.id), inArray(paymentOrders.status, ["CREATED", "PENDING"]))).returning();
  await audit(authorized.hospital.id, authorized.user.id, "PAYMENT_ORDER_CANCELLED", order.id);
  res.json(safeOrderView(order));
});

router.post("/payments/sandbox/:orderId/complete", async (req, res) => {
  if (process.env.NODE_ENV === "production" || configuredProvider() !== "sandbox") {
    fail(res, 404, "Not found", "NOT_FOUND");
    return;
  }
  const authorized = await authorizePaymentOrder(req, res, req.params.orderId);
  if (!authorized) return;
  if (!["CREATED", "PENDING"].includes(authorized.order.status)) {
    fail(res, 409, "Sandbox order is already finalized", "PAYMENT_FINALIZED");
    return;
  }
  const eventId = `sandbox_evt_${randomBytes(12).toString("hex")}`;
  const event = {
    event: "payment.captured",
    payload: { payment: { entity: {
      id: `sandbox_pay_${randomBytes(12).toString("hex")}`,
      order_id: authorized.order.providerOrderId,
      amount: paise(authorized.order.amount),
      currency: authorized.order.currency,
      method: String(req.body?.method || "upi").toLowerCase(),
      status: "captured",
      notes: { medcore_order_id: authorized.order.id },
    } } },
  };
  const body = Buffer.from(JSON.stringify(event));
  const secret = process.env.SANDBOX_WEBHOOK_SECRET || process.env.SESSION_SECRET || "local-sandbox-only";
  const signature = hmacSha256(body, secret);
  if (!verifyHmacSha256(body, signature, secret)) {
    fail(res, 500, "Sandbox signature verification failed", "SANDBOX_SIGNATURE_ERROR");
    return;
  }
  const result = await applyPaymentEvent("sandbox", eventId, event.event, event, sha256(body));
  await audit(authorized.hospital.id, authorized.user.id, "SANDBOX_PAYMENT_COMPLETED", authorized.order.id, { eventId });
  const [updated] = await db.select().from(paymentOrders).where(eq(paymentOrders.id, authorized.order.id)).limit(1);
  res.json({ order: safeOrderView(updated), duplicate: result.duplicate, mode: "SANDBOX - NO REAL MONEY MOVED" });
});

const scanAttempts = new Map<string, { count: number; resetAt: number }>();
router.post("/secure-qr/tokens", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  if (!supportedRoles.qrIssuer.includes(ctx.user.role as "HOSPITAL_ADMIN" | "DOCTOR" | "NURSE" | "RECEPTIONIST")) {
    await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, action: "CREATE_DENIED", success: false, reasonCode: "FORBIDDEN" });
    fail(res, 403, "You cannot issue patient QR tokens", "FORBIDDEN");
    return;
  }
  const purpose = String(req.body?.purpose || "").toUpperCase();
  if (!["PATIENT", "APPOINTMENT", "CHECK_IN"].includes(purpose)) {
    fail(res, 400, "Choose PATIENT, APPOINTMENT, or CHECK_IN QR purpose", "VALIDATION_ERROR");
    return;
  }
  let patientId = typeof req.body?.patientId === "string" ? req.body.patientId : null;
  let appointmentId = typeof req.body?.appointmentId === "string" ? req.body.appointmentId : null;
  if (purpose !== "PATIENT" && !appointmentId) {
    fail(res, 400, "An appointment is required for appointment and check-in QR codes", "VALIDATION_ERROR");
    return;
  }
  if (appointmentId) {
    const [appointment] = await db.select().from(appointments).where(and(eq(appointments.id, appointmentId), eq(appointments.hospitalId, ctx.hospital.id))).limit(1);
    if (!appointment) {
      fail(res, 404, "Appointment not found in this hospital", "NOT_FOUND");
      return;
    }
    if (patientId && patientId !== appointment.patientId) {
      fail(res, 400, "Appointment and patient do not match", "QR_TARGET_MISMATCH");
      return;
    }
    patientId = appointment.patientId;
  }
  if (!patientId) {
    fail(res, 400, "A patient or appointment is required", "VALIDATION_ERROR");
    return;
  }
  const [patient] = await db.select({ id: patients.id }).from(patients).where(and(eq(patients.id, patientId), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
  if (!patient) {
    fail(res, 404, "Patient not found in this hospital", "NOT_FOUND");
    return;
  }
  const rawToken = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + 2 * 60 * 1000);
  const [row] = await db.insert(secureQrTokens).values({
    hospitalId: ctx.hospital.id,
    tokenHash: sha256(rawToken),
    purpose,
    patientId,
    appointmentId,
    createdById: ctx.user.id,
    expiresAt,
  }).returning();
  await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, tokenId: row.id, action: "CREATED", success: true });
  await audit(ctx.hospital.id, ctx.user.id, "SECURE_QR_CREATED", row.id, { purpose });
  const qrDataUrl = await QRCode.toDataURL(rawToken, { errorCorrectionLevel: "M", margin: 2, width: 280 });
  res.status(201).json({ qrDataUrl, purpose, expiresAt, oneTime: true, tokenId: row.id });
});

router.post("/secure-qr/verify", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  const actorKey = `${req.ip}:${ctx.user.id}`;
  const attempt = scanAttempts.get(actorKey);
  if (attempt && attempt.resetAt > Date.now() && attempt.count >= 20) {
    await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, action: "RATE_LIMITED", success: false, reasonCode: "RATE_LIMITED" });
    fail(res, 429, "QR scan limit reached; try again in one minute", "RATE_LIMITED");
    return;
  }
  scanAttempts.set(actorKey, { count: attempt && attempt.resetAt > Date.now() ? attempt.count + 1 : 1, resetAt: Date.now() + 60_000 });
  if (!supportedRoles.qrScanner.includes(ctx.user.role as "HOSPITAL_ADMIN" | "DOCTOR" | "NURSE" | "RECEPTIONIST")) {
    await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, action: "SCAN_DENIED", success: false, reasonCode: "FORBIDDEN" });
    fail(res, 403, "You cannot scan patient QR codes", "FORBIDDEN");
    return;
  }
  const rawToken = typeof req.body?.token === "string" ? req.body.token : "";
  if (rawToken.length < 32 || rawToken.length > 100) {
    await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, action: "SCAN_REJECTED", success: false, reasonCode: "INVALID_TOKEN" });
    fail(res, 400, "QR token is invalid", "INVALID_QR");
    return;
  }
  const tokenHash = sha256(rawToken);
  const [token] = await db.select().from(secureQrTokens).where(eq(secureQrTokens.tokenHash, tokenHash)).limit(1);
  if (!token || token.hospitalId !== ctx.hospital.id) {
    await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, action: "SCAN_REJECTED", success: false, reasonCode: token ? "CROSS_TENANT" : "NOT_FOUND" });
    fail(res, 404, "QR token is invalid for this hospital", "INVALID_QR");
    return;
  }
  if (token.expiresAt <= new Date()) {
    await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, tokenId: token.id, action: "SCAN_REJECTED", success: false, reasonCode: "EXPIRED" });
    fail(res, 410, "QR token has expired", "QR_EXPIRED");
    return;
  }
  if (token.redeemedAt) {
    await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, tokenId: token.id, action: "SCAN_REJECTED", success: false, reasonCode: "REPLAY" });
    fail(res, 409, "QR token has already been used", "QR_REPLAY");
    return;
  }
  const [redeemed] = await db.update(secureQrTokens).set({ redeemedAt: new Date() }).where(and(eq(secureQrTokens.id, token.id), eq(secureQrTokens.hospitalId, ctx.hospital.id), sql`${secureQrTokens.redeemedAt} is null`, gte(secureQrTokens.expiresAt, new Date()))).returning();
  if (!redeemed) {
    await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, tokenId: token.id, action: "SCAN_REJECTED", success: false, reasonCode: "REPLAY" });
    fail(res, 409, "QR token was used by another scan", "QR_REPLAY");
    return;
  }
  let response: Record<string, unknown>;
  if (token.appointmentId) {
    const [appointment] = await db.select().from(appointments).where(and(eq(appointments.id, token.appointmentId), eq(appointments.hospitalId, ctx.hospital.id))).limit(1);
    if (!appointment) {
      fail(res, 404, "Appointment is not available in this hospital", "NOT_FOUND");
      return;
    }
    response = {
      kind: "APPOINTMENT",
      patient: { id: appointment.patientId, name: appointment.patientName },
      appointment: { id: appointment.id, department: appointment.department, doctor: appointment.doctorName, startsAt: appointment.startsAt, status: appointment.status, checkedInAt: appointment.checkedInAt },
    };
    if (token.purpose === "CHECK_IN") {
      if (["CANCELLED", "NO_SHOW"].includes(appointment.status)) {
        await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, tokenId: token.id, action: "CHECK_IN_REJECTED", success: false, reasonCode: "APPOINTMENT_CLOSED" });
        fail(res, 409, "This appointment cannot be checked in", "APPOINTMENT_CLOSED");
        return;
      }
      const [updated] = await db.update(appointments).set({ checkedInAt: new Date(), checkedInById: ctx.user.id, updatedAt: new Date() }).where(and(eq(appointments.id, appointment.id), eq(appointments.hospitalId, ctx.hospital.id))).returning();
      response = { ...response, checkedIn: true, checkedInAt: updated.checkedInAt };
      await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, tokenId: token.id, action: "CHECK_IN", success: true });
      await audit(ctx.hospital.id, ctx.user.id, "APPOINTMENT_QR_CHECK_IN", appointment.id);
    }
  } else if (token.patientId) {
    const [patient] = await db.select({ id: patients.id, name: patients.name, mrn: patients.mrn }).from(patients).where(and(eq(patients.id, token.patientId), eq(patients.hospitalId, ctx.hospital.id))).limit(1);
    if (!patient) {
      fail(res, 404, "Patient is not available in this hospital", "NOT_FOUND");
      return;
    }
    response = { kind: "PATIENT", patient };
  } else {
    fail(res, 404, "QR target is no longer available", "NOT_FOUND");
    return;
  }
  await db.insert(qrAuditEvents).values({ hospitalId: ctx.hospital.id, actorId: ctx.user.id, tokenId: token.id, action: "SCAN_SUCCESS", success: true });
  await audit(ctx.hospital.id, ctx.user.id, "SECURE_QR_SCANNED", token.id, { purpose: token.purpose });
  res.json({ ...response, consumed: true });
});

router.get("/subscription/invoices/:invoiceId/pdf", async (req, res) => {
  const ctx = await loadContext(req, res);
  if (!ctx) return;
  if (!supportedRoles.hospitalAdmin.includes(ctx.user.role as "HOSPITAL_ADMIN" | "SUPER_ADMIN")) {
    fail(res, 403, "Only hospital administrators can download MedCore subscription invoices", "FORBIDDEN");
    return;
  }
  const [invoice] = await db.select().from(subscriptionInvoices).where(and(
    eq(subscriptionInvoices.id, req.params.invoiceId),
    eq(subscriptionInvoices.hospitalId, ctx.hospital.id),
  )).limit(1);
  if (!invoice) {
    fail(res, 404, "MedCore subscription invoice not found", "NOT_FOUND");
    return;
  }
  const doc = new PDFDocument({ size: "A4", margin: 50, info: { Title: `MedCore ${invoice.invoiceNumber}`, Author: "MedCore HMS" } });
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `inline; filename="${invoice.invoiceNumber.replace(/[^a-zA-Z0-9._-]/g, "_")}.pdf"`);
  res.setHeader("Cache-Control", "private, no-store");
  doc.pipe(res);
  doc.fillColor("#07565d").font("Helvetica-Bold").fontSize(22).text("MedCore HMS");
  doc.moveDown(0.4).fillColor("#18353b").fontSize(18).text("Subscription invoice");
  doc.moveDown().font("Helvetica").fontSize(11).fillColor("#263b40")
    .text(`Invoice: ${invoice.invoiceNumber}`)
    .text(`Hospital: ${ctx.hospital.name}`)
    .text(`Description: ${invoice.description}`)
    .text(`Issued: ${invoice.issuedAt.toISOString().slice(0, 10)}`)
    .text(`Status: ${invoice.status}`);
  if (invoice.paidAt) doc.text(`Paid: ${invoice.paidAt.toISOString().slice(0, 10)}`);
  doc.moveDown().font("Helvetica-Bold").fontSize(13).text(`Total: ${invoice.currency} ${Number(invoice.amount).toFixed(2)}`);
  doc.moveDown(2).font("Helvetica").fontSize(9).fillColor("#64777c").text("This invoice is for MedCore HMS platform access. Hospital patient-care invoices are maintained in a separate hospital billing ledger.");
  doc.end();
  await audit(ctx.hospital.id, ctx.user.id, "SUBSCRIPTION_INVOICE_PDF_DOWNLOADED", invoice.id);
});

export default router;