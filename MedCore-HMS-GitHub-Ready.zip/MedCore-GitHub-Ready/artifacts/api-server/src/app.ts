import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import cookieParser from "cookie-parser";
import swaggerUi from "swagger-ui-express";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import router from "./routes";
import { handleRazorpayWebhook } from "./routes/platform";
import { logger } from "./lib/logger";

const app: Express = express();
app.disable("x-powered-by");
const openApiSpecPath = [resolve(process.cwd(), "lib/api-spec/openapi.yaml"), resolve(process.cwd(), "../../lib/api-spec/openapi.yaml")].find(existsSync);
if (!openApiSpecPath) throw new Error("OpenAPI specification was not found; expected lib/api-spec/openapi.yaml");

const configuredOrigins = new Set(
  [process.env.APP_ORIGIN, ...(process.env.CORS_ORIGINS || "").split(",")]
    .filter(Boolean)
    .map((origin) => {
      try { return new URL(origin!).origin; } catch { return ""; }
    })
    .filter(Boolean),
);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use((req, res, next) => {
  const origin = req.get("origin");
  const sameHost = (() => {
    if (!origin || !req.get("host")) return false;
    try { return new URL(origin).host === req.get("host"); } catch { return false; }
  })();
  const allowed = !origin || sameHost || configuredOrigins.has(origin);
  cors({ origin: allowed ? origin || false : false, credentials: true })(req, res, next);
});
app.use((req, res, next) => {
  if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method) && req.path !== "/api/webhooks/razorpay") {
    const origin = req.get("origin");
    if (origin) {
      const sameHost = (() => { try { return new URL(origin).host === req.get("host"); } catch { return false; } })();
      if (!sameHost && !configuredOrigins.has(origin)) {
        res.status(403).json({ error: "Request origin is not allowed", code: "ORIGIN_REJECTED" });
        return;
      }
    }
  }
  return next();
});
app.use(cookieParser());
app.post("/api/webhooks/razorpay", express.raw({ type: "application/json" }), handleRazorpayWebhook);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use((_req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(self), microphone=(), geolocation=()");
  res.setHeader("X-DNS-Prefetch-Control", "off");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  next();
});

app.get("/api/openapi.yaml", (_req, res) => {
  res.type("text/yaml").setHeader("Cache-Control", "no-store");
  res.send(readFileSync(openApiSpecPath));
});
app.use("/api/docs", swaggerUi.serve, swaggerUi.setup(undefined, {
  swaggerOptions: { url: "/api/openapi.yaml", persistAuthorization: true, displayRequestDuration: true },
  customSiteTitle: "MedCore HMS API Documentation",
}));

app.use("/api", router);

export default app;
