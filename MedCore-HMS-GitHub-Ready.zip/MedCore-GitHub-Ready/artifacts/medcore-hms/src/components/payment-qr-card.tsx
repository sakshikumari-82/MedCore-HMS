import { useEffect, useState } from "react";
import { AlertCircle, CheckCircle2, Clock3, X } from "lucide-react";
import { StatusPill } from "@/components/shell";
import { inr, platformApi } from "@/lib/platform-api";

export type PaymentOrder = {
  id: string;
  scope: "HOSPITAL_INVOICE" | "SUBSCRIPTION";
  provider: string;
  status: string;
  amount: number;
  currency: string;
  qrImageUrl?: string | null;
  qrPayload?: string | null;
  expiresAt: string;
};

export function PaymentQrCard({ initialOrder, onClose }: { initialOrder: PaymentOrder; onClose: () => void }) {
  const [order, setOrder] = useState(initialOrder);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!["CREATED", "PENDING"].includes(order.status)) return;
    let stopped = false;
    const poll = async () => {
      try {
        const current = await platformApi<PaymentOrder>(`/payments/orders/${order.id}`);
        if (!stopped) setOrder(current);
      } catch (cause) {
        if (!stopped) setError(cause instanceof Error ? cause.message : "Could not refresh payment status");
      }
    };
    const timer = window.setInterval(() => void poll(), 3500);
    return () => { stopped = true; window.clearInterval(timer); };
  }, [order.id, order.status]);

  const simulate = async () => {
    setBusy(true);
    setError("");
    try {
      const response = await platformApi<{ order: PaymentOrder; mode: string }>(`/payments/sandbox/${order.id}/complete`, { method: "POST", body: JSON.stringify({ method: "upi" }) });
      setOrder(response.order);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Sandbox completion failed");
    } finally {
      setBusy(false);
    }
  };

  const cancel = async () => {
    setBusy(true);
    try {
      const updated = await platformApi<PaymentOrder>(`/payments/orders/${order.id}/cancel`, { method: "POST" });
      setOrder(updated);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not cancel payment");
    } finally {
      setBusy(false);
    }
  };

  return <section className="rounded-2xl border border-primary/20 bg-card p-5 shadow-sm" aria-live="polite">
    <div className="flex items-start justify-between gap-3">
      <div><p className="text-xs font-bold uppercase tracking-wider text-primary">{order.scope === "SUBSCRIPTION" ? "MedCore subscription payment" : "Hospital invoice payment"}</p><h3 className="mt-1 text-xl font-bold">{inr(order.amount)}</h3></div>
      <button onClick={onClose} className="rounded-lg p-2 text-muted-foreground hover:bg-muted" aria-label="Close payment QR"><X size={18} /></button>
    </div>
    <div className="mt-3 flex items-center gap-2"><StatusPill value={order.status} /><span className="text-xs text-muted-foreground">{order.provider === "sandbox" ? "Development sandbox" : "Razorpay"}</span></div>
    {order.status === "SUCCESS" ? <div className="mt-5 rounded-xl bg-emerald-50 p-4 text-emerald-800"><CheckCircle2 className="mb-2" size={22} /><p className="font-bold">Payment verified</p><p className="mt-1 text-sm">The server confirmed this payment. The related invoice or subscription has been updated.</p></div> :
      ["FAILED", "CANCELLED", "EXPIRED", "REFUNDED"].includes(order.status) ? <div className="mt-5 rounded-xl bg-amber-50 p-4 text-amber-900"><AlertCircle size={20} /><p className="mt-2 font-semibold">This payment order is {order.status.toLowerCase()}.</p></div> :
        <div className="mt-5 grid gap-4 sm:grid-cols-[200px_1fr] sm:items-center">
          {order.qrImageUrl ? <img src={order.qrImageUrl} alt={`${order.scope === "SUBSCRIPTION" ? "Subscription" : "Hospital invoice"} payment QR for ${inr(order.amount)}`} className="mx-auto aspect-square w-48 rounded-xl border bg-white p-2" /> : <div className="flex aspect-square w-48 items-center justify-center rounded-xl border bg-muted text-sm text-muted-foreground">QR unavailable</div>}
          <div><p className="font-semibold">Payment instructions</p><p className="mt-1 text-sm text-muted-foreground">{order.provider === "sandbox" ? "Sandbox only: this is not a real UPI payment. Use the development control below to simulate a server-verified event." : "Scan this Razorpay UPI QR in your payment app. Confirm the merchant and amount shown by your payment app before authorizing."}</p><p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground"><Clock3 size={14} /> Expires {new Date(order.expiresAt).toLocaleString()}</p></div>
        </div>}
    {order.provider === "sandbox" && ["CREATED", "PENDING"].includes(order.status) && <button onClick={simulate} disabled={busy} className="mt-4 w-full rounded-xl border border-amber-300 bg-amber-50 px-4 py-2.5 text-sm font-bold text-amber-900 disabled:opacity-50">Simulate verified sandbox payment (no real money)</button>}
    {["CREATED", "PENDING"].includes(order.status) && <button onClick={cancel} disabled={busy} className="mt-2 w-full rounded-xl border px-4 py-2 text-sm font-semibold hover:bg-muted disabled:opacity-50">Cancel payment order</button>}
    {error && <p className="mt-3 text-sm text-rose-700" role="alert">{error}</p>}
    <p className="mt-4 text-[11px] leading-relaxed text-muted-foreground">A QR scan or browser callback never marks payment as paid. Only verified server confirmation updates the ledger.</p>
  </section>;
}