import type { SVGProps } from "react";

export function MedCoreMark({ className = "", ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 48 48" role="img" aria-label="MedCore HMS healthcare mark" className={className} {...props}>
      <path d="M13 7v12a9 9 0 0 0 18 0V7" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="13" cy="6.5" r="3.5" fill="none" stroke="currentColor" strokeWidth="3" />
      <circle cx="31" cy="6.5" r="3.5" fill="none" stroke="currentColor" strokeWidth="3" />
      <path d="M22 28v2a8 8 0 1 0 16 0v-3" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="38" cy="24" r="3.5" fill="currentColor" />
      <circle cx="24" cy="38" r="8.5" fill="#f5ad48" />
      <path d="M24 33.5v9M19.5 38h9" stroke="#073f46" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

export function MedCoreBrand({ compact = false, className = "" }: { compact?: boolean; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#f5ad48] p-1.5 text-[#073f46]">
        <MedCoreMark className="h-full w-full" />
      </span>
      {!compact && <span className="min-w-0">
        <span className="block text-base font-bold tracking-tight">MedCore HMS</span>
        <span className="block text-[10px] leading-4 opacity-75">Connected Care. Smarter Hospitals.</span>
      </span>}
    </span>
  );
}