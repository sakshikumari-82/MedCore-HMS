import { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Bell, CalendarDays, ChevronDown, CircleUserRound, FileText, FlaskConical, LayoutDashboard, LogOut, Menu, PackageOpen, Pill, ReceiptText, Search, Settings2, Stethoscope, Users, X, ScanLine, CreditCard, BarChart3, UserCog } from 'lucide-react';
import { useGetSession, useGetCurrentHospital, useLogout, useSearchAll } from '@workspace/api-client-react';
import { MedCoreBrand } from '@/components/brand';

const nav = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/patients', label: 'Patients', icon: Users },
  { href: '/appointments', label: 'Appointments', icon: CalendarDays },
  { href: '/records', label: 'Clinical records', icon: Stethoscope },
  { href: '/prescriptions', label: 'Prescriptions', icon: Pill },
  { href: '/pharmacy', label: 'Pharmacy', icon: PackageOpen },
  { href: '/labs', label: 'Laboratory', icon: FlaskConical },
  { href: '/billing', label: 'Billing', icon: ReceiptText },
  { href: '/payments', label: 'Invoice payments', icon: CreditCard },
  { href: '/secure-qr', label: 'Patient check-in QR', icon: ScanLine },
  { href: '/staff', label: 'Staff', icon: UserCog },
  { href: '/subscription', label: 'SaaS subscription', icon: CreditCard },
  { href: '/revenue', label: 'Platform revenue', icon: BarChart3 },
  { href: '/attachments', label: 'Attachments', icon: FileText },
  { href: '/portal/files', label: 'My documents', icon: FileText },
];

export function Initials({ name, className = '' }: { name?: string; className?: string }) {
  const value = (name || 'MC').split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase();
  return <span className={`inline-flex items-center justify-center rounded-full bg-teal-100 text-teal-800 font-semibold ${className}`} data-testid="avatar-initials">{value}</span>;
}

export function Shell({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  const session = useGetSession();
  const hospital = useGetCurrentHospital({ query: { queryKey: ['current-hospital'], enabled: Boolean(session.data) } });
  const logout = useLogout();
  const search = useSearchAll({ q: globalSearch.trim() }, { query: { enabled: globalSearch.trim().length >= 2, queryKey: ['global-search', globalSearch.trim()] } });

  useEffect(() => {
    if (session.isError) setLocation('/login');
  }, [session.isError, setLocation]);

  useEffect(() => {
    const branding = hospital.data?.branding;
    if (!branding) return;
    const root = document.documentElement;
    root.dataset.brandTheme = branding.theme || 'teal';
    root.dataset.brandBackground = branding.background || 'white';
    const dark = branding.mode === 'dark' || branding.theme === 'dark';
    root.classList.toggle('dark', dark);
    const colorToHsl = (value?: string) => {
      if (!value || !/^#[0-9a-f]{6}$/i.test(value)) return undefined;
      const channels = [1, 3, 5].map((offset) => parseInt(value.slice(offset, offset + 2), 16) / 255);
      const max = Math.max(...channels), min = Math.min(...channels);
      let h = 0, s = 0;
      const l = (max + min) / 2;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        if (max === channels[0]) h = (channels[1] - channels[2]) / d + (channels[1] < channels[2] ? 6 : 0);
        else if (max === channels[1]) h = (channels[2] - channels[0]) / d + 2;
        else h = (channels[0] - channels[1]) / d + 4;
        h /= 6;
      }
      return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
    };
    const primary = colorToHsl(branding.primary);
    const accent = colorToHsl(branding.accent);
    if (primary) root.style.setProperty('--primary', primary);
    if (accent) root.style.setProperty('--accent', accent);
  }, [hospital.data?.branding]);

  useEffect(() => {
    if (!session.data) return;
    const timer = window.setInterval(() => {
      fetch('/api/auth/refresh', { method: 'POST', credentials: 'include' }).catch(() => undefined);
    }, 4 * 60 * 60 * 1000);
    return () => window.clearInterval(timer);
  }, [session.data?.user.id]);

  if (session.isLoading) return <div className="min-h-[100dvh] bg-background p-6"><div className="mx-auto max-w-6xl space-y-5"><div className="h-8 w-48 animate-pulse rounded-lg bg-muted" /><div className="h-32 animate-pulse rounded-2xl bg-muted" /><div className="grid grid-cols-2 gap-4"><div className="h-28 animate-pulse rounded-2xl bg-muted" /><div className="h-28 animate-pulse rounded-2xl bg-muted" /></div></div></div>;
  if (!session.data) return null;
  const user = session.data.user;
  const hospitalName = hospital.data?.name || session.data.hospital?.name || 'MedCore Hospital';
  const patientOnly = user.role === 'PATIENT';
  const visibleNav = nav.filter(({ href }) => {
    if (patientOnly) return href === '/payments' || href === '/portal/files';
    if (href === '/portal/files') return false;
    if (href === '/staff' || href === '/subscription') return ['HOSPITAL_ADMIN', 'SUPER_ADMIN'].includes(user.role);
    if (href === '/revenue') return user.role === 'SUPER_ADMIN';
    return true;
  });

  return (
    <div className="app-shell min-h-[100dvh]">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[258px] flex-col border-r bg-[#073f46] text-white transition-transform duration-200 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex h-20 items-center justify-between px-6">
          <Link href="/" className="flex items-center gap-3" onClick={() => setMobileOpen(false)} data-testid="link-brand">
            <MedCoreBrand compact className="text-white" />
            <span className="text-sm font-bold tracking-tight">MedCore HMS</span>
          </Link>
          <button className="lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close menu" data-testid="button-close-menu"><X size={19} /></button>
        </div>
        <div className="px-4 pb-5">
          <div className="rounded-xl border border-white/10 bg-white/[.07] px-3 py-3">
            <p className="text-[10px] uppercase tracking-[.16em] text-teal-200">Current workspace</p>
            <p className="mt-1 truncate text-sm font-semibold">{hospitalName}</p>
            <p className="mt-1 text-xs text-teal-100/65">{user.role.replaceAll('_', ' ')}</p>
          </div>
        </div>
        <nav className="flex-1 space-y-1 px-3">
          <p className="px-3 pb-2 pt-1 text-[10px] font-semibold uppercase tracking-[.18em] text-teal-200/60">Workspace</p>
          {patientOnly && <Link href="/portal" onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-teal-50/75 transition-colors hover:bg-white/10 hover:text-white ${location === '/portal' ? 'bg-white/10 text-white' : ''}`} data-testid="link-nav-patient-portal"><CircleUserRound size={17} /><span>Patient portal</span></Link>}
          {visibleNav.map(({ href, label, icon: Icon }) => {
            const active = href === '/' ? location === '/' : location.startsWith(href);
            return <Link key={href} href={href} onClick={() => setMobileOpen(false)} className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${active ? 'bg-[#f5ad48] font-semibold text-[#073f46]' : 'text-teal-50/75 hover:bg-white/10 hover:text-white'}`} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={17} strokeWidth={active ? 2.5 : 1.8} /><span>{label}</span>{label === 'Laboratory' && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#f5ad48]" />}</Link>;
          })}
          {!patientOnly && <><p className="px-3 pb-2 pt-7 text-[10px] font-semibold uppercase tracking-[.18em] text-teal-200/60">Workspace settings</p>
          <Link href="/portal" onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-teal-50/75 transition-colors hover:bg-white/10 hover:text-white ${location === '/portal' ? 'bg-white/10 text-white' : ''}`} data-testid="link-nav-patient-portal"><CircleUserRound size={17} /><span>Patient portal</span></Link>
          <Link href="/settings" onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-teal-50/75 transition-colors hover:bg-white/10 hover:text-white ${location === '/settings' ? 'bg-white/10 text-white' : ''}`} data-testid="link-nav-settings"><Settings2 size={17} /><span>Settings</span></Link></>}
        </nav>
        <div className="border-t border-white/10 p-4">
          <button className="flex w-full items-center gap-3 rounded-xl p-2 text-left transition-colors hover:bg-white/10" onClick={() => logout.mutate(undefined, { onSuccess: () => setLocation('/login') })} data-testid="button-logout">
            <Initials name={user.name} className="h-9 w-9 bg-teal-300 text-teal-950 text-xs" />
            <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{user.name}</span><span className="block truncate text-[11px] text-teal-100/60">{user.email}</span></span>
            <LogOut size={15} className="text-teal-100/60" />
          </button>
        </div>
      </aside>
      {mobileOpen && <button className="fixed inset-0 z-30 bg-[#062b30]/50 lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-overlay-menu" />}
      <div className="lg:pl-[258px]">
        <header className="sticky top-0 z-20 flex h-[72px] items-center gap-3 border-b bg-background/90 px-4 backdrop-blur-md sm:px-7">
          <button className="rounded-lg p-2 hover:bg-muted lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu" data-testid="button-open-menu"><Menu size={20} /></button>
          <div className="relative hidden max-w-md flex-1 sm:block">
            <Search size={17} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={globalSearch} onChange={(event) => setGlobalSearch(event.target.value)} className="h-10 w-full rounded-xl border bg-card pl-10 pr-4 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary" placeholder="Search patients, records, appointments..." data-testid="input-global-search" />
            {globalSearch.trim().length >= 2 && <div className="absolute left-0 right-0 top-12 z-50 overflow-hidden rounded-xl border bg-card shadow-xl">{search.isLoading ? <p className="px-4 py-3 text-xs text-muted-foreground">Searching hospital records…</p> : search.data?.length ? search.data.map((result) => <Link key={`${result.kind}-${result.id}`} href={result.href || '#'} onClick={() => setGlobalSearch('')} className="block border-b px-4 py-3 last:border-0 hover:bg-muted"><p className="text-sm font-semibold">{result.title}</p><p className="mt-0.5 text-xs text-muted-foreground">{result.kind} · {result.subtitle}</p></Link>) : <p className="px-4 py-3 text-xs text-muted-foreground">No matching records</p>}</div>}
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Link href="/settings" className="hidden rounded-lg px-3 py-2 text-xs font-medium text-muted-foreground hover:bg-muted sm:block" data-testid="link-help">Help center</Link>
            <button className="relative rounded-xl p-2.5 text-muted-foreground hover:bg-muted hover:text-foreground" aria-label="Notifications" data-testid="button-notifications"><Bell size={18} /><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-[#e98c4c]" /></button>
            <div className="ml-1 flex items-center gap-2 border-l pl-3"><Initials name={user.name} className="h-8 w-8 text-[11px]" /><span className="hidden text-sm font-semibold sm:block">{user.name.split(' ')[0]}</span><ChevronDown size={14} className="hidden text-muted-foreground sm:block" /></div>
          </div>
        </header>
        <main className="mx-auto max-w-[1500px] p-4 sm:p-7">{children}</main>
      </div>
    </div>
  );
}

export function PageHeader({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><p className="mono mb-2 text-[10px] font-bold uppercase tracking-[.18em] text-primary">{eyebrow || 'MedCore HMS'}</p><h1 className="text-2xl font-bold tracking-[-.03em] text-foreground sm:text-[30px]">{title}</h1>{description && <p className="mt-1.5 max-w-2xl text-sm text-muted-foreground">{description}</p>}</div>{action}</div>;
}

export function StatusPill({ value }: { value?: string | null }) {
  const tone = value?.toLowerCase() || 'pending';
  const styles: Record<string, string> = { active: 'bg-emerald-50 text-emerald-700', paid: 'bg-emerald-50 text-emerald-700', completed: 'bg-emerald-50 text-emerald-700', signed: 'bg-emerald-50 text-emerald-700', confirmed: 'bg-sky-50 text-sky-700', processing: 'bg-amber-50 text-amber-700', issued: 'bg-amber-50 text-amber-700', pending: 'bg-amber-50 text-amber-700', ordered: 'bg-violet-50 text-violet-700', draft: 'bg-slate-100 text-slate-600', cancelled: 'bg-rose-50 text-rose-700', void: 'bg-rose-50 text-rose-700', inactive: 'bg-slate-100 text-slate-600' };
  return <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-bold capitalize ${styles[tone] || 'bg-slate-100 text-slate-600'}`} data-testid={`status-${tone}`}>{tone.replaceAll('_', ' ').toLowerCase()}</span>;
}

export function LoadingRows({ cols = 4 }: { cols?: number }) {
  return <div className="space-y-3 p-4">{[1, 2, 3, 4, 5].map((row) => <div className="grid gap-4 sm:grid-cols-4" key={row}>{Array.from({ length: cols }).map((_, i) => <div className="h-10 animate-pulse rounded-lg bg-muted" key={i} />)}</div>)}</div>;
}

export function EmptyState({ title, message, action }: { title: string; message: string; action?: React.ReactNode }) {
  return <div className="flex min-h-[230px] flex-col items-center justify-center px-5 text-center"><div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-primary"><Stethoscope size={21} /></div><h3 className="font-semibold">{title}</h3><p className="mt-1 max-w-sm text-sm text-muted-foreground">{message}</p>{action && <div className="mt-5">{action}</div>}</div>;
}

export function ErrorState({ onRetry }: { onRetry?: () => void }) {
  return <div className="flex min-h-[220px] flex-col items-center justify-center text-center"><p className="font-semibold">We could not load this view.</p><p className="mt-1 text-sm text-muted-foreground">Your data is safe. Try again in a moment.</p>{onRetry && <button onClick={onRetry} className="mt-4 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90" data-testid="button-retry">Try again</button>}</div>;
}
