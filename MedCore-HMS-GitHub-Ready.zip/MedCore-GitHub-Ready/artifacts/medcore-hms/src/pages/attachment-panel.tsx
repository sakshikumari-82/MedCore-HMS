import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { AlertCircle, Download, FileText, UploadCloud } from "lucide-react";
import {
  getDownloadAttachmentUrl,
  getDownloadPortalAttachmentUrl,
  getListAttachmentsQueryKey,
  useCreateAttachment,
  useListAttachments,
  useListPortalAttachments,
  useRequestUploadUrl,
} from "@workspace/api-client-react";

const acceptedTypes = new Set(["application/pdf", "image/png", "image/jpeg", "text/plain", "text/csv"]);
const extensionTypes: Record<string, string> = {
  pdf: "application/pdf",
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  txt: "text/plain",
  csv: "text/csv",
};

export function PatientAttachmentsPanel({ patientId, portal = false }: { patientId?: string; portal?: boolean }) {
  const queryClient = useQueryClient();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const uploadRequest = useRequestUploadUrl();
  const completeUpload = useCreateAttachment();
  const staffAttachments = useListAttachments(
    { patientId },
    {
      query: {
        enabled: !portal && Boolean(patientId),
        queryKey: getListAttachmentsQueryKey({ patientId }),
      },
    },
  );
  const portalAttachments = useListPortalAttachments({
    query: { enabled: portal, queryKey: ["listPortalAttachments"] },
  });
  const attachments = portal ? portalAttachments.data : staffAttachments.data;
  const loading = portal ? portalAttachments.isLoading : staffAttachments.isLoading;
  const listError = portal ? portalAttachments.isError : staffAttachments.isError;
  const refresh = portal ? portalAttachments.refetch : staffAttachments.refetch;

  const upload = () => {
    if (!selectedFile || !patientId) return;
    const extension = selectedFile.name.split(".").pop()?.toLowerCase() || "";
    const contentType = selectedFile.type || extensionTypes[extension] || "";
    if (!acceptedTypes.has(contentType)) {
      setError("Choose a PDF, PNG, JPEG, plain text, or CSV file.");
      return;
    }
    if (selectedFile.size < 1 || selectedFile.size > 10 * 1024 * 1024) {
      setError("Files must be smaller than 10 MB.");
      return;
    }
    setError("");
    setBusy(true);
    uploadRequest.mutate(
      { data: { name: selectedFile.name, size: selectedFile.size, contentType, patientId } },
      {
        onSuccess: async (upload) => {
          try {
            const response = await fetch(upload.uploadURL, {
              method: "PUT",
              headers: { "Content-Type": contentType },
              body: selectedFile,
            });
            if (!response.ok) throw new Error("The file could not be uploaded to private storage.");
            completeUpload.mutate(
              { data: { uploadIntentId: upload.uploadIntentId } },
              {
                onSuccess: () => {
                  queryClient.invalidateQueries({ queryKey: getListAttachmentsQueryKey({ patientId }) });
                  setSelectedFile(null);
                  setBusy(false);
                },
                onError: () => {
                  setError("The upload arrived, but verification failed. Please try again with a valid file.");
                  setBusy(false);
                },
              },
            );
          } catch (reason) {
            setError(reason instanceof Error ? reason.message : "The file upload failed.");
            setBusy(false);
          }
        },
        onError: () => {
          setError("A private upload could not be started. Please try again.");
          setBusy(false);
        },
      },
    );
  };

  return (
    <section className="overflow-hidden rounded-2xl border bg-card shadow-[0_8px_30px_hsl(190_30%_25%/.04)]" data-testid="panel-patient-attachments">
      <div className="flex items-center gap-3 border-b px-5 py-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary text-primary"><FileText size={16} /></div>
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-bold">Secure attachments</h2>
          <p className="text-xs text-muted-foreground">{portal ? "Files shared with your patient account" : "Private files linked to this patient"}</p>
        </div>
        {portal && <button onClick={() => refresh()} className="text-xs font-semibold text-primary" data-testid="button-refresh-attachments">Refresh</button>}
      </div>
      {!portal && patientId && (
        <div className="flex flex-col gap-3 border-b p-4 sm:flex-row sm:items-center">
          <input
            type="file"
            accept=".pdf,.png,.jpg,.jpeg,.txt,.csv"
            onChange={(event) => setSelectedFile(event.target.files?.[0] || null)}
            disabled={busy}
            className="min-w-0 flex-1 text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-secondary file:px-3 file:py-2 file:text-xs file:font-bold file:text-primary"
            data-testid="input-patient-attachment"
          />
          <button
            type="button"
            onClick={upload}
            disabled={!selectedFile || busy}
            className="flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-50"
            data-testid="button-upload-patient-attachment"
          >
            <UploadCloud size={16} /> {busy ? "Uploading…" : "Upload securely"}
          </button>
        </div>
      )}
      {error && <p className="flex items-center gap-2 px-5 py-3 text-sm text-rose-700" role="alert" data-testid="status-attachment-error"><AlertCircle size={15} />{error}</p>}
      {loading ? (
        <div className="space-y-3 p-5"><div className="h-10 animate-pulse rounded-lg bg-muted" /><div className="h-10 animate-pulse rounded-lg bg-muted" /></div>
      ) : listError ? (
        <div className="p-5 text-sm text-muted-foreground">
          <p>Attachments could not be loaded.</p>
          <button onClick={() => refresh()} className="mt-2 font-semibold text-primary" data-testid="button-retry-attachments">Try again</button>
        </div>
      ) : attachments?.length ? (
        <ul className="divide-y">
          {attachments.map((attachment) => (
            <li key={attachment.id} className="flex items-center gap-3 px-5 py-3.5" data-testid={`row-attachment-${attachment.id}`}>
              <FileText size={17} className="shrink-0 text-primary" />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold" data-testid={`text-attachment-name-${attachment.id}`}>{attachment.fileName}</span>
                <span className="block text-xs text-muted-foreground">{Math.max(1, Math.round(attachment.sizeBytes / 1024))} KB · {new Date(attachment.createdAt).toLocaleDateString()}</span>
              </span>
              <a
                href={portal ? getDownloadPortalAttachmentUrl(attachment.id) : getDownloadAttachmentUrl(attachment.id)}
                className="flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold hover:bg-muted"
                data-testid={`link-download-attachment-${attachment.id}`}
              >
                <Download size={14} /> Download
              </a>
            </li>
          ))}
        </ul>
      ) : (
        <p className="px-5 py-8 text-center text-sm text-muted-foreground" data-testid="text-no-attachments">No files have been attached yet.</p>
      )}
      {!portal && <p className="border-t px-5 py-3 text-[11px] text-muted-foreground">Private App Storage. Maximum 10 MB. Files are checked against their declared type before they appear here.</p>}
    </section>
  );
}