import { useState } from "react";
import { useListPatients } from "@workspace/api-client-react";
import { EmptyState, ErrorState, LoadingRows, PageHeader } from "@/components/shell";
import { PatientAttachmentsPanel } from "@/pages/attachment-panel";

export function AttachmentsPage() {
  const patients = useListPatients({ page: 1, pageSize: 100 });
  const [patientId, setPatientId] = useState("");

  if (patients.isLoading) return <LoadingRows cols={3} />;
  if (patients.isError || !patients.data) return <ErrorState onRetry={() => patients.refetch()} />;

  return (
    <div className="rise-in">
      <PageHeader
        eyebrow="Private patient files"
        title="Attachments"
        description="Upload and download verified files in private, tenant-scoped storage."
      />
      {patients.data.items.length ? (
        <>
          <label className="mb-5 block max-w-xl">
            <span className="label">Patient</span>
            <select value={patientId} onChange={(event) => setPatientId(event.target.value)} className="field" data-testid="select-attachment-patient">
              <option value="">Choose a patient</option>
              {patients.data.items.map((patient) => <option key={patient.id} value={patient.id}>{patient.name} · {patient.mrn}</option>)}
            </select>
          </label>
          {patientId
            ? <PatientAttachmentsPanel patientId={patientId} />
            : <EmptyState title="Choose a patient" message="Select a patient to view, upload, or download their private attachments." />}
        </>
      ) : (
        <EmptyState title="No patients yet" message="Add a patient before attaching clinical files." />
      )}
    </div>
  );
}

export function PortalAttachmentsPage() {
  return (
    <div className="rise-in">
      <PageHeader
        eyebrow="Patient portal"
        title="My documents"
        description="Download files your hospital has shared with your patient account."
      />
      <PatientAttachmentsPanel portal />
    </div>
  );
}