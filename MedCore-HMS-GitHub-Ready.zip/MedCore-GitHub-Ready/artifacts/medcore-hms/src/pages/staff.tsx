import { useEffect, useState } from "react";
import { Pencil, ShieldCheck, UserPlus, UserX } from "lucide-react";
import { Initials, PageHeader, StatusPill } from "@/components/shell";
import { platformApi } from "@/lib/platform-api";

type StaffRole = "HOSPITAL_ADMIN" | "DOCTOR" | "NURSE" | "RECEPTIONIST" | "LAB_TECHNICIAN" | "PHARMACIST" | "ACCOUNTANT";
type StaffMember = { id: string; name: string; email: string; role: StaffRole; department?: string | null; isActive: boolean; createdAt: string };
const roles: StaffRole[] = ["HOSPITAL_ADMIN", "DOCTOR", "NURSE", "RECEPTIONIST", "LAB_TECHNICIAN", "PHARMACIST", "ACCOUNTANT"];

export function StaffPage() {
  const [rows, setRows] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState<StaffMember | null>(null);
  const [form, setForm] = useState({ name: "", email: "", role: "DOCTOR" as StaffRole, department: "", password: "" });

  const reload = async () => {
    setLoading(true);
    try { setRows(await platformApi<StaffMember[]>("/staff")); setError(""); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Staff list could not be loaded"); }
    finally { setLoading(false); }
  };
  useEffect(() => { void reload(); }, []);

  const reset = () => {
    setEditing(null);
    setForm({ name: "", email: "", role: "DOCTOR", department: "", password: "" });
  };
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    const body: Record<string, unknown> = { name: form.name, email: form.email, role: form.role, department: form.department };
    if (form.password) body.password = form.password;
    if (!editing && !form.password) { setError("Set a temporary password of at least 12 characters."); setBusy(false); return; }
    try {
      if (editing) await platformApi(`/staff/${editing.id}`, { method: "PATCH", body: JSON.stringify(body) });
      else await platformApi("/staff", { method: "POST", body: JSON.stringify(body) });
      reset();
      await reload();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Staff changes could not be saved"); }
    finally { setBusy(false); }
  };

  const edit = (member: StaffMember) => {
    setEditing(member);
    setForm({ name: member.name, email: member.email, role: member.role, department: member.department || "", password: "" });
  };
  const deactivate = async (member: StaffMember) => {
    if (!window.confirm(`Deactivate ${member.name}? They will be signed out and cannot log in.`)) return;
    setBusy(true);
    try { await platformApi(`/staff/${member.id}`, { method: "DELETE" }); await reload(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Staff account could not be deactivated"); }
    finally { setBusy(false); }
  };

  return <div className="rise-in">
    <PageHeader eyebrow="Hospital workspace administration" title="Staff & access" description="Manage hospital staff accounts, roles, departments, and access status. Changes to a role, password, or account status revoke active sessions." />
    <div className="grid gap-5 xl:grid-cols-[1.15fr_.85fr]">
      <section className="overflow-hidden rounded-2xl border bg-card">
        <div className="flex items-center justify-between border-b p-5"><div className="flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><ShieldCheck size={19} /></span><div><h2 className="font-bold">Hospital accounts</h2><p className="text-sm text-muted-foreground">Tenant-scoped. No patient accounts are listed here.</p></div></div><span className="rounded-full bg-muted px-2.5 py-1 text-xs font-semibold">{rows.length} staff</span></div>
        {loading ? <p className="p-5 text-sm text-muted-foreground">Loading staff…</p> : error && !rows.length ? <p className="p-5 text-sm text-rose-700">{error}</p> : rows.length ? <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="bg-muted/40 text-[10px] uppercase tracking-wider text-muted-foreground"><tr><th className="px-4 py-3">Staff member</th><th className="px-4 py-3">Role / department</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Manage</th></tr></thead><tbody className="divide-y">{rows.map((member) => <tr key={member.id} className={!member.isActive ? "opacity-60" : ""}><td className="px-4 py-3"><div className="flex items-center gap-2.5"><Initials name={member.name} className="h-8 w-8 text-[10px]" /><div className="min-w-0"><p className="truncate font-semibold">{member.name}</p><p className="truncate text-xs text-muted-foreground">{member.email}</p></div></div></td><td className="px-4 py-3"><p>{member.role.replaceAll("_", " ").toLowerCase()}</p><p className="text-xs text-muted-foreground">{member.department || "No department"}</p></td><td className="px-4 py-3"><StatusPill value={member.isActive ? "active" : "inactive"} /></td><td className="px-4 py-3"><div className="flex gap-1"><button onClick={() => edit(member)} aria-label={`Edit ${member.name}`} className="rounded-lg p-2 hover:bg-muted"><Pencil size={15} /></button>{member.isActive && <button disabled={busy} onClick={() => void deactivate(member)} aria-label={`Deactivate ${member.name}`} className="rounded-lg p-2 text-rose-700 hover:bg-rose-50 disabled:opacity-50"><UserX size={15} /></button>}</div></td></tr>)}</tbody></table></div> : <p className="p-5 text-sm text-muted-foreground">No hospital staff accounts found.</p>}
      </section>
      <section className="rounded-2xl border bg-card p-5">
        <div className="mb-5 flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><UserPlus size={19} /></span><div><h2 className="font-bold">{editing ? "Edit staff account" : "Create staff account"}</h2><p className="text-sm text-muted-foreground">{editing ? "Changing password or role signs out active sessions." : "Temporary passwords must be at least 12 characters."}</p></div></div>
        <form className="space-y-3.5" onSubmit={submit}>
          <label className="block"><span className="label">Full name</span><input required minLength={2} className="field" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} /></label>
          <label className="block"><span className="label">Work email</span><input required type="email" className="field" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} /></label>
          <div className="grid gap-3 sm:grid-cols-2"><label><span className="label">Role</span><select className="field" value={form.role} onChange={(event) => setForm({ ...form, role: event.target.value as StaffRole })}>{roles.map((role) => <option key={role} value={role}>{role.replaceAll("_", " ")}</option>)}</select></label><label><span className="label">Department</span><input className="field" maxLength={100} value={form.department} onChange={(event) => setForm({ ...form, department: event.target.value })} placeholder="e.g. Cardiology" /></label></div>
          <label className="block"><span className="label">{editing ? "New password (optional)" : "Temporary password"}</span><input className="field" type="password" autoComplete="new-password" minLength={12} required={!editing} value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} placeholder={editing ? "Leave blank to keep current password" : "At least 12 characters"} /></label>
          {error && <p className="text-sm text-rose-700" role="alert">{error}</p>}
          <div className="flex gap-2 pt-2"><button disabled={busy} className="flex-1 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50">{busy ? "Saving…" : editing ? "Save staff changes" : "Create account"}</button>{editing && <button type="button" onClick={reset} className="rounded-xl border px-4 py-3 text-sm font-semibold">Cancel</button>}</div>
        </form>
      </section>
    </div>
  </div>;
}