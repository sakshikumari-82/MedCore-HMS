import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CreditCard, ReceiptText } from "lucide-react";
import { PaymentQrCard, type PaymentOrder } from "@/components/payment-qr-card";
import { PageHeader, StatusPill } from "@/components/shell";
import { inr, platformApi } from "@/lib/platform-api";
import { useGetSession } from "@workspace/api-client-react";

type InvoiceRow = { id: string; invoiceNumber: string; patientName?: string; total: number | string; paid: number | string; status: string; dueDate?: string };

export function PaymentCenter() {
  const session = useGetSession();
  const isPatient = session.data?.user.role === "PATIENT";
  const [selectedId, setSelectedId] = useState("");
  const [order, setOrder] = useState<PaymentOrder | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const invoices = useQuery({
    queryKey: ["payment-center-invoices", isPatient ? "patient" : "staff"],
    enabled: Boolean(session.data),
    queryFn: async () => {
      const result = await platformApi<InvoiceRow[] | { items: InvoiceRow[] }>(isPatient ? "/portal/invoices" : "/invoices?page=1&pageSize=100");
      return Array.isArray(result) ? result : result.items || [];
    },
  });
  const selected = invoices.data?.find((invoice) => invoice.id === selectedId);
  const due = selected ? Number(selected.total) - Number(selected.paid) : 0;

  const createPayment = async () => {
    if (!selected || due <= 0) return;
    setBusy(true);
    setError("");
    try {
      const newOrder = await platformApi<PaymentOrder>("/payments/orders", {
        method: "POST",
        headers: { "Idempotency-Key": `ui-${crypto.randomUUID()}` },
        body: JSON.stringify({ invoiceId: selected.id }),
      });
      setOrder(newOrder);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Payment order could not be created");
    } finally {
      setBusy(false);
    }
  };

  return <div className="rise-in">
    <PageHeader eyebrow="Payment QR · hospital billing" title="Invoice payments" description="Collect a hospital invoice payment using a server-created Razorpay QR. This ledger is separate from MedCore subscription revenue." />
    <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_minmax(320px,.8fr)]">
      <section className="rounded-2xl border bg-card p-5 sm:p-6">
        <div className="mb-5 flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><ReceiptText size={19} /></span><div><h2 className="font-bold">Choose an invoice</h2><p className="text-sm text-muted-foreground">{isPatient ? "Only your hospital invoices are shown." : "Only invoices from your current hospital are shown."}</p></div></div>
        <label className="label" htmlFor="invoice-payment-select">Hospital invoice</label>
        <select id="invoice-payment-select" className="field" value={selectedId} onChange={(event) => { setSelectedId(event.target.value); setOrder(null); }}>
          <option value="">Select an invoice</option>
          {(invoices.data || []).map((invoice) => <option key={invoice.id} value={invoice.id}>{invoice.invoiceNumber} · {invoice.patientName || "Your account"} · {inr(Number(invoice.total) - Number(invoice.paid))} due</option>)}
        </select>
        {selected && <div className="mt-4 rounded-xl border bg-muted/30 p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-bold">{selected.invoiceNumber}</p><p className="mt-1 text-sm text-muted-foreground">{selected.patientName || "Patient invoice"}{selected.dueDate ? ` · Due ${selected.dueDate}` : ""}</p></div><StatusPill value={selected.status} /></div><div className="mt-4 grid grid-cols-2 gap-3 text-sm"><div><p className="text-xs text-muted-foreground">Invoice total</p><p className="mt-1 font-semibold">{inr(selected.total)}</p></div><div><p className="text-xs text-muted-foreground">Outstanding</p><p className="mt-1 text-lg font-bold text-primary">{inr(due)}</p></div></div></div>}
        {invoices.isLoading && <p className="mt-4 text-sm text-muted-foreground">Loading invoices…</p>}
        {invoices.isError && <p className="mt-4 text-sm text-rose-700" role="alert">{invoices.error.message}</p>}
        <button onClick={createPayment} disabled={!selected || due <= 0 || busy} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"><CreditCard size={17} />{busy ? "Creating payment QR…" : "Create payment QR"}</button>
        {selected && due <= 0 && <p className="mt-2 text-sm text-emerald-700">This invoice has no remaining balance.</p>}
        {error && <p className="mt-3 text-sm text-rose-700" role="alert">{error}</p>}
      </section>
      <div>{order ? <PaymentQrCard initialOrder={order} onClose={() => setOrder(null)} /> : <div className="flex min-h-64 items-center justify-center rounded-2xl border border-dashed bg-card p-6 text-center"><div><CreditCard className="mx-auto h-8 w-8 text-muted-foreground" /><p className="mt-3 font-semibold">Payment QR appears here</p><p className="mt-1 max-w-sm text-sm text-muted-foreground">A QR is generated from the invoice payment order. Scanning it will not mark the invoice paid.</p></div></div>}</div>
    </div>
  </div>;
}