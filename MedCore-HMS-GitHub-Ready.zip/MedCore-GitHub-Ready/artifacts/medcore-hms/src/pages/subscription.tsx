import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BadgeCheck, CalendarClock, CreditCard, FileText, RefreshCw } from "lucide-react";
import { PaymentQrCard, type PaymentOrder } from "@/components/payment-qr-card";
import { PageHeader, StatusPill } from "@/components/shell";
import { inr, platformApi } from "@/lib/platform-api";

type Plan = { id: string; code: string; name: string; description: string; features: string[]; monthlyPrice: number; annualPrice: number; trialDays: number };
type SubscriptionView = {
  subscription: { id: string; status: string; billingCycle: string; startsAt: string; renewalAt: string; cancelRequestedAt?: string | null } | null;
  plan: Plan | null;
  payments: Array<{ id: string; amount: number; status: string; billingCycle: string; paidAt?: string | null }>;
  invoices: Array<{ id: string; invoiceNumber: string; description: string; amount: number; status: string; issuedAt: string; paidAt: string }>;
};

export function SubscriptionPage() {
  const [cycle, setCycle] = useState<"MONTHLY" | "ANNUAL">("MONTHLY");
  const [order, setOrder] = useState<PaymentOrder | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const plans = useQuery({ queryKey: ["subscription-plans"], queryFn: () => platformApi<Plan[]>("/subscription/plans") });
  const current = useQuery({ queryKey: ["subscription-current"], queryFn: () => platformApi<SubscriptionView>("/subscription/current"), refetchInterval: 8000 });

  const checkout = async (planId: string) => {
    setBusy(true);
    setMessage("");
    try {
      const created = await platformApi<PaymentOrder>("/subscription/orders", {
        method: "POST",
        headers: { "Idempotency-Key": `sub-${crypto.randomUUID()}` },
        body: JSON.stringify({ planId, billingCycle: cycle }),
      });
      setOrder(created);
    } catch (cause) {
      setMessage(cause instanceof Error ? cause.message : "Subscription payment could not be created");
    } finally {
      setBusy(false);
    }
  };

  const startTrial = async (planId: string) => {
    setBusy(true);
    setMessage("");
    try {
      await platformApi("/subscription/trial", { method: "POST", body: JSON.stringify({ planId }) });
      await current.refetch();
      setMessage("Your trial is active.");
    } catch (cause) {
      setMessage(cause instanceof Error ? cause.message : "Trial could not be started");
    } finally {
      setBusy(false);
    }
  };

  const cancel = async () => {
    if (!window.confirm("Request cancellation at the end of the current billing period?")) return;
    setBusy(true);
    try {
      await platformApi("/subscription/cancel", { method: "POST" });
      await current.refetch();
      setMessage("Cancellation recorded. Current access remains available through the displayed renewal date.");
    } catch (cause) {
      setMessage(cause instanceof Error ? cause.message : "Cancellation request failed");
    } finally {
      setBusy(false);
    }
  };

  const data = current.data;
  const isPaidCurrent = Boolean(data?.subscription && ["ACTIVE", "TRIAL", "PAST_DUE"].includes(data.subscription.status));
  return <div className="rise-in">
    <PageHeader eyebrow="MedCore platform billing" title="SaaS subscription" description="Manage the MedCore platform plan for this hospital. Hospital invoice receipts remain in the separate hospital billing ledger." />
    {current.isLoading ? <div className="rounded-2xl border bg-card p-6 text-sm text-muted-foreground">Loading current subscription…</div> : current.isError ? <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800">{current.error.message}</div> : <div className="grid gap-5 xl:grid-cols-[.9fr_1.1fr]">
      <section className="rounded-2xl border bg-card p-5 sm:p-6">
        <div className="flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><BadgeCheck size={20} /></span><div><h2 className="font-bold">Current plan</h2><p className="text-sm text-muted-foreground">Status changes only after a verified provider event.</p></div></div>
        {data?.subscription && data.plan ? <div className="mt-5 rounded-xl border bg-muted/25 p-4"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-xl font-bold">{data.plan.name}</p><p className="mt-1 text-sm text-muted-foreground">{data.subscription.billingCycle.toLowerCase()} billing</p></div><StatusPill value={data.subscription.status} /></div><div className="mt-4 grid gap-3 text-sm sm:grid-cols-2"><div><p className="text-xs text-muted-foreground">Renewal / trial end</p><p className="mt-1 flex items-center gap-2 font-semibold"><CalendarClock size={15} />{new Date(data.subscription.renewalAt).toLocaleDateString()}</p></div><div><p className="text-xs text-muted-foreground">Started</p><p className="mt-1 font-semibold">{new Date(data.subscription.startsAt).toLocaleDateString()}</p></div></div>{data.subscription.cancelRequestedAt && <p className="mt-3 rounded-lg bg-amber-50 p-3 text-xs text-amber-900">Cancellation requested. The current period ends on the renewal date.</p>}<div className="mt-4 flex flex-wrap gap-2">{isPaidCurrent && !data.subscription.cancelRequestedAt && <button disabled={busy} onClick={cancel} className="rounded-lg border px-3 py-2 text-sm font-semibold hover:bg-muted disabled:opacity-50">Request cancellation</button>}<button onClick={() => setCycle(data.subscription!.billingCycle as "MONTHLY" | "ANNUAL")} className="rounded-lg border px-3 py-2 text-sm font-semibold hover:bg-muted">Use current cycle</button></div></div> : <div className="mt-5 rounded-xl border border-dashed p-4"><p className="font-semibold">No subscription yet</p><p className="mt-1 text-sm text-muted-foreground">Choose a plan below or start its 14-day trial.</p></div>}
        <div className="mt-6"><h3 className="font-bold">Payment history</h3>{data?.payments?.length ? <div className="mt-2 divide-y rounded-xl border">{data.payments.map((payment) => <div className="flex items-center gap-3 px-3 py-3" key={payment.id}><div className="min-w-0 flex-1"><p className="text-sm font-semibold">{inr(payment.amount)} · {payment.billingCycle.toLowerCase()}</p><p className="text-xs text-muted-foreground">{payment.paidAt ? new Date(payment.paidAt).toLocaleString() : "Not paid"}</p></div><StatusPill value={payment.status} /></div>)}</div> : <p className="mt-2 text-sm text-muted-foreground">No subscription payments recorded.</p>}</div>
        <div className="mt-6"><h3 className="font-bold">MedCore subscription invoices</h3>{data?.invoices?.length ? <div className="mt-2 divide-y rounded-xl border">{data.invoices.map((invoice) => <div className="flex items-center gap-3 px-3 py-3" key={invoice.id}><FileText size={17} className="text-primary" /><div className="min-w-0 flex-1"><p className="text-sm font-semibold">{invoice.invoiceNumber}</p><p className="text-xs text-muted-foreground">{invoice.description} · {inr(invoice.amount)}</p></div><a href={`/api/subscription/invoices/${invoice.id}/pdf`} className="text-xs font-bold text-primary hover:underline" target="_blank" rel="noreferrer">PDF</a></div>)}</div> : <p className="mt-2 text-sm text-muted-foreground">Subscription receipts appear after a verified payment.</p>}</div>
      </section>
      <section>
        <div className="mb-3 flex items-center justify-between gap-3"><div><h2 className="font-bold">Available plans</h2><p className="text-sm text-muted-foreground">Prices are in INR.</p></div><div className="flex rounded-xl border p-1" role="group" aria-label="Billing cycle"><button onClick={() => setCycle("MONTHLY")} className={`rounded-lg px-3 py-2 text-xs font-bold ${cycle === "MONTHLY" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>Monthly</button><button onClick={() => setCycle("ANNUAL")} className={`rounded-lg px-3 py-2 text-xs font-bold ${cycle === "ANNUAL" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>Annual</button></div></div>
        {plans.isLoading ? <div className="rounded-xl border bg-card p-5 text-sm text-muted-foreground">Loading plans…</div> : <div className="grid gap-3">{(plans.data || []).map((plan) => {
          const amount = cycle === "MONTHLY" ? plan.monthlyPrice : plan.annualPrice;
          const selected = data?.plan?.id === plan.id && data.subscription?.billingCycle === cycle;
          return <article key={plan.id} className={`rounded-2xl border bg-card p-5 ${selected ? "border-primary ring-1 ring-primary/20" : ""}`}><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-wider text-primary">{plan.code}</p><h3 className="mt-1 text-lg font-bold">{plan.name}</h3><p className="mt-1 text-sm text-muted-foreground">{plan.description}</p></div><p className="text-lg font-bold">{inr(amount)}<span className="text-xs font-medium text-muted-foreground"> / {cycle === "ANNUAL" ? "year" : "month"}</span></p></div><ul className="mt-4 grid gap-2 sm:grid-cols-2">{plan.features.map((feature) => <li className="text-xs text-muted-foreground" key={feature}>✓ {feature}</li>)}</ul><div className="mt-4 flex flex-wrap gap-2"><button disabled={busy || selected} onClick={() => checkout(plan.id)} className="flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-50"><CreditCard size={15} />{busy ? "Please wait…" : selected ? "Current plan" : data?.plan ? "Upgrade / change plan" : "Subscribe"}</button>{!data?.subscription && <button disabled={busy} onClick={() => startTrial(plan.id)} className="rounded-xl border px-4 py-2.5 text-sm font-semibold hover:bg-muted disabled:opacity-50"><RefreshCw size={14} className="mr-1 inline" />Start {plan.trialDays}-day trial</button>}</div></article>;
        })}</div>}
        {message && <p className="mt-3 rounded-xl bg-secondary p-3 text-sm" role="status">{message}</p>}
        {order && <div className="mt-5"><PaymentQrCard initialOrder={order} onClose={() => setOrder(null)} /></div>}
      </section>
    </div>}
  </div>;
}