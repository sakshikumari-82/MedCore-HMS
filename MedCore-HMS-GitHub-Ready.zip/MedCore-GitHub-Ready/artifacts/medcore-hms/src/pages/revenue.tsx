import { useQuery } from "@tanstack/react-query";
import { Activity, BadgeDollarSign, Building2, CreditCard, TrendingUp } from "lucide-react";
import { PageHeader, StatusPill } from "@/components/shell";
import { inr, platformApi } from "@/lib/platform-api";

type Revenue = {
  currency: string; totalRevenue: number; monthlyRevenue: number; annualRevenue: number;
  activeSubscriptions: number; trialSubscriptions: number; expiredSubscriptions: number;
  pendingPayments: number; failedPayments: number;
  revenueByPlan: Array<{ plan: string; revenue: number }>;
  revenueByMonth: Array<{ month: string; revenue: number }>;
  subscriptionGrowth: Array<{ month: string; newSubscriptions: number }>;
};

export function PlatformRevenuePage() {
  const query = useQuery({ queryKey: ["platform-revenue"], queryFn: () => platformApi<Revenue>("/subscription/revenue") });
  const data = query.data;
  const max = Math.max(1, ...(data?.revenueByMonth || []).map((item) => Number(item.revenue)));
  return <div className="rise-in">
    <PageHeader eyebrow="MedCore platform · super-admin" title="SaaS revenue" description="Subscription revenue is collected for MedCore. Hospital invoice revenue is deliberately excluded from these totals." />
    {query.isLoading ? <div className="rounded-2xl border bg-card p-6 text-sm text-muted-foreground">Loading platform revenue…</div> : query.isError ? <div className="rounded-2xl border border-rose-200 bg-rose-50 p-5 text-sm text-rose-800">{query.error.message}</div> : data ? <>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[{ label: "Lifetime SaaS revenue", amount: inr(data.totalRevenue), icon: BadgeDollarSign }, { label: "This month", amount: inr(data.monthlyRevenue), icon: TrendingUp }, { label: "Year to date", amount: inr(data.annualRevenue), icon: Activity }, { label: "Active subscriptions", amount: String(data.activeSubscriptions), icon: Building2 }].map(({ label, amount, icon: Icon }) => <div key={label} className="rounded-2xl border bg-card p-5"><div className="flex items-center justify-between"><p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{label}</p><Icon size={19} className="text-primary" /></div><p className="mt-3 text-2xl font-bold">{amount}</p><p className="mt-1 text-[11px] text-muted-foreground">Verified subscription payments only</p></div>)}
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.4fr_.8fr]">
        <section className="rounded-2xl border bg-card p-5"><div className="flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><TrendingUp size={19} /></span><div><h2 className="font-bold">Monthly SaaS revenue</h2><p className="text-sm text-muted-foreground">Last 12 months · INR</p></div></div><div className="mt-6 grid h-56 grid-cols-12 items-end gap-2">{data.revenueByMonth.map((item) => <div key={item.month} className="flex h-full flex-col items-center justify-end gap-2" title={`${item.month}: ${inr(item.revenue)}`}><div className="flex w-full flex-1 items-end"><div className="w-full rounded-t-md bg-primary/80" style={{ height: `${Math.max(3, Number(item.revenue) / max * 100)}%` }} /></div><span className="text-[9px] text-muted-foreground">{item.month.slice(5)}</span></div>)}</div></section>
        <section className="rounded-2xl border bg-card p-5"><div className="flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><CreditCard size={19} /></span><div><h2 className="font-bold">By subscription plan</h2><p className="text-sm text-muted-foreground">All-time verified payments</p></div></div><div className="mt-4 divide-y">{data.revenueByPlan.length ? data.revenueByPlan.map((item) => <div className="flex items-center justify-between gap-3 py-3" key={item.plan}><span className="text-sm font-semibold">{item.plan}</span><span className="text-sm font-bold">{inr(item.revenue)}</span></div>) : <p className="py-4 text-sm text-muted-foreground">No subscription revenue recorded.</p>}</div></section>
      </div>
      <section className="mt-5 rounded-2xl border bg-card p-5"><div className="flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><Building2 size={19} /></span><div><h2 className="font-bold">Subscription health</h2><p className="text-sm text-muted-foreground">Operational counts, separate from hospital billing.</p></div></div><div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">{[{ label: "Active", value: data.activeSubscriptions, state: "ACTIVE" }, { label: "Trials", value: data.trialSubscriptions, state: "TRIAL" }, { label: "Expired", value: data.expiredSubscriptions, state: "EXPIRED" }, { label: "Payments pending", value: data.pendingPayments, state: "PENDING" }, { label: "Payments failed", value: data.failedPayments, state: "FAILED" }].map((item) => <div key={item.state} className="rounded-xl border bg-muted/20 p-4"><StatusPill value={item.state} /><p className="mt-2 text-2xl font-bold">{item.value}</p><p className="text-xs text-muted-foreground">{item.label}</p></div>)}</div></section>
    </> : null}
  </div>;
}