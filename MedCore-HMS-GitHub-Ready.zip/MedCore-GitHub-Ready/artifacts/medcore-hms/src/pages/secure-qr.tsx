import { useEffect, useMemo, useRef, useState } from "react";
import { Camera, CameraOff, CheckCircle2, QrCode, ShieldCheck, UserRound } from "lucide-react";
import { PageHeader, StatusPill } from "@/components/shell";
import { platformApi } from "@/lib/platform-api";

type Patient = { id: string; name: string; mrn: string };
type Appointment = { id: string; patientId: string; patientName: string; doctorName: string; startsAt: string; status: string; department: string };
type IssuedQr = { qrDataUrl: string; purpose: string; expiresAt: string; oneTime: boolean; tokenId: string };
type ScanResult = {
  kind: "PATIENT" | "APPOINTMENT";
  patient: { id: string; name: string; mrn?: string };
  appointment?: { id: string; department: string; doctor: string; startsAt: string; status: string };
  checkedIn?: boolean;
  checkedInAt?: string;
  consumed: boolean;
};

export function SecureQrPage() {
  const [purpose, setPurpose] = useState<"PATIENT" | "APPOINTMENT" | "CHECK_IN">("PATIENT");
  const [patientId, setPatientId] = useState("");
  const [appointmentId, setAppointmentId] = useState("");
  const [issued, setIssued] = useState<IssuedQr | null>(null);
  const [manualToken, setManualToken] = useState("");
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [scanning, setScanning] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const patientsState = useState<Patient[]>([]);
  const appointmentsState = useState<Appointment[]>([]);
  const [patients, setPatients] = patientsState;
  const [appointments, setAppointments] = appointmentsState;
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const controller = new AbortController();
    Promise.all([
      platformApi<{ items: Patient[] }>("/patients?page=1&pageSize=100", { signal: controller.signal }),
      platformApi<{ items: Appointment[] }>("/appointments?page=1&pageSize=100", { signal: controller.signal }),
    ]).then(([patientPage, appointmentPage]) => {
      setPatients(patientPage.items || []);
      setAppointments(appointmentPage.items || []);
    }).catch((cause) => {
      if (cause?.name !== "AbortError") setError(cause instanceof Error ? cause.message : "Could not load QR targets");
    }).finally(() => setLoading(false));
    return () => {
      controller.abort();
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  const availableAppointments = useMemo(() => patientId ? appointments.filter((appointment) => appointment.patientId === patientId) : appointments, [appointments, patientId]);

  const issue = async () => {
    setError("");
    setIssued(null);
    if (purpose === "PATIENT" && !patientId) { setError("Choose a patient first."); return; }
    if (purpose !== "PATIENT" && !appointmentId) { setError("Choose an appointment first."); return; }
    setBusy(true);
    try {
      const qr = await platformApi<IssuedQr>("/secure-qr/tokens", {
        method: "POST",
        body: JSON.stringify({ purpose, patientId: patientId || undefined, appointmentId: appointmentId || undefined }),
      });
      setIssued(qr);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "QR token could not be issued");
    } finally {
      setBusy(false);
    }
  };

  const verify = async (token: string) => {
    const trimmed = token.trim();
    if (!trimmed) return;
    setError("");
    setResult(null);
    setBusy(true);
    try {
      const data = await platformApi<ScanResult>("/secure-qr/verify", { method: "POST", body: JSON.stringify({ token: trimmed }) });
      setResult(data);
      setManualToken("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "QR verification failed");
    } finally {
      setBusy(false);
    }
  };

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setScanning(false);
  };

  const startCamera = async () => {
    setError("");
    if (!navigator.mediaDevices?.getUserMedia) { setError("Camera access is unavailable here. Paste the QR token to verify it."); return; }
    const BarcodeDetectorClass = (window as any).BarcodeDetector;
    if (!BarcodeDetectorClass) { setError("This browser cannot read QR codes from the camera. Use the secure manual-token field."); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
      streamRef.current = stream;
      setScanning(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      const detector = new BarcodeDetectorClass({ formats: ["qr_code"] });
      let active = true;
      const detectFrame = async () => {
        if (!active || !videoRef.current || videoRef.current.readyState < 2) {
          if (active) requestAnimationFrame(detectFrame);
          return;
        }
        try {
          const codes = await detector.detect(videoRef.current);
          const value = codes.find((code: { rawValue?: string }) => code.rawValue)?.rawValue;
          if (value) {
            active = false;
            stopCamera();
            await verify(value);
            return;
          }
        } catch {
          active = false;
          stopCamera();
          setError("Camera scan failed. You can still paste the QR token below.");
          return;
        }
        requestAnimationFrame(detectFrame);
      };
      requestAnimationFrame(detectFrame);
    } catch {
      setScanning(false);
      setError("Camera permission was denied or the camera is unavailable. Use the manual-token field instead.");
    }
  };

  return <div className="rise-in">
    <PageHeader eyebrow="Privacy-first patient identification" title="Secure QR check-in" description="Issue a short-lived, one-use patient or appointment QR, then verify it with the camera or a manual token. Payment QR codes are handled separately." />
    <div className="grid gap-5 xl:grid-cols-2">
      <section className="rounded-2xl border bg-card p-5 sm:p-6">
        <div className="mb-5 flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><QrCode size={20} /></span><div><h2 className="font-bold">Issue patient QR</h2><p className="text-sm text-muted-foreground">Valid for 2 minutes and one successful scan.</p></div></div>
        <label className="label" htmlFor="qr-purpose">QR purpose</label>
        <select id="qr-purpose" className="field" value={purpose} onChange={(event) => { setPurpose(event.target.value as typeof purpose); setIssued(null); }}>
          <option value="PATIENT">Patient identity</option><option value="APPOINTMENT">Appointment lookup</option><option value="CHECK_IN">Appointment check-in</option>
        </select>
        <label className="label mt-4" htmlFor="qr-patient">Patient</label>
        <select id="qr-patient" className="field" value={patientId} onChange={(event) => { setPatientId(event.target.value); setAppointmentId(""); }}>
          <option value="">Choose a patient</option>{patients.map((patient) => <option key={patient.id} value={patient.id}>{patient.name} · {patient.mrn}</option>)}
        </select>
        {purpose !== "PATIENT" && <><label className="label mt-4" htmlFor="qr-appointment">Appointment</label><select id="qr-appointment" className="field" value={appointmentId} onChange={(event) => setAppointmentId(event.target.value)}><option value="">Choose an appointment</option>{availableAppointments.map((appointment) => <option key={appointment.id} value={appointment.id}>{new Date(appointment.startsAt).toLocaleString()} · {appointment.doctorName} · {appointment.status}</option>)}</select></>}
        <button disabled={loading || busy} onClick={issue} className="mt-5 w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50">{busy ? "Issuing…" : "Issue secure QR"}</button>
        {issued && <div className="mt-5 rounded-xl border border-primary/20 bg-secondary/30 p-4 text-center"><p className="text-sm font-bold text-primary">{issued.purpose.replace("_", " ")} · one use</p><img src={issued.qrDataUrl} alt="Short-lived secure patient QR code" className="mx-auto mt-3 h-52 w-52 rounded-xl border bg-white p-2" /><p className="mt-2 text-xs text-muted-foreground">Expires {new Date(issued.expiresAt).toLocaleTimeString()} · QR ID {issued.tokenId.slice(0, 8)}</p><p className="mt-2 text-xs text-muted-foreground">The code contains only a random token. Patient details remain on the authenticated server.</p></div>}
      </section>

      <section className="rounded-2xl border bg-card p-5 sm:p-6">
        <div className="mb-5 flex items-center gap-3"><span className="rounded-xl bg-secondary p-2.5 text-primary"><ShieldCheck size={20} /></span><div><h2 className="font-bold">Verify or check in</h2><p className="text-sm text-muted-foreground">Camera scanning requires your browser’s camera permission.</p></div></div>
        <div className="overflow-hidden rounded-xl bg-slate-950">
          <video ref={videoRef} muted playsInline className={`${scanning ? "block" : "hidden"} aspect-video w-full object-cover`} aria-label="Live camera view for QR scanning" />
          {!scanning && <div className="flex aspect-video flex-col items-center justify-center text-center text-white/70"><CameraOff size={25} /><p className="mt-2 text-sm">Camera off</p></div>}
        </div>
        <button onClick={scanning ? stopCamera : startCamera} className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-bold hover:bg-muted">{scanning ? <CameraOff size={16} /> : <Camera size={16} />}{scanning ? "Stop camera" : "Scan with camera"}</button>
        <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" /><span>OR VERIFY MANUALLY</span><span className="h-px flex-1 bg-border" /></div>
        <label className="label" htmlFor="qr-manual-token">Secure QR token</label>
        <div className="flex gap-2"><input id="qr-manual-token" value={manualToken} onChange={(event) => setManualToken(event.target.value)} className="field font-mono text-xs" placeholder="Paste the random token encoded in a patient QR" autoComplete="off" /><button disabled={busy || !manualToken.trim()} onClick={() => void verify(manualToken)} className="shrink-0 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-50">{busy ? "Verifying…" : "Verify"}</button></div>
        {error && <p className="mt-3 rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-800" role="alert">{error}</p>}
        {result && <div className="mt-5 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-950" role="status"><div className="flex items-center gap-2"><CheckCircle2 size={18} /><p className="font-bold">Verified · token consumed</p></div><div className="mt-3 flex items-start gap-3"><UserRound size={18} className="mt-0.5" /><div><p className="font-semibold">{result.patient.name}</p>{result.patient.mrn && <p className="text-sm">MRN {result.patient.mrn}</p>}</div></div>{result.appointment && <div className="mt-3 border-t border-emerald-200 pt-3 text-sm"><p className="font-semibold">{result.appointment.department} · Dr. {result.appointment.doctor}</p><p className="mt-1">{new Date(result.appointment.startsAt).toLocaleString()} · <StatusPill value={result.appointment.status} /></p>{result.checkedIn && <p className="mt-2 font-bold">Appointment checked in at {result.checkedInAt ? new Date(result.checkedInAt).toLocaleTimeString() : "now"}.</p>}</div>}<p className="mt-3 text-xs">This token cannot be reused. All scans are rate-limited and audited.</p></div>}
      </section>
    </div>
  </div>;
}