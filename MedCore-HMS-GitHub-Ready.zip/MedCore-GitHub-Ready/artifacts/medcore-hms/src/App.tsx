import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Shell } from '@/components/shell';
import { Appointments, Dashboard, Login, PatientProfile, Patients, Pharmacy, Portal, Settings } from '@/pages/app-pages';
import { TablePage } from '@/pages/app-pages';
import { PaymentCenter } from '@/pages/payments';
import { SubscriptionPage } from '@/pages/subscription';
import { SecureQrPage } from '@/pages/secure-qr';
import { StaffPage } from '@/pages/staff';
import { PlatformRevenuePage } from '@/pages/revenue';
import { AttachmentsPage, PortalAttachmentsPage } from '@/pages/attachments';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/">
          <Shell><Dashboard /></Shell>
        </Route>
        <Route path="/patients">
          <Shell><Patients /></Shell>
        </Route>
        <Route path="/patients/:id">
          <Shell><PatientProfile /></Shell>
        </Route>
        <Route path="/appointments">
          <Shell><Appointments /></Shell>
        </Route>
        <Route path="/records">
          <Shell><TablePage kind="records" /></Shell>
        </Route>
        <Route path="/prescriptions">
          <Shell><TablePage kind="prescriptions" /></Shell>
        </Route>
        <Route path="/pharmacy">
          <Shell><Pharmacy /></Shell>
        </Route>
        <Route path="/labs">
          <Shell><TablePage kind="labs" /></Shell>
        </Route>
        <Route path="/billing">
          <Shell><TablePage kind="billing" /></Shell>
        </Route>
        <Route path="/payments">
          <Shell><PaymentCenter /></Shell>
        </Route>
        <Route path="/secure-qr">
          <Shell><SecureQrPage /></Shell>
        </Route>
        <Route path="/staff">
          <Shell><StaffPage /></Shell>
        </Route>
        <Route path="/subscription">
          <Shell><SubscriptionPage /></Shell>
        </Route>
        <Route path="/revenue">
          <Shell><PlatformRevenuePage /></Shell>
        </Route>
        <Route path="/attachments">
          <Shell><AttachmentsPage /></Shell>
        </Route>
        <Route path="/portal/files">
          <Shell><PortalAttachmentsPage /></Shell>
        </Route>
        <Route path="/settings">
          <Shell><Settings /></Shell>
        </Route>
        <Route path="/portal">
          <Shell><Portal /></Shell>
        </Route>
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
