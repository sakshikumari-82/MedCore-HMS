import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const roleEnum = pgEnum("role", [
  "SUPER_ADMIN",
  "HOSPITAL_ADMIN",
  "DOCTOR",
  "NURSE",
  "RECEPTIONIST",
  "LAB_TECHNICIAN",
  "PHARMACIST",
  "ACCOUNTANT",
  "PATIENT",
]);

export const hospitalStatusEnum = pgEnum("hospital_status", [
  "ACTIVE",
  "PENDING",
  "SUSPENDED",
]);

export const appointmentStatusEnum = pgEnum("appointment_status", [
  "PENDING",
  "CONFIRMED",
  "IN_PROGRESS",
  "COMPLETED",
  "CANCELLED",
  "NO_SHOW",
]);

export const appointmentTypeEnum = pgEnum("appointment_type", [
  "CONSULTATION",
  "FOLLOW_UP",
  "EMERGENCY",
  "PROCEDURE",
]);

export const recordStatusEnum = pgEnum("medical_record_status", [
  "DRAFT",
  "SIGNED",
  "AMENDED",
]);

export const prescriptionStatusEnum = pgEnum("prescription_status", [
  "DRAFT",
  "SIGNED",
  "DISPENSED",
  "CANCELLED",
]);

export const labStatusEnum = pgEnum("lab_status", [
  "ORDERED",
  "SAMPLE_COLLECTED",
  "PROCESSING",
  "RESULT_READY",
  "APPROVED",
  "CANCELLED",
  "COLLECTED",
  "COMPLETED",
]);

export const invoiceStatusEnum = pgEnum("invoice_status", [
  "DRAFT",
  "ISSUED",
  "PARTIALLY_PAID",
  "PAID",
  "VOID",
]);

export const platformSubscriptionStatusEnum = pgEnum("platform_subscription_status", [
  "TRIAL",
  "ACTIVE",
  "PAST_DUE",
  "CANCELLED",
  "EXPIRED",
]);
export const platformBillingCycleEnum = pgEnum("platform_billing_cycle", ["MONTHLY", "ANNUAL"]);
export const gatewayPaymentStatusEnum = pgEnum("gateway_payment_status", [
  "CREATED",
  "PENDING",
  "SUCCESS",
  "FAILED",
  "CANCELLED",
  "EXPIRED",
  "REFUNDED",
]);
export const gatewayPaymentScopeEnum = pgEnum("gateway_payment_scope", ["HOSPITAL_INVOICE", "SUBSCRIPTION"]);

export const hospitals = pgTable(
  "hospitals",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    code: varchar("code", { length: 32 }).notNull(),
    city: varchar("city", { length: 100 }).notNull(),
    state: varchar("state", { length: 100 }).notNull().default(""),
    phone: varchar("phone", { length: 32 }).notNull().default(""),
    status: hospitalStatusEnum("status").notNull().default("ACTIVE"),
    branding: jsonb("branding").$type<{
      theme: string;
      background: string;
      primary?: string;
      accent?: string;
      logoMark: string;
      mode?: "light" | "dark";
    }>().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("hospitals_code_unique").on(table.code)],
);

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").references(() => hospitals.id),
    name: varchar("name", { length: 160 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    passwordHash: text("password_hash"),
    role: roleEnum("role").notNull(),
    department: varchar("department", { length: 100 }),
    isActive: boolean("is_active").notNull().default(true),
    avatarUrl: text("avatar_url"),
    isEmailVerified: boolean("is_email_verified").notNull().default(false),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("users_email_unique").on(table.email),
    index("users_hospital_role_idx").on(table.hospitalId, table.role),
  ],
);

export const userSessions = pgTable(
  "user_sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id),
    tokenHash: varchar("token_hash", { length: 64 }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("user_sessions_token_hash_unique").on(table.tokenHash), index("user_sessions_user_expiry_idx").on(table.userId, table.expiresAt)],
);

export const patients = pgTable(
  "patients",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    userId: uuid("user_id").references(() => users.id),
    mrn: varchar("mrn", { length: 40 }).notNull(),
    name: varchar("name", { length: 160 }).notNull(),
    dateOfBirth: date("date_of_birth").notNull(),
    gender: varchar("gender", { length: 40 }).notNull(),
    phone: varchar("phone", { length: 32 }).notNull(),
    email: varchar("email", { length: 320 }),
    bloodGroup: varchar("blood_group", { length: 8 }),
    address: text("address"),
    emergencyContact: text("emergency_contact"),
    status: varchar("status", { length: 20 }).notNull().default("ACTIVE"),
    condition: varchar("condition", { length: 160 }),
    lastVisit: timestamp("last_visit", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("patients_hospital_mrn_unique").on(table.hospitalId, table.mrn),
    index("patients_hospital_name_idx").on(table.hospitalId, table.name),
  ],
);

export const appointments = pgTable(
  "appointments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    patientId: uuid("patient_id").notNull().references(() => patients.id),
    doctorId: uuid("doctor_id").notNull().references(() => users.id),
    patientName: varchar("patient_name", { length: 160 }).notNull(),
    doctorName: varchar("doctor_name", { length: 160 }).notNull(),
    department: varchar("department", { length: 100 }).notNull(),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
    type: appointmentTypeEnum("type").notNull(),
    status: appointmentStatusEnum("status").notNull().default("PENDING"),
    checkedInAt: timestamp("checked_in_at", { withTimezone: true }),
    checkedInById: uuid("checked_in_by_id").references(() => users.id),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (table) => [
    index("appointments_hospital_starts_idx").on(table.hospitalId, table.startsAt),
    index("appointments_doctor_starts_idx").on(table.doctorId, table.startsAt),
  ],
);

export const medicalRecords = pgTable(
  "medical_records",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    patientId: uuid("patient_id").notNull().references(() => patients.id),
    clinicianId: uuid("clinician_id").notNull().references(() => users.id),
    patientName: varchar("patient_name", { length: 160 }).notNull(),
    clinicianName: varchar("clinician_name", { length: 160 }).notNull(),
    chiefComplaint: text("chief_complaint").notNull(),
    symptoms: text("symptoms"),
    diagnosis: text("diagnosis").notNull(),
    icd10: varchar("icd10", { length: 20 }),
    treatment: text("treatment"),
    allergies: text("allergies"),
    vitals: jsonb("vitals").$type<Record<string, number | string | null>>(),
    status: recordStatusEnum("status").notNull().default("SIGNED"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("medical_records_hospital_patient_idx").on(table.hospitalId, table.patientId),
    index("medical_records_created_idx").on(table.createdAt),
  ],
);

export const prescriptions = pgTable(
  "prescriptions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    patientId: uuid("patient_id").notNull().references(() => patients.id),
    doctorId: uuid("doctor_id").notNull().references(() => users.id),
    patientName: varchar("patient_name", { length: 160 }).notNull(),
    doctorName: varchar("doctor_name", { length: 160 }).notNull(),
    medicines: jsonb("medicines").$type<Array<Record<string, string>>>().notNull(),
    instructions: text("instructions"),
    status: prescriptionStatusEnum("status").notNull().default("SIGNED"),
    issuedAt: timestamp("issued_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("prescriptions_hospital_patient_idx").on(table.hospitalId, table.patientId)],
);

export const labOrders = pgTable(
  "lab_orders",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    patientId: uuid("patient_id").notNull().references(() => patients.id),
    orderedById: uuid("ordered_by_id").notNull().references(() => users.id),
    patientName: varchar("patient_name", { length: 160 }).notNull(),
    testName: varchar("test_name", { length: 160 }).notNull(),
    orderedBy: varchar("ordered_by", { length: 160 }).notNull(),
    notes: text("notes"),
    result: text("result"),
    status: labStatusEnum("status").notNull().default("ORDERED"),
    orderedAt: timestamp("ordered_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("lab_orders_hospital_status_idx").on(table.hospitalId, table.status)],
);

export const labTestCatalog = pgTable(
  "lab_test_catalog",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    code: varchar("code", { length: 40 }).notNull(),
    name: varchar("name", { length: 160 }).notNull(),
    specimen: varchar("specimen", { length: 80 }).notNull().default("Blood"),
    unit: varchar("unit", { length: 40 }),
    referenceLow: numeric("reference_low", { precision: 12, scale: 4 }),
    referenceHigh: numeric("reference_high", { precision: 12, scale: 4 }),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("lab_catalog_hospital_code_unique").on(table.hospitalId, table.code), index("lab_catalog_hospital_name_idx").on(table.hospitalId, table.name)],
);

export const labResults = pgTable(
  "lab_results",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    labOrderId: uuid("lab_order_id").notNull().references(() => labOrders.id),
    testId: uuid("test_id").references(() => labTestCatalog.id),
    analyte: varchar("analyte", { length: 160 }).notNull(),
    value: text("value").notNull(),
    numericValue: numeric("numeric_value", { precision: 12, scale: 4 }),
    unit: varchar("unit", { length: 40 }),
    referenceRange: varchar("reference_range", { length: 80 }),
    abnormalFlag: varchar("abnormal_flag", { length: 16 }),
    enteredById: uuid("entered_by_id").notNull().references(() => users.id),
    reviewedById: uuid("reviewed_by_id").references(() => users.id),
    approvedAt: timestamp("approved_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("lab_results_hospital_order_idx").on(table.hospitalId, table.labOrderId)],
);

export const invoices = pgTable(
  "invoices",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    patientId: uuid("patient_id").notNull().references(() => patients.id),
    patientName: varchar("patient_name", { length: 160 }).notNull(),
    invoiceNumber: varchar("invoice_number", { length: 50 }).notNull(),
    issueDate: date("issue_date").notNull(),
    dueDate: date("due_date").notNull(),
    total: numeric("total", { precision: 12, scale: 2 }).notNull(),
    paid: numeric("paid", { precision: 12, scale: 2 }).notNull().default("0"),
    status: invoiceStatusEnum("status").notNull().default("ISSUED"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("invoices_hospital_number_unique").on(table.hospitalId, table.invoiceNumber),
    index("invoices_hospital_status_idx").on(table.hospitalId, table.status),
  ],
);

export const invoiceItems = pgTable(
  "invoice_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    invoiceId: uuid("invoice_id").notNull().references(() => invoices.id),
    category: varchar("category", { length: 32 }).notNull(),
    description: varchar("description", { length: 240 }).notNull(),
    quantity: numeric("quantity", { precision: 12, scale: 2 }).notNull().default("1"),
    unitPrice: numeric("unit_price", { precision: 12, scale: 2 }).notNull(),
    total: numeric("total", { precision: 12, scale: 2 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("invoice_items_hospital_invoice_idx").on(table.hospitalId, table.invoiceId)],
);

export const payments = pgTable(
  "payments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    invoiceId: uuid("invoice_id").notNull().references(() => invoices.id),
    patientId: uuid("patient_id").notNull().references(() => patients.id),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    method: varchar("method", { length: 32 }).notNull(),
    reference: varchar("reference", { length: 120 }),
    status: varchar("status", { length: 24 }).notNull().default("COMPLETED"),
    receivedById: uuid("received_by_id").notNull().references(() => users.id),
    paidAt: timestamp("paid_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("payments_hospital_invoice_idx").on(table.hospitalId, table.invoiceId), index("payments_hospital_paid_idx").on(table.hospitalId, table.paidAt)],
);

export const medicineCatalog = pgTable(
  "medicine_catalog",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    sku: varchar("sku", { length: 64 }).notNull(),
    name: varchar("name", { length: 160 }).notNull(),
    genericName: varchar("generic_name", { length: 160 }),
    form: varchar("form", { length: 40 }).notNull(),
    strength: varchar("strength", { length: 80 }),
    reorderLevel: integer("reorder_level").notNull().default(10),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("medicine_catalog_hospital_sku_unique").on(table.hospitalId, table.sku), index("medicine_catalog_hospital_name_idx").on(table.hospitalId, table.name)],
);

export const medicineBatches = pgTable(
  "medicine_batches",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    medicineId: uuid("medicine_id").notNull().references(() => medicineCatalog.id),
    batchNumber: varchar("batch_number", { length: 80 }).notNull(),
    manufacturingDate: date("manufacturing_date").notNull(),
    expiryDate: date("expiry_date").notNull(),
    quantity: integer("quantity").notNull().default(0),
    unitCost: numeric("unit_cost", { precision: 12, scale: 2 }).notNull(),
    mrp: numeric("mrp", { precision: 12, scale: 2 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("medicine_batches_hospital_batch_unique").on(table.hospitalId, table.batchNumber), index("medicine_batches_fifo_idx").on(table.hospitalId, table.medicineId, table.expiryDate)],
);

export const inventoryTransactions = pgTable(
  "inventory_transactions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    medicineId: uuid("medicine_id").notNull().references(() => medicineCatalog.id),
    batchId: uuid("batch_id").notNull().references(() => medicineBatches.id),
    type: varchar("type", { length: 32 }).notNull(),
    quantity: integer("quantity").notNull(),
    reference: varchar("reference", { length: 160 }),
    actorId: uuid("actor_id").notNull().references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("inventory_tx_hospital_created_idx").on(table.hospitalId, table.createdAt)],
);

export const prescriptionItems = pgTable(
  "prescription_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    prescriptionId: uuid("prescription_id").notNull().references(() => prescriptions.id),
    medicineId: uuid("medicine_id").references(() => medicineCatalog.id),
    medicine: varchar("medicine", { length: 160 }).notNull(),
    dosage: varchar("dosage", { length: 80 }).notNull(),
    frequency: varchar("frequency", { length: 80 }).notNull(),
    duration: varchar("duration", { length: 80 }).notNull(),
    quantity: integer("quantity"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("prescription_items_hospital_prescription_idx").on(table.hospitalId, table.prescriptionId)],
);

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").references(() => hospitals.id),
    userId: uuid("user_id").notNull().references(() => users.id),
    title: varchar("title", { length: 160 }).notNull(),
    message: text("message").notNull(),
    type: varchar("type", { length: 32 }).notNull().default("GENERAL"),
    read: boolean("read").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("notifications_user_created_idx").on(table.userId, table.createdAt)],
);

export const notificationPreferences = pgTable(
  "notification_preferences",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").references(() => hospitals.id),
    userId: uuid("user_id").notNull().references(() => users.id),
    channel: varchar("channel", { length: 16 }).notNull(),
    eventType: varchar("event_type", { length: 64 }).notNull(),
    enabled: boolean("enabled").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("notification_preferences_unique").on(table.userId, table.channel, table.eventType)],
);

export const fileAttachments = pgTable(
  "file_attachments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    patientId: uuid("patient_id").references(() => patients.id),
    uploadedById: uuid("uploaded_by_id").notNull().references(() => users.id),
    objectPath: text("object_path").notNull(),
    fileName: varchar("file_name", { length: 240 }).notNull(),
    mimeType: varchar("mime_type", { length: 120 }).notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("file_attachments_hospital_patient_idx").on(table.hospitalId, table.patientId)],
);

export const fileUploadIntents = pgTable(
  "file_upload_intents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    userId: uuid("user_id").notNull().references(() => users.id),
    patientId: uuid("patient_id").references(() => patients.id),
    objectPath: text("object_path").notNull(),
    fileName: varchar("file_name", { length: 240 }).notNull(),
    mimeType: varchar("mime_type", { length: 120 }).notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("file_upload_intents_object_path_unique").on(table.objectPath),
    index("file_upload_intents_hospital_user_expiry_idx").on(table.hospitalId, table.userId, table.expiresAt),
  ],
);

export const subscriptionPlans = pgTable(
  "subscription_plans",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    code: varchar("code", { length: 32 }).notNull(),
    name: varchar("name", { length: 80 }).notNull(),
    description: text("description").notNull(),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    monthlyPrice: numeric("monthly_price", { precision: 12, scale: 2 }).notNull(),
    annualPrice: numeric("annual_price", { precision: 12, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).notNull().default("INR"),
    trialDays: integer("trial_days").notNull().default(14),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("subscription_plans_code_unique").on(table.code), index("subscription_plans_active_idx").on(table.active)],
);

export const hospitalSubscriptions = pgTable(
  "hospital_subscriptions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    planId: uuid("plan_id").notNull().references(() => subscriptionPlans.id),
    status: platformSubscriptionStatusEnum("status").notNull(),
    billingCycle: platformBillingCycleEnum("billing_cycle").notNull(),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    currentPeriodStart: timestamp("current_period_start", { withTimezone: true }).notNull(),
    renewalAt: timestamp("renewal_at", { withTimezone: true }).notNull(),
    cancelRequestedAt: timestamp("cancel_requested_at", { withTimezone: true }),
    endedAt: timestamp("ended_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("hospital_subscriptions_hospital_status_idx").on(table.hospitalId, table.status), index("hospital_subscriptions_plan_idx").on(table.planId)],
);

export const paymentOrders = pgTable(
  "payment_orders",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    scope: gatewayPaymentScopeEnum("scope").notNull(),
    invoiceId: uuid("invoice_id").references(() => invoices.id),
    subscriptionId: uuid("subscription_id").references(() => hospitalSubscriptions.id),
    planId: uuid("plan_id").references(() => subscriptionPlans.id),
    billingCycle: platformBillingCycleEnum("billing_cycle"),
    provider: varchar("provider", { length: 32 }).notNull(),
    providerOrderId: varchar("provider_order_id", { length: 120 }),
    providerPaymentId: varchar("provider_payment_id", { length: 120 }),
    idempotencyKey: varchar("idempotency_key", { length: 120 }).notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).notNull().default("INR"),
    status: gatewayPaymentStatusEnum("status").notNull().default("CREATED"),
    method: varchar("method", { length: 32 }),
    qrPayload: text("qr_payload"),
    qrImageUrl: text("qr_image_url"),
    providerQrId: varchar("provider_qr_id", { length: 120 }),
    createdById: uuid("created_by_id").notNull().references(() => users.id),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    succeededAt: timestamp("succeeded_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("payment_orders_hospital_idempotency_unique").on(table.hospitalId, table.idempotencyKey),
    uniqueIndex("payment_orders_provider_order_unique").on(table.provider, table.providerOrderId),
    uniqueIndex("payment_orders_provider_payment_unique").on(table.provider, table.providerPaymentId),
    index("payment_orders_hospital_status_idx").on(table.hospitalId, table.status, table.createdAt),
    index("payment_orders_scope_created_idx").on(table.scope, table.createdAt),
  ],
);

export const subscriptionPayments = pgTable(
  "subscription_payments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    subscriptionId: uuid("subscription_id").notNull().references(() => hospitalSubscriptions.id),
    paymentOrderId: uuid("payment_order_id").notNull().references(() => paymentOrders.id),
    planId: uuid("plan_id").notNull().references(() => subscriptionPlans.id),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).notNull().default("INR"),
    status: gatewayPaymentStatusEnum("status").notNull(),
    providerPaymentId: varchar("provider_payment_id", { length: 120 }),
    billingCycle: platformBillingCycleEnum("billing_cycle").notNull(),
    paidAt: timestamp("paid_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("subscription_payments_order_unique").on(table.paymentOrderId), index("subscription_payments_hospital_status_idx").on(table.hospitalId, table.status, table.paidAt), index("subscription_payments_plan_paid_idx").on(table.planId, table.paidAt)],
);

export const subscriptionInvoices = pgTable(
  "subscription_invoices",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    subscriptionId: uuid("subscription_id").notNull().references(() => hospitalSubscriptions.id),
    paymentId: uuid("payment_id").notNull().references(() => subscriptionPayments.id),
    invoiceNumber: varchar("invoice_number", { length: 64 }).notNull(),
    description: varchar("description", { length: 200 }).notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).notNull().default("INR"),
    status: varchar("status", { length: 24 }).notNull().default("PAID"),
    issuedAt: timestamp("issued_at", { withTimezone: true }).defaultNow().notNull(),
    paidAt: timestamp("paid_at", { withTimezone: true }).notNull(),
  },
  (table) => [uniqueIndex("subscription_invoices_hospital_number_unique").on(table.hospitalId, table.invoiceNumber), uniqueIndex("subscription_invoices_payment_unique").on(table.paymentId), index("subscription_invoices_hospital_issued_idx").on(table.hospitalId, table.issuedAt)],
);

export const paymentWebhookEvents = pgTable(
  "payment_webhook_events",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    provider: varchar("provider", { length: 32 }).notNull(),
    eventId: varchar("event_id", { length: 160 }).notNull(),
    eventType: varchar("event_type", { length: 120 }).notNull(),
    payloadSha256: varchar("payload_sha256", { length: 64 }).notNull(),
    signatureVerified: boolean("signature_verified").notNull(),
    paymentOrderId: uuid("payment_order_id").references(() => paymentOrders.id),
    processedAt: timestamp("processed_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("payment_webhook_provider_event_unique").on(table.provider, table.eventId), index("payment_webhook_processed_idx").on(table.processedAt)],
);

export const secureQrTokens = pgTable(
  "secure_qr_tokens",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").notNull().references(() => hospitals.id),
    tokenHash: varchar("token_hash", { length: 64 }).notNull(),
    purpose: varchar("purpose", { length: 24 }).notNull(),
    patientId: uuid("patient_id").references(() => patients.id),
    appointmentId: uuid("appointment_id").references(() => appointments.id),
    createdById: uuid("created_by_id").notNull().references(() => users.id),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    redeemedAt: timestamp("redeemed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("secure_qr_token_hash_unique").on(table.tokenHash), index("secure_qr_hospital_expiry_idx").on(table.hospitalId, table.expiresAt), index("secure_qr_appointment_idx").on(table.appointmentId)],
);

export const qrAuditEvents = pgTable(
  "qr_audit_events",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").references(() => hospitals.id),
    actorId: uuid("actor_id").references(() => users.id),
    tokenId: uuid("token_id").references(() => secureQrTokens.id),
    action: varchar("action", { length: 32 }).notNull(),
    success: boolean("success").notNull(),
    reasonCode: varchar("reason_code", { length: 40 }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("qr_audit_hospital_created_idx").on(table.hospitalId, table.createdAt), index("qr_audit_actor_created_idx").on(table.actorId, table.createdAt)],
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    hospitalId: uuid("hospital_id").references(() => hospitals.id),
    actorId: uuid("actor_id").references(() => users.id),
    action: varchar("action", { length: 100 }).notNull(),
    target: varchar("target", { length: 160 }),
    metadata: jsonb("metadata").$type<Record<string, unknown>>(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("audit_logs_hospital_created_idx").on(table.hospitalId, table.createdAt)],
);

export type Hospital = typeof hospitals.$inferSelect;
export type User = typeof users.$inferSelect;
export type Patient = typeof patients.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type MedicalRecord = typeof medicalRecords.$inferSelect;
export type Prescription = typeof prescriptions.$inferSelect;
export type LabOrder = typeof labOrders.$inferSelect;
export type LabTest = typeof labTestCatalog.$inferSelect;
export type LabResult = typeof labResults.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type InvoiceItem = typeof invoiceItems.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type Medicine = typeof medicineCatalog.$inferSelect;
export type MedicineBatch = typeof medicineBatches.$inferSelect;
export type InventoryTransaction = typeof inventoryTransactions.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;