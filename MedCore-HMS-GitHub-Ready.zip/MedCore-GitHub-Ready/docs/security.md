# Security foundation

- Passwords are stored as salted `scrypt` hashes.
- Sessions are signed, short-lived, httpOnly cookies with SameSite protection.
- Request bodies are validated with generated Zod schemas.
- Hospital-owned data is filtered server-side by tenant context.
- Clinical access, patient access, login/logout, and high-value mutations write audit records.
- Do not log passwords, cookies, bearer tokens, OTPs, or secret values.
- Uploaded clinical files must be added through an object-storage adapter with MIME, extension, permission, and 20 MB size validation before enabling attachments.

This is an application security foundation, not a regulatory or compliance certification.