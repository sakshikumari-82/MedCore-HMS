# MedCore HMS architecture

## Runtime boundaries

- `artifacts/medcore-hms` is the Vite/React web application and uses generated React Query hooks.
- `artifacts/api-server` is the REST service mounted at `/api`.
- `lib/api-spec` is the contract source of truth. Run codegen after changing it.
- `lib/api-client-react` and `lib/api-zod` are generated from OpenAPI.
- `lib/db` owns the PostgreSQL schema and Drizzle connection.

## Request flow

The browser calls the same-origin `/api` path. The API issues an httpOnly signed session cookie. Every hospital-owned query filters by the authenticated hospital id; the super administrator role is the only cross-hospital exception. Medical records are append-only.

## Extension points

Redis, BullMQ, Socket.IO, object storage, and external monitoring are represented in environment/configuration seams but are not enabled in this phase. Add them behind service adapters rather than coupling route handlers to provider SDKs.