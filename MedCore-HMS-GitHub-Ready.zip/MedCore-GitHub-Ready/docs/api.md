# API notes

The OpenAPI document lives at `lib/api-spec/openapi.yaml`. Generated client hooks are available from `@workspace/api-client-react`, and generated Zod schemas are available from `@workspace/api-zod`.

Development API base path: `/api`

Demo staff accounts after seeding:

- `admin@medcore.demo` / `MedcoreDemo123!`
- `doctor@medcore.demo` / `MedcoreDemo123!`
- `nurse@medcore.demo` / `MedcoreDemo123!`
- `patient@medcore.demo` / `MedcoreDemo123!`