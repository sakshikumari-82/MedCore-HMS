---
name: Persistence and API boundary
description: The current MedCore runtime uses the existing Express and Drizzle monorepo foundation while deeper platform migrations remain deferred.
---

The working product boundary is Express REST + Drizzle/PostgreSQL with OpenAPI-generated clients. Do not start a framework or ORM migration as part of routine module work; isolate it as a dedicated migration with compatibility tests.

**Why:** The project already has a live tenant-scoped schema, generated client, seeded data, and managed workflows. Replacing the persistence or API layer during feature delivery would risk the working clinical flows.

**How to apply:** Add new hospital workflows to the existing contract/schema conventions first, and treat NestJS/Prisma, BullMQ, Socket.IO, and object-storage adoption as separately verified infrastructure work.