import { scryptSync, randomBytes } from "node:crypto";
import { db, hospitals, users, patients, appointments, medicalRecords, prescriptions, labOrders, invoices, notifications, auditLogs, labTestCatalog, medicineCatalog, medicineBatches, inventoryTransactions, subscriptionPlans } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `scrypt:${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}

const hospitalId = "11111111-1111-4111-8111-111111111111";
const adminId = "22222222-2222-4222-8222-222222222222";
const doctorId = "33333333-3333-4333-8333-333333333333";
const nurseId = "44444444-4444-4444-8444-444444444444";
const patientUserId = "55555555-5555-4555-8555-555555555555";
const patientId = "66666666-6666-4666-8666-666666666666";
const secondPatientId = "77777777-7777-4777-8777-777777777777";
const appointmentId = "88888888-8888-4888-8888-888888888888";
const superAdminId = "99999999-9999-4999-8999-999999999991";
const receptionistId = "99999999-9999-4999-8999-999999999992";
const labTechId = "99999999-9999-4999-8999-999999999993";
const pharmacistId = "99999999-9999-4999-8999-999999999994";
const accountantId = "99999999-9999-4999-8999-999999999995";
const hba1cCatalogId = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1";
const lipidCatalogId = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2";
const metforminId = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1";
const metforminBatchId = "cccccccc-cccc-4ccc-8ccc-ccccccccccc1";

const now = new Date();
const todayAt = (hour: number, minute = 0) => {
  const value = new Date(now);
  value.setHours(hour, minute, 0, 0);
  return value;
};

const [existing] = await db.select().from(hospitals).where(eq(hospitals.id, hospitalId)).limit(1);
if (!existing) {
  await db.insert(hospitals).values({
    id: hospitalId,
    name: "St. Anselm Medical Center",
    code: "SAMC",
    city: "Bengaluru",
    state: "Karnataka",
    phone: "+91 80 4100 2200",
    status: "ACTIVE",
    branding: { theme: "blue", background: "white", primary: "#1769e0", accent: "#26b7a5", logoMark: "M" },
  });
}

await db.insert(users).values([
  { id: adminId, hospitalId, name: "Aarav Mehta", email: "admin@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "HOSPITAL_ADMIN", isEmailVerified: true },
  { id: doctorId, hospitalId, name: "Dr. Maya Shah", email: "doctor@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "DOCTOR", isEmailVerified: true },
  { id: nurseId, hospitalId, name: "Rhea Nair", email: "nurse@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "NURSE", isEmailVerified: true },
  { id: patientUserId, hospitalId, name: "Priya Menon", email: "patient@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "PATIENT", isEmailVerified: true },
  { id: superAdminId, hospitalId, name: "Nikhil Rao", email: "superadmin@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "SUPER_ADMIN", isEmailVerified: true },
  { id: receptionistId, hospitalId, name: "Anika Joseph", email: "reception@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "RECEPTIONIST", isEmailVerified: true },
  { id: labTechId, hospitalId, name: "Vikram Iyer", email: "lab@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "LAB_TECHNICIAN", isEmailVerified: true },
  { id: pharmacistId, hospitalId, name: "Neha Kapoor", email: "pharmacy@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "PHARMACIST", isEmailVerified: true },
  { id: accountantId, hospitalId, name: "Rohit Das", email: "accounts@medcore.demo", passwordHash: hashPassword("MedcoreDemo123!"), role: "ACCOUNTANT", isEmailVerified: true },
]).onConflictDoNothing();

await db.insert(patients).values([
  { id: patientId, hospitalId, userId: patientUserId, mrn: "MC-10284", name: "Priya Menon", dateOfBirth: "1988-04-12", gender: "Female", phone: "+91 98765 43210", email: "patient@medcore.demo", bloodGroup: "O+", condition: "Type 2 diabetes", lastVisit: new Date(now.getTime() - 1000 * 60 * 60 * 24 * 12) },
  { id: secondPatientId, hospitalId, mrn: "MC-10285", name: "Kabir Rao", dateOfBirth: "1979-09-28", gender: "Male", phone: "+91 99887 11223", email: "kabir.rao@example.com", bloodGroup: "B+", condition: "Hypertension", lastVisit: new Date(now.getTime() - 1000 * 60 * 60 * 24 * 28) },
]).onConflictDoNothing();

await db.insert(appointments).values([
  { id: appointmentId, hospitalId, patientId, doctorId, patientName: "Priya Menon", doctorName: "Dr. Maya Shah", department: "Cardiology", startsAt: todayAt(9, 30), endsAt: todayAt(10), type: "FOLLOW_UP", status: "CONFIRMED", notes: "Review glucose and blood pressure logs" },
  { hospitalId, patientId: secondPatientId, doctorId, patientName: "Kabir Rao", doctorName: "Dr. Maya Shah", department: "Cardiology", startsAt: todayAt(11), endsAt: todayAt(11, 30), type: "CONSULTATION", status: "PENDING", notes: "New patient consultation" },
]).onConflictDoNothing();

await db.insert(medicalRecords).values({
  hospitalId, patientId, clinicianId: doctorId, patientName: "Priya Menon", clinicianName: "Dr. Maya Shah",
  chiefComplaint: "Follow-up for elevated glucose", symptoms: "Fatigue, increased thirst", diagnosis: "Type 2 diabetes mellitus without complications", icd10: "E11.9",
  treatment: "Continue metformin and lifestyle plan", allergies: "No known drug allergies", vitals: { bp: "128/82", pulse: 76, temperature: 36.7, spo2: 99, height: 165, weight: 68, bmi: 25 },
}).onConflictDoNothing();

await db.insert(prescriptions).values({
  hospitalId, patientId, doctorId, patientName: "Priya Menon", doctorName: "Dr. Maya Shah",
  medicines: [{ medicine: "Metformin", form: "Tablet", dosage: "500 mg", frequency: "Twice daily", duration: "30 days", instructions: "Take with meals" }],
  instructions: "Return for review in four weeks", status: "SIGNED",
}).onConflictDoNothing();

await db.insert(labOrders).values([
  { hospitalId, patientId, orderedById: doctorId, patientName: "Priya Menon", testName: "HbA1c", orderedBy: "Dr. Maya Shah", status: "PROCESSING", notes: "Fasting sample not required" },
  { hospitalId, patientId: secondPatientId, orderedById: doctorId, patientName: "Kabir Rao", testName: "Lipid profile", orderedBy: "Dr. Maya Shah", status: "ORDERED" },
]).onConflictDoNothing();

await db.insert(labTestCatalog).values([
  { id: hba1cCatalogId, hospitalId, code: "HBA1C", name: "HbA1c", specimen: "Blood", unit: "%", referenceLow: "4", referenceHigh: "5.6" },
  { id: lipidCatalogId, hospitalId, code: "LIPID", name: "Lipid profile", specimen: "Blood", unit: "mg/dL", referenceLow: "0", referenceHigh: "200" },
]).onConflictDoNothing();

await db.insert(medicineCatalog).values({
  id: metforminId, hospitalId, sku: "MED-MET-500", name: "Metformin 500 mg", genericName: "Metformin", form: "Tablet", strength: "500 mg", reorderLevel: 20,
}).onConflictDoNothing();

await db.insert(medicineBatches).values({
  id: metforminBatchId, hospitalId, medicineId: metforminId, batchNumber: "MET-2026-01", manufacturingDate: "2026-01-10", expiryDate: "2027-01-10", quantity: 240, unitCost: "1.20", mrp: "2.50",
}).onConflictDoNothing();

await db.insert(inventoryTransactions).values({
  hospitalId, medicineId: metforminId, batchId: metforminBatchId, type: "RECEIPT", quantity: 240, reference: "Initial seed stock", actorId: pharmacistId,
}).onConflictDoNothing();

await db.insert(invoices).values([
  { hospitalId, patientId, patientName: "Priya Menon", invoiceNumber: "INV-2026-00418", issueDate: now.toISOString().slice(0, 10), dueDate: new Date(now.getTime() + 1000 * 60 * 60 * 24 * 15).toISOString().slice(0, 10), total: "4850.00", paid: "3000.00", status: "PARTIALLY_PAID" },
  { hospitalId, patientId: secondPatientId, patientName: "Kabir Rao", invoiceNumber: "INV-2026-00419", issueDate: now.toISOString().slice(0, 10), dueDate: new Date(now.getTime() + 1000 * 60 * 60 * 24 * 15).toISOString().slice(0, 10), total: "2200.00", paid: "0", status: "ISSUED" },
]).onConflictDoNothing();

await db.insert(notifications).values([
  { hospitalId, userId: adminId, title: "Lab result ready", message: "HbA1c results for Priya Menon are ready for review.", type: "LAB" },
  { hospitalId, userId: adminId, title: "Payment received", message: "A partial payment was recorded against INV-2026-00418.", type: "BILLING", read: true },
]).onConflictDoNothing();

await db.insert(auditLogs).values({ hospitalId, actorId: adminId, action: "SEED_READY", target: "MedCore HMS" }).onConflictDoNothing();

await db.insert(subscriptionPlans).values([
  {
    code: "BASIC", name: "Basic", description: "Essential tools for a small hospital team.",
    features: ["Patient and appointment management", "Core clinical records", "Laboratory and pharmacy workflows", "Hospital billing and patient portal"],
    monthlyPrice: "2999.00", annualPrice: "29990.00", currency: "INR", trialDays: 14, active: true,
  },
  {
    code: "PROFESSIONAL", name: "Professional", description: "Expanded operations for growing care organizations.",
    features: ["Everything in Basic", "Advanced operational dashboards", "Expanded staff and workflow controls", "Priority support"],
    monthlyPrice: "6999.00", annualPrice: "69990.00", currency: "INR", trialDays: 14, active: true,
  },
  {
    code: "ENTERPRISE", name: "Enterprise", description: "Advanced administration for larger hospital groups.",
    features: ["Everything in Professional", "Multi-site administration", "Enhanced audit and governance", "Dedicated onboarding"],
    monthlyPrice: "14999.00", annualPrice: "149990.00", currency: "INR", trialDays: 14, active: true,
  },
]).onConflictDoUpdate({
  target: subscriptionPlans.code,
  set: { name: sql`excluded.name`, description: sql`excluded.description`, features: sql`excluded.features`, monthlyPrice: sql`excluded.monthly_price`, annualPrice: sql`excluded.annual_price`, currency: sql`excluded.currency`, trialDays: sql`excluded.trial_days`, active: sql`excluded.active`, updatedAt: new Date() },
});

console.log("MedCore HMS seed complete");